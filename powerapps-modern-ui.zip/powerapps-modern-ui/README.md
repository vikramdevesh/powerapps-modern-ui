# Power Apps Modern UI: a Claude skill

This is a Claude skill that builds **modern-looking Power Apps canvas screens as copy-and-paste YAML**. Give Claude the repo link. Claude asks what you're building, shows your app in 3-4 suitable styles from a catalogue of **30**, and once you pick one it generates YAML you paste straight into Power Apps Studio. There are no images, connectors or premium licences to set up.

![All 30 styles](assets/style-picker.png)

| # | Style | Family | Good for |
|---|---|---|---|
| 1 | Fluent Enterprise (`fluent`) | Modern business | Internal line-of-business apps, approvals, HR / IT / finance tools, anything that sits next to Teams and SharePoint. |
| 2 | Slate & Indigo (`slate`) | Modern business | Dashboards, admin consoles, inventory / CRM / ticketing masters. |
| 3 | Midnight Glow (`midnight`) | Modern business | Ops / monitoring dashboards, IT and security consoles, data-heavy screens shown on big displays. |
| 4 | Aurora Glass (`aurora`) | Modern business | Employee portals, self-service apps, booking and request apps, home / landing screens. |
| 5 | Soft Pastel (`pastel`) | Modern business | Retail floor, education, wellbeing, onboarding and front-line apps used on tablets. |
| 6 | Editorial Paper (`editorial`) | Modern business | Reports and briefings, knowledge bases, policy / content apps, executive summaries. |
| 7 | Neo-Brutalist (`brutal`) | Modern business | Creative teams, campaigns, events, start-up tools, anything that should feel energetic and un-corporate. |
| 8 | Keynote Noir (`keynote`) | Modern business | Executive / CEO dashboards, sales leaderboards, kiosk and wallboard screens. |
| 9 | Papercraft Models (`papercraft`) | Atlas · Popular Explainer Looks | Retail and toy shops, maker / craft brands, kids' and education apps, playful internal tools. |
| 10 | Flat-Vector Science (`flatvector`) | Atlas · Popular Explainer Looks | Science, education and STEM apps, product catalogues, onboarding and anything that should feel curious. |
| 11 | Watercolor Wash (`watercolor`) | Atlas · Painterly | Wellbeing, hospitality, events, non-profit and community apps. |
| 12 | Shadow Puppet Theatre (`shadowpuppet`) | Atlas · Paper & Craft | Storytelling, culture and heritage, festivals, hospitality and evening / ambient displays. |
| 13 | Whiteboard Explainer (`whiteboard`) | Atlas · Hand-Drawn | Training and workshops, planning tools, team boards, classroom apps. |
| 14 | Psychedelic Poster (`psychedelic`) | Atlas · Cosmic & Psychedelic | Music, festivals, youth marketing, creative studios. Use when the app should shout. |
| 15 | 1940s Film Noir (`noir`) | Atlas · Light & Imaging | Security, audit and investigations, legal / compliance, moody executive views. |
| 16 | Manim-Style Math (`manim`) | Atlas · Popular Explainer Looks | Analytics and finance models, engineering, data-science and forecasting tools. |
| 17 | Illuminated Manuscript (`manuscript`) | Atlas · Illustration | Heritage, libraries and archives, ceremonies, premium / luxury brands, certificates. |
| 18 | Bioluminescent Deep Sea (`deepsea`) | Atlas · Light & Imaging | Environmental and energy monitoring, IoT and sensor dashboards, night-shift operations. |
| 19 | Halftone Pop Panel (`halftone`) | Atlas · Print | Marketing, promotions and retail campaigns, gamified apps, youth audiences. |
| 20 | Synthwave Neon (`synthwave`) | Retro UI & Neon | Gaming, entertainment, music and nightlife, hackathons, fun internal leaderboards. |
| 21 | Retro Desktop '95 (`retroos`) | Retro UI & Neon | Fun internal tools, IT teams, retro-themed campaigns, kiosks that must look clickable. |
| 22 | Pixel Arcade (`pixel`) | Retro Digital | Gamification, learning and rewards apps, kids' clubs, playful team trackers. |
| 23 | Green Terminal (`terminal`) | Retro Digital | Developer and DevOps tools, network / server status, hacker-style ops consoles. |
| 24 | Blueprint (`blueprint`) | Data & Information | Facilities, construction, engineering, field service and asset management. |
| 25 | Bauhaus (`bauhaus`) | Art & Design Movements | Design-led brands, architecture, museums, culture and any app wanting a confident, geometric look. |
| 26 | Swiss Grid (`swiss`) | Art & Design Movements | Corporate reporting, finance, consulting, public sector and documentation apps. |
| 27 | Claymorphism (`clay`) | Dimensional | Consumer-style employee apps, wellbeing, rewards, onboarding and kids' learning. |
| 28 | Risograph Print (`risograph`) | Print | Creative agencies, zines and media, community events, start-ups with personality. |
| 29 | Chalkboard (`chalkboard`) | Hand-Drawn | Schools and training, cafés and menus, coaching, team stand-ups. |
| 30 | Art Deco (`artdeco`) | Art & Design Movements | Luxury retail, hotels, banking and wealth, premium memberships and VIP dashboards. |

Each style ships with four page templates: **Home**, **Dashboard** (KPIs, breakdown, ranking, alerts), **List** (search, filter pills, sortable table) and **Form** (add, edit, delete with validation). `gallery/index.html` shows every page in every style.

## Start here

- **How-to guide (PDF):** [`docs/Power-Apps-Modern-UI-How-to-use.pdf`](docs/Power-Apps-Modern-UI-How-to-use.pdf)
- **Ready-to-use YAML for all 30 styles:** download [`docs/ready-to-use.html`](docs/ready-to-use.html) and open it in your browser. Pick a style, choose *Demo data* or *SharePoint list*, and copy each block. The sample CSV, [`docs/sample-data.csv`](docs/sample-data.csv), creates the SharePoint list the screens expect.

## Use it with Claude

- **Claude.ai / desktop:** download this repo as a ZIP and upload it under **Settings → Capabilities → Skills**. Alternatively, paste the GitHub link into a chat and ask *"Use this skill to build me a Power App"*.
- **Claude Code:** `git clone <repo-url> ~/.claude/skills/powerapps-modern-ui`.

Claude then follows `SKILL.md`:

1. It asks **what you want to build**: purpose, users, screens, fields and brand.
2. It writes a spec for your app and **shows sample images of your app** in the 3-4 styles that fit.
3. You **pick** one.
4. It generates the YAML and a `paste.html` page with a **Copy** button for each file.

## Paste into Power Apps

1. Create a **blank canvas app** in **Tablet** format.
2. In the Tree view, select **App**, choose the **Formulas** property and paste `App.Formulas.txt`.
3. Right-click any screen and choose **Paste** for each `.pa.yaml`. Studio may freeze for up to a minute.
4. Drag the first screen to the top, delete Screen1, save and press **Play**.

Ready-made examples for every style are in `examples/retail-inventory/<style>/`. Open `paste.html` in a folder and copy each block.

## Build it yourself (without Claude)

```bash
pip install pyyaml pillow playwright && python -m playwright install chromium
python scripts/build.py examples/specs/retail-inventory.json --style aurora --out out/inventory
python scripts/compare.py my-spec.json --styles slate,aurora,keynote   # side-by-side style samples
python scripts/build.py my-spec.json --style slate --source MyList       # screens that read/write a SharePoint list
python scripts/make_gallery.py                                         # rebuild examples, previews, gallery
python scripts/make_ready.py                                           # rebuild docs/ready-to-use.html
```

See `reference/spec-format.md` for the spec format, `reference/styles.md` for the style tokens, `reference/design-principles.md` for the design rules and `reference/powerapps-yaml-notes.md` for Power Apps paste gotchas.

## Credits

Built on the ToyCo / Cosmo / Teddy-Tech Power Apps kit's builder approach. Style research drew on Futurepedia's AI Style Atlas (Papercraft Models, Flat-Vector Science, Watercolor Wash, Shadow Puppet Theatre, Whiteboard Explainer, Psychedelic Poster, 1940s Film Noir, Manim-Style Math, Illuminated Manuscript, Bioluminescent Deep Sea, Halftone Pop Panel, Tech Glow, Product Launch Reveal, Isometric Pastel and Editorial Essay Collage), Anthropic's `frontend-design` and `theme-factory` skills, and the design skills round-up on composio.dev.

MIT licence.
