# Spec format (`spec.json`)

The spec describes the app. `scripts/build.py` turns it into screens in any style. A complete example is in `examples/specs/retail-inventory.json`. Expressions use a small subset of Power Fx: field names, numbers, "strings", `+ - * /`, `= <> < <= > >=`, `&& || !`, `true` and `false`. The same expression runs in Power Apps and in the Python mock, so keep it inside that subset.

```jsonc
{
  "app": {
    "name": "Inventory Master",        // shown in the nav and on the home hero
    "tagline": "Retail · 100 stores",  // small text under the name
    "icon": "box",                     // box grid list plus search alert ban coin chart check users store doc clock
    "currency": "₹",                   // symbol for currency fields
    "numbers": "indian",               // "indian" = L / Cr, "intl" = K / M / B for compact money
    "prefix": ""                       // prepended to screen, control and variable names. Set it (e.g. "Inv") when pasting into an existing app.
  },
  "pages": ["home", "dashboard", "list", "form"],   // any subset, in this order
  "data": {
    "collection": "colItems",          // working collection that edits are saved to
    "seed": "SeedItems",               // named formula in App.Formulas holding the demo rows
    "entity": "Stock line", "entities": "Stock lines",
    "fields": [
      {"name": "Product", "label": "Product", "type": "text", "required": true, "title": true, "hint": "e.g. Cotton Crew T-Shirt"},
      {"name": "Category", "label": "Category", "type": "choice", "choices": ["Apparel", "Toys"], "filter": true},
      {"name": "Region", "label": "Region", "type": "choice", "choices": ["North", "South"], "segment": true, "plural": "Regions"},
      {"name": "Qty", "label": "On hand", "type": "number", "required": true},
      {"name": "Price", "label": "Unit price", "type": "currency", "required": true}
    ],
    "computed": [{"name": "Value", "label": "Stock value", "expr": "Qty * Price", "type": "currency"}],
    "status": {"label": "Status", "rules": [            // first match wins; the last rule should be "true"
      ["Qty = 0", "Out of stock", "bad"], ["Qty <= Reorder", "Low stock", "warn"], ["true", "In stock", "good"]]},
    "rows": [{"Product": "…", "Category": "Apparel", "Region": "North", "Qty": 12, "Price": 499}]
  },
  "list": {
    "columns": ["Product", "Category", "Qty", "Value", "StatusText"],  // 5-8 fit. StatusText is the status chip.
    "search": ["Product", "SKU"],                                     // text fields matched by the search box
    "sort": ["Product", "Qty", "Value"]                               // clickable column headers
  },
  "dashboard": {
    "kpis": [                                                         // 2-4 cards
      {"label": "Stock value", "agg": "sum", "expr": "Qty * Price", "format": "money", "icon": "coin", "note": "Units × price"},
      {"label": "Low stock", "agg": "count", "where": "Qty > 0 && Qty <= Reorder", "tone": "warn", "status": "Low stock", "note": "At or below reorder level"}
    ],                                                                // agg: sum | count | avg. format: money | currency | number. "status" makes the card open the list filtered.
    "breakdown": {"title": "Stock value by category", "by": "Category", "expr": "Qty * Price", "format": "money"},
    "ranking":   {"title": "Top stores", "by": "Store", "expr": "Qty * Price", "format": "money", "top": 7},
    "attention": {"title": "Reorder alerts", "where": "Qty <= Reorder", "sort": "Qty", "sub": "Store", "status": "Low stock"}
  },
  "home": {"headline": "Every store's stock, in one place", "lead": "One sentence on what the app does.", "sub": "Store"}
}
```

Notes

- Field `type` is one of `text`, `number`, `currency` or `choice`. Dates can be stored as `text`, for example "2026-11-09".
- `title: true` marks the main field. It is used for the default sort, list titles and the form heading.
- `segment` adds region-style pills to the dashboard and list. `filter` adds category-style pills to the list. Each needs `choices`. Keep it to 7 or fewer choices.
- A `breakdown` or `ranking` with `"expr": "1"` counts rows instead of summing.
- `sort` in `attention` can be an expression. Use `"0 - AgeHours"` to show the oldest first.
- Every row gets an `Id` automatically. Saving and deleting use `Id`.

## Swapping demo data for SharePoint or Dataverse

1. Create a list or table with the same column names. Make `Id` a number column, or switch the formulas to the built-in `ID`.
2. In each screen's `OnVisible`, delete the `If(IsEmpty(colX), ClearCollect(colX, SeedX))` line.
3. Replace `colX` with the data source name throughout. `Collect`, `Patch` and `Remove` work unchanged on SharePoint and Dataverse.
4. Watch for delegation. `Filter`, `Sort` and `in` searches on large lists may need delegable alternatives such as `StartsWith`, or indexed columns.
