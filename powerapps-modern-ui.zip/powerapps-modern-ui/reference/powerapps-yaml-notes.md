# Power Apps canvas YAML: working notes

These rules come from building and pasting this kit into Power Apps Studio (late 2026). Check them before writing new YAML.

## Paste formats

- **Whole screens:** start with `Screens:`, then `  <ScreenName>:` with `Properties:` and `Children:`. Several screens can share one `Screens:` key. Right-click any screen in the Tree view and choose **Paste** to add them as new screens.
- **Controls onto an existing screen:** a top-level list (`- <ControlName>:` with `Control:` and `Properties:`). Select the screen, then paste.
- **Layer order:** children are listed back to front. The first child is the bottom layer and the last child sits on top.
- **Formulas:** every property value starts with `=`. Use the block form `|-` (value on the next line, indented) for any formula that spans lines or contains `: `, `#` or `{`. Plain YAML breaks on those.

## Control versions that paste cleanly

`Label@2.5.1`, `Classic/Button@2.2.0`, `Image@2.2.3`, `Rectangle@2.3.0`, `Gallery@2.15.0` (with `Variant: Vertical`), `Classic/TextInput@2.3.2`.

## Properties that are rejected

- `AccessibleLabel` on `Classic/Button@2.2.0` fails with error PA2108 (unknown property). Use `Tooltip` instead.
- `RadiusTopLeft`, `RadiusTopRight`, `RadiusBottomLeft` and `RadiusBottomRight` are not valid on `Rectangle@2.3.0`. For a rounded shape, use a button or an SVG image.
- Unique control names are required across the whole app. Prefix each screen's controls (for example `Sp`, `Sa`, `La`).

## Power Fx gotchas

- `Rept()` is not available. For star ratings, use `Left("★★★★★", n) & Left("☆☆☆☆☆", 5 - n)`.
- Fonts that work everywhere: `Font.'Lato Black'`, `Font.'Segoe UI'`, `Font.Georgia`, `Font.'Courier New'`.
- `ColorValue("#" & x)` raises a runtime error while `x` is blank, for example before a gallery has a selection. Guard it with `Coalesce`.

## SVG art in formulas

- The pattern is `"data:image/svg+xml;utf8," & EncodeUrl("<svg ...>")`.
- Inside the SVG, use **single quotes only**. A double quote ends the Power Fx string.
- Put reusable art in App `Formulas` as named formulas (`TentBlue = ...;`) and use `Substitute()` on placeholder tokens for per-item colours or text.
- Images 100 KB and larger work, but Studio takes a while to parse them on paste.

## Studio behaviour

- During a big paste the Studio tab is unresponsive for one to three minutes. Wait for it rather than pasting again.
- With a control selected (not the formula bar), pressing Delete deletes the control. Undo recovers it.
- Only one session can edit an app at a time. A second tab opens read-only until you choose **Override**.

## Added for the modern UI kit

- Colours with transparency are written `RGBA(r, g, b, a)`. In `themes.py` an 8-digit hex (`rrggbbaa`) is converted to RGBA automatically.
- Card shadows, glows, gradient borders and frosted glass are drawn inside the card's SVG image. Power Apps has no CSS shadow or blur, so do not try to fake them with stacked rectangles.
- Galleries used as pill rows: `Gallery@2.15.0` Vertical with `WrapCount = number of pills` lays the pills out horizontally. Each pill is a button sized `Parent.TemplateWidth` × `Parent.TemplateHeight`.
- Rows in a gallery are clicked through a transparent button that is the last child, so it sits on top. Chips and bars inside rows use `OnSelect = false` and `TabIndex = -1`.
- `With(ThisItem, …)` and `AddColumns(collection, Name, expr, …)` (identifier syntax) are used throughout. They need a Studio version from 2024 or later.
- After a paste, open the **App checker**. Any warning about `TabIndex` or `HoverColor` is cosmetic and can be ignored.
