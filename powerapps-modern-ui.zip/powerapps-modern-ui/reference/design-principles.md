# Design principles for modern Power Apps screens

These are condensed from the design skills reviewed for this kit: Anthropic `frontend-design`, `theme-factory`, Impeccable's product-UI mode and Accesslint. They are adapted to what a canvas app can render.

## Direction before detail
- **Learn the app first.** Ask what the app is for, who uses it and where, before choosing a look. A store-floor tablet app and a CFO wallboard need different styles.
- **Commit to one named style.** Mixing two half-styles is what makes a screen look generic.
- **Treat this as product UI, not marketing.** Density, scanning and clear actions matter more than decoration. Save boldness for one element per screen.

## Tokens
- **Take every value from the style's tokens:** colour, radius, font and card treatment. Never use a one-off hex.
- **Keep 4-6 base colours:** background, surface, ink, muted ink, one accent and an optional second accent. Chart series come from `chart`. Status colours come from `good`, `warn` and `bad`.
- **Set radius by hierarchy:** cards largest, controls smaller, chips as pills. Editorial uses 0 everywhere on purpose.

## Layout (1366 × 768 tablet canvas)
- **Use a 24 px outer margin and 18 px gutters**, and align everything to them. The side nav is 232 px wide. The top nav is 64 px high, or a floating 56 px bar for glass styles.
- **One anchor per screen:**
  - Home: the hero.
  - Dashboard: the KPI row.
  - List: the table.
  - Form: the fields card, with a quiet summary card beside it.
- **Don't build the app from identical cards.** Vary sizes, and let tables and lists be real tables and lists.

## Type
- **Use one family, or two that are clearly different:** a display face for titles and KPI numbers, a body face for everything else.
- **Use a clear scale:** title 20-26, section 12-13, body 10-11, caption 8-9 (Power Apps points).
- **Write in sentence case.** No all-caps eyebrows, except in Neo-Brutalist, where monospace labels are part of the look.

## Avoiding generated-looking defaults
Avoid these unless the chosen style calls for them:
- the purple-white gradient with Inter;
- four identical cards with a faint shadow everywhere;
- an arrow appended to every link;
- numbered markers on content that isn't a sequence;
- decorative gradients that carry no information.

## Words
- **Name actions by what they do:** "Save changes", "Add stock line", "View all". Keep the same word through the flow, so "Add" leads to a "Stock line added" notification.
- **Errors say what is wrong and how to fix it:** "Unit price must be more than 0." Empty states tell people what to do next.
- **Use the user's own nouns and realistic sample data.**

## Accessibility
- **Contrast:** at least 4.5:1 for body text and 3:1 for large numbers and UI borders. Check any custom accent.
- **Status:** chips always carry text as well as colour.
- **Focus:** every clickable control has a visible focus border in the accent, and a tooltip on icon-only buttons.

## Verify
Screenshot the mocks (`scripts/shoot.py`) and look at every screen. Check for clipped text, overlapping pills, empty charts and unreadable contrast, then fix and rebuild before handing the YAML over.
