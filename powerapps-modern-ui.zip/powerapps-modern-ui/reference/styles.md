# Style catalogue

There are 30 styles. Each one is a token set in `scripts/themes.py` (the 8 modern business styles) or `scripts/styles_more.py` (the rest). The card and background art is in `scripts/art.py`. `assets/previews/<key>-<page>.jpg` has a preview of every page, and `assets/style-picker.png` puts all of them on one numbered sheet.

Sources: Futurepedia's AI Style Atlas, which gives named visual styles with descriptive prompts. Atlas styles are adapted directly where possible, and the wider Atlas categories (Retro UI & Neon, Retro Digital, Data & Information, Art & Design Movements, Dimensional, Print, Hand-Drawn) supplied the rest. Anthropic's `frontend-design` skill (commit to a direction, avoid templated defaults) and `theme-factory` (palette and font tokens chosen from a showcase) shaped the approach. Every look is limited to what Power Apps can render: Power Apps fonts, SVG art, and solid or RGBA fills.

## 1. Fluent Enterprise (`fluent`)

![Fluent Enterprise](../assets/previews/fluent-dashboard.jpg)

- **Family:** Modern business
- **Look:** Familiar Microsoft 365 look. Calm neutrals, one brand blue, compact and dependable.
- **Best for:** Internal line-of-business apps, approvals, HR / IT / finance tools, anything that sits next to Teams and SharePoint.
- **Inspired by:** Clean product UI (Fluent 2 design language)
- **Palette:** background `#f5f5f5`, surface `#ffffff`, ink `#242424`, accent `#0f6cbd`, second accent `#115ea3`
- **Type:** Segoe UI for display, Segoe UI for body. **Shape:** card radius 8, card treatment `soft`. **Nav:** `top`

## 2. Slate & Indigo (`slate`)

![Slate & Indigo](../assets/previews/slate-dashboard.jpg)

- **Family:** Modern business
- **Look:** Crisp modern SaaS. Dark sidebar, white cards with soft shadow, indigo accent, generous spacing.
- **Best for:** Dashboards, admin consoles, inventory / CRM / ticketing masters.
- **Inspired by:** Modern SaaS dashboard
- **Palette:** background `#f1f5f9`, surface `#ffffff`, ink `#0f172a`, accent `#4f46e5`, second accent `#4338ca`
- **Type:** Segoe UI for display, Segoe UI for body. **Shape:** card radius 14, card treatment `soft`. **Nav:** `side-dark`

## 3. Midnight Glow (`midnight`)

![Midnight Glow](../assets/previews/midnight-dashboard.jpg)

- **Family:** Modern business
- **Look:** Dark command-centre. Deep navy, faint grid, violet and cyan glows, neon-edged glass panels.
- **Best for:** Ops / monitoring dashboards, IT and security consoles, data-heavy screens shown on big displays.
- **Inspired by:** Tech Glow Explainer (AI Style Atlas)
- **Palette:** background `#070b1a`, surface `#0f1630`, ink `#eef1ff`, accent `#7c5cff`, second accent `#22d3ee`
- **Type:** Segoe UI for display, Segoe UI for body. **Shape:** card radius 16, card treatment `glow`. **Nav:** `side-dark`

## 4. Aurora Glass (`aurora`)

![Aurora Glass](../assets/previews/aurora-dashboard.jpg)

- **Family:** Modern business
- **Look:** Airy and optimistic. Soft aurora gradient backdrop with frosted white glass cards and a floating top bar.
- **Best for:** Employee portals, self-service apps, booking and request apps, home / landing screens.
- **Inspired by:** Glassmorphism on gradient mesh
- **Palette:** background `#f6f5fb`, surface `#ffffff`, ink `#1e1b3a`, accent `#5b3df5`, second accent `#db2777`
- **Type:** Lato Black for display, Lato for body. **Shape:** card radius 22, card treatment `glass`. **Nav:** `top`

## 5. Soft Pastel (`pastel`)

![Soft Pastel](../assets/previews/pastel-dashboard.jpg)

- **Family:** Modern business
- **Look:** Friendly and rounded. Pastel colour blocks, big radii, a single coral accent, no hard borders.
- **Best for:** Retail floor, education, wellbeing, onboarding and front-line apps used on tablets.
- **Inspired by:** Isometric Pastel (AI Style Atlas)
- **Palette:** background `#eef0fa`, surface `#ffffff`, ink `#2b2d42`, accent `#ff6b5b`, second accent `#2b2d42`
- **Type:** Lato Black for display, Open Sans for body. **Shape:** card radius 24, card treatment `tint`. **Nav:** `side-light`

## 6. Editorial Paper (`editorial`)

![Editorial Paper](../assets/previews/editorial-dashboard.jpg)

- **Family:** Modern business
- **Look:** Magazine layout. Warm grainy paper, Georgia serif headlines, hairline rules, a highlighter accent.
- **Best for:** Reports and briefings, knowledge bases, policy / content apps, executive summaries.
- **Inspired by:** Editorial Essay Collage (AI Style Atlas)
- **Palette:** background `#efeadf`, surface `#faf7f0`, ink `#1a1a1a`, accent `#1a1a1a`, second accent `#c8102e`
- **Type:** Georgia for display, Segoe UI for body. **Shape:** card radius 0, card treatment `rule`. **Nav:** `top`

## 7. Neo-Brutalist (`brutal`)

![Neo-Brutalist](../assets/previews/brutal-dashboard.jpg)

- **Family:** Modern business
- **Look:** Loud and confident. Thick black outlines, hard offset shadows, saturated blocks, monospace labels.
- **Best for:** Creative teams, campaigns, events, start-up tools, anything that should feel energetic and un-corporate.
- **Inspired by:** Halftone Pop Panel / bold print
- **Palette:** background `#fff8e7`, surface `#ffffff`, ink `#000000`, accent `#2f5bff`, second accent `#ff5ca8`
- **Type:** Lato Black for display, Lato for body. **Shape:** card radius 10, card treatment `offset`. **Nav:** `side-light`

## 8. Keynote Noir (`keynote`)

![Keynote Noir](../assets/previews/keynote-dashboard.jpg)

- **Family:** Modern business
- **Look:** Product-launch stage. Near-black, spotlight gradient, oversized light-weight numbers, hairline panels.
- **Best for:** Executive / CEO dashboards, sales leaderboards, kiosk and wallboard screens.
- **Inspired by:** Product Launch Reveal (AI Style Atlas)
- **Palette:** background `#000000`, surface `#111114`, ink `#f5f5f7`, accent `#2997ff`, second accent `#bf5af2`
- **Type:** Lato Light for display, Segoe UI for body. **Shape:** card radius 18, card treatment `hairline`. **Nav:** `top`

## 9. Papercraft Models (`papercraft`)

![Papercraft Models](../assets/previews/papercraft-dashboard.jpg)

- **Family:** Atlas · Popular Explainer Looks
- **Look:** Printed-cardstock cards with dotted fold lines and soft shadows on a green self-healing cutting mat.
- **Best for:** Retail and toy shops, maker / craft brands, kids' and education apps, playful internal tools.
- **Inspired by:** Papercraft Models
- **Palette:** background `#3f7d4f`, surface `#f5f0e4`, ink `#22252d`, accent `#ee6b2d`, second accent `#2f6db3`
- **Type:** Lato Black for display, Segoe UI for body. **Shape:** card radius 4, card treatment `paper`. **Nav:** `side-light`

## 10. Flat-Vector Science (`flatvector`)

![Flat-Vector Science](../assets/previews/flatvector-dashboard.jpg)

- **Family:** Atlas · Popular Explainer Looks
- **Look:** Navy-to-violet space, flat shapes with soft gradients, a ringed planet and star field, warm amber accents.
- **Best for:** Science, education and STEM apps, product catalogues, onboarding and anything that should feel curious.
- **Inspired by:** Flat-Vector Science
- **Palette:** background `#141a52`, surface `#1f2466`, ink `#f4f2ff`, accent `#ffb547`, second accent `#4fd1c5`
- **Type:** Lato Black for display, Open Sans for body. **Shape:** card radius 20, card treatment `tint`. **Nav:** `side-dark`

## 11. Watercolor Wash (`watercolor`)

![Watercolor Wash](../assets/previews/watercolor-dashboard.jpg)

- **Family:** Atlas · Painterly
- **Look:** Cold-press paper with transparent watercolour washes bleeding behind calm white panels and serif headings.
- **Best for:** Wellbeing, hospitality, events, non-profit and community apps.
- **Inspired by:** Watercolor Wash
- **Palette:** background `#fbfaf6`, surface `#ffffff`, ink `#2d3142`, accent `#3a6ea5`, second accent `#e59aa8`
- **Type:** Georgia for display, Open Sans for body. **Shape:** card radius 6, card treatment `wash`. **Nav:** `top`

## 12. Shadow Puppet Theatre (`shadowpuppet`)

![Shadow Puppet Theatre](../assets/previews/shadowpuppet-dashboard.jpg)

- **Family:** Atlas · Paper & Craft
- **Look:** Black cut-out panels with punched lace edges against a lamp-lit amber cloth screen.
- **Best for:** Storytelling, culture and heritage, festivals, hospitality and evening / ambient displays.
- **Inspired by:** Shadow Puppet Theatre
- **Palette:** background `#7a2e12`, surface `#140b07`, ink `#ffe7c2`, accent `#ffb347`, second accent `#ff7b39`
- **Type:** Georgia for display, Segoe UI for body. **Shape:** card radius 14, card treatment `cutout`. **Nav:** `side-dark`

## 13. Whiteboard Explainer (`whiteboard`)

![Whiteboard Explainer](../assets/previews/whiteboard-dashboard.jpg)

- **Family:** Atlas · Hand-Drawn
- **Look:** Glossy whiteboard, wobbly marker outlines, handwriting font and red / blue marker accents.
- **Best for:** Training and workshops, planning tools, team boards, classroom apps.
- **Inspired by:** Whiteboard Explainer
- **Palette:** background `#f3f5f4`, surface `#ffffff`, ink `#1f2a37`, accent `#1c4fd8`, second accent `#e03131`
- **Type:** Patrick Hand for display, Patrick Hand for body. **Shape:** card radius 12, card treatment `sketch`. **Nav:** `top`

## 14. Psychedelic Poster (`psychedelic`)

![Psychedelic Poster](../assets/previews/psychedelic-dashboard.jpg)

- **Family:** Atlas · Cosmic & Psychedelic
- **Look:** 1960s concert-poster rings in vibrating orange, pink and violet behind cream panels with double borders.
- **Best for:** Music, festivals, youth marketing, creative studios. Use when the app should shout.
- **Inspired by:** Psychedelic Poster
- **Palette:** background `#2a0a3d`, surface `#fff1d6`, ink `#2a0a3d`, accent `#ff2e88`, second accent `#7b2ff7`
- **Type:** Lato Black for display, Lato for body. **Shape:** card radius 26, card treatment `ring`. **Nav:** `side-light`

## 15. 1940s Film Noir (`noir`)

![1940s Film Noir](../assets/previews/noir-dashboard.jpg)

- **Family:** Atlas · Light & Imaging
- **Look:** High-contrast black and white, venetian-blind light across the screen, film grain, Georgia headlines.
- **Best for:** Security, audit and investigations, legal / compliance, moody executive views.
- **Inspired by:** 1940s Film Noir
- **Palette:** background `#0c0c0c`, surface `#141414`, ink `#f0f0f0`, accent `#f0f0f0`, second accent `#b8b8b8`
- **Type:** Georgia for display, Segoe UI for body. **Shape:** card radius 2, card treatment `hairline`. **Nav:** `top`

## 16. Manim-Style Math (`manim`)

![Manim-Style Math](../assets/previews/manim-dashboard.jpg)

- **Family:** Atlas · Popular Explainer Looks
- **Look:** Pure black canvas, crisp thin outlines, LaTeX-like serif headings and the blue / teal / yellow / red maths palette.
- **Best for:** Analytics and finance models, engineering, data-science and forecasting tools.
- **Inspired by:** Manim-Style Math
- **Palette:** background `#000000`, surface `#000000`, ink `#ffffff`, accent `#58c4dd`, second accent `#ffff66`
- **Type:** Georgia for display, Segoe UI for body. **Shape:** card radius 0, card treatment `frame`. **Nav:** `top`

## 17. Illuminated Manuscript (`manuscript`)

![Illuminated Manuscript](../assets/previews/manuscript-dashboard.jpg)

- **Family:** Atlas · Illustration
- **Look:** Mottled vellum, iron-gall ink, vermilion rubrics and gold double borders with corner bezants.
- **Best for:** Heritage, libraries and archives, ceremonies, premium / luxury brands, certificates.
- **Inspired by:** Illuminated Manuscript
- **Palette:** background `#f1e3c2`, surface `#f8eed6`, ink `#2a1d12`, accent `#b3261e`, second accent `#c9a227`
- **Type:** Georgia for display, Georgia for body. **Shape:** card radius 0, card treatment `illum`. **Nav:** `top`

## 18. Bioluminescent Deep Sea (`deepsea`)

![Bioluminescent Deep Sea](../assets/previews/deepsea-dashboard.jpg)

- **Family:** Atlas · Light & Imaging
- **Look:** Near-black water with drifting marine snow; panels glow cyan and magenta like deep-sea creatures.
- **Best for:** Environmental and energy monitoring, IoT and sensor dashboards, night-shift operations.
- **Inspired by:** Bioluminescent Deep Sea
- **Palette:** background `#00121a`, surface `#03222c`, ink `#e3fbff`, accent `#22e1ff`, second accent `#ff4fd8`
- **Type:** Segoe UI for display, Segoe UI for body. **Shape:** card radius 18, card treatment `glow`. **Nav:** `side-dark`

## 19. Halftone Pop Panel (`halftone`)

![Halftone Pop Panel](../assets/previews/halftone-dashboard.jpg)

- **Family:** Atlas · Print
- **Look:** Comic-panel look: thick black outlines, red Ben-Day dot shadows, flat primary yellow and blue.
- **Best for:** Marketing, promotions and retail campaigns, gamified apps, youth audiences.
- **Inspired by:** Halftone Pop Panel
- **Palette:** background `#ffe14d`, surface `#ffffff`, ink `#000000`, accent `#1f5bd8`, second accent `#e10600`
- **Type:** Lato Black for display, Lato for body. **Shape:** card radius 0, card treatment `halftone`. **Nav:** `top`

## 20. Synthwave Neon (`synthwave`)

![Synthwave Neon](../assets/previews/synthwave-dashboard.jpg)

- **Family:** Retro UI & Neon
- **Look:** 80s outrun: striped sunset, magenta perspective grid, neon-edged panels on deep purple.
- **Best for:** Gaming, entertainment, music and nightlife, hackathons, fun internal leaderboards.
- **Inspired by:** Retro UI & Neon category
- **Palette:** background `#1a0533`, surface `#1a0830`, ink `#fdeaff`, accent `#ff2fd2`, second accent `#22e6ff`
- **Type:** Lato Black for display, Segoe UI for body. **Shape:** card radius 10, card treatment `neon`. **Nav:** `side-dark`

## 21. Retro Desktop '95 (`retroos`)

![Retro Desktop '95](../assets/previews/retroos-dashboard.jpg)

- **Family:** Retro UI & Neon
- **Look:** Teal desktop, silver bevelled windows, navy highlights and Verdana: nostalgic and instantly readable.
- **Best for:** Fun internal tools, IT teams, retro-themed campaigns, kiosks that must look clickable.
- **Inspired by:** Retro UI category
- **Palette:** background `#008080`, surface `#c0c0c0`, ink `#000000`, accent `#000080`, second accent `#800080`
- **Type:** Verdana for display, Verdana for body. **Shape:** card radius 0, card treatment `bevel`. **Nav:** `top`

## 22. Pixel Arcade (`pixel`)

![Pixel Arcade](../assets/previews/pixel-dashboard.jpg)

- **Family:** Retro Digital
- **Look:** 8-bit night sky, stepped pixel-corner panels with bright borders and monospace type.
- **Best for:** Gamification, learning and rewards apps, kids' clubs, playful team trackers.
- **Inspired by:** Retro Digital category
- **Palette:** background `#1a1433`, surface `#241c48`, ink `#ffffff`, accent `#ffcc00`, second accent `#ff4d6d`
- **Type:** Courier New for display, Courier New for body. **Shape:** card radius 0, card treatment `pixel`. **Nav:** `side-dark`

## 23. Green Terminal (`terminal`)

![Green Terminal](../assets/previews/terminal-dashboard.jpg)

- **Family:** Retro Digital
- **Look:** Phosphor-green text on a black CRT with scanlines; every panel is a thin glowing frame.
- **Best for:** Developer and DevOps tools, network / server status, hacker-style ops consoles.
- **Inspired by:** Retro Digital category
- **Palette:** background `#010502`, surface `#020a04`, ink `#9dff9d`, accent `#39ff14`, second accent `#ffd23f`
- **Type:** Courier New for display, Courier New for body. **Shape:** card radius 0, card treatment `frame`. **Nav:** `top`

## 24. Blueprint (`blueprint`)

![Blueprint](../assets/previews/blueprint-dashboard.jpg)

- **Family:** Data & Information
- **Look:** Engineering blueprint: cyan-blue grid paper, dashed white frames with corner ticks, yellow highlights.
- **Best for:** Facilities, construction, engineering, field service and asset management.
- **Inspired by:** Data & Information category
- **Palette:** background `#0d4f8b`, surface `#0f5a9c`, ink `#ffffff`, accent `#ffd43b`, second accent `#ffffff`
- **Type:** Courier New for display, Segoe UI for body. **Shape:** card radius 0, card treatment `dashed`. **Nav:** `top`

## 25. Bauhaus (`bauhaus`)

![Bauhaus](../assets/previews/bauhaus-dashboard.jpg)

- **Family:** Art & Design Movements
- **Look:** Primary red, blue and yellow geometry on warm paper; flat white panels, black type, no ornament.
- **Best for:** Design-led brands, architecture, museums, culture and any app wanting a confident, geometric look.
- **Inspired by:** Art & Design Movements category
- **Palette:** background `#f2ead8`, surface `#ffffff`, ink `#111111`, accent `#e63322`, second accent `#1f4fa3`
- **Type:** Lato Black for display, Lato for body. **Shape:** card radius 0, card treatment `tint`. **Nav:** `side-light`

## 26. Swiss Grid (`swiss`)

![Swiss Grid](../assets/previews/swiss-dashboard.jpg)

- **Family:** Art & Design Movements
- **Look:** International Typographic Style: pure white, strict grid, black rules, bold sans and a single red.
- **Best for:** Corporate reporting, finance, consulting, public sector and documentation apps.
- **Inspired by:** Art & Design Movements category
- **Palette:** background `#ffffff`, surface `#ffffff`, ink `#000000`, accent `#ff2a1a`, second accent `#000000`
- **Type:** Open Sans for display, Open Sans for body. **Shape:** card radius 0, card treatment `rule`. **Nav:** `top`

## 27. Claymorphism (`clay`)

![Claymorphism](../assets/previews/clay-dashboard.jpg)

- **Family:** Dimensional
- **Look:** Puffy 3D clay panels with inner highlights and soft coloured shadows on a candy gradient.
- **Best for:** Consumer-style employee apps, wellbeing, rewards, onboarding and kids' learning.
- **Inspired by:** Dimensional category
- **Palette:** background `#ffe8f1`, surface `#ffffff`, ink `#2b2350`, accent `#7c5cff`, second accent `#ff7eb6`
- **Type:** Lato Black for display, Open Sans for body. **Shape:** card radius 28, card treatment `clay`. **Nav:** `side-light`

## 28. Risograph Print (`risograph`)

![Risograph Print](../assets/previews/risograph-dashboard.jpg)

- **Family:** Print
- **Look:** Two-colour riso print: fluoro pink and blue, slightly misregistered outlines, grainy off-white stock.
- **Best for:** Creative agencies, zines and media, community events, start-ups with personality.
- **Inspired by:** Print category
- **Palette:** background `#f6f1e7`, surface `#fffdf8`, ink `#1b2a6b`, accent `#0078bf`, second accent `#ff48b0`
- **Type:** Lato Black for display, Lato for body. **Shape:** card radius 4, card treatment `riso`. **Nav:** `top`

## 29. Chalkboard (`chalkboard`)

![Chalkboard](../assets/previews/chalkboard-dashboard.jpg)

- **Family:** Hand-Drawn
- **Look:** Dusty green chalkboard, chalk-line panels drawn by hand, warm yellow chalk for highlights.
- **Best for:** Schools and training, cafés and menus, coaching, team stand-ups.
- **Inspired by:** Hand-Drawn category
- **Palette:** background `#26372d`, surface `#2b3f33`, ink `#f4f1e8`, accent `#ffd166`, second accent `#ff8fa3`
- **Type:** Patrick Hand for display, Patrick Hand for body. **Shape:** card radius 10, card treatment `sketch`. **Nav:** `side-dark`

## 30. Art Deco (`artdeco`)

![Art Deco](../assets/previews/artdeco-dashboard.jpg)

- **Family:** Art & Design Movements
- **Look:** Midnight navy with gold fan patterns, double gold frames with stepped corners and Georgia capitals.
- **Best for:** Luxury retail, hotels, banking and wealth, premium memberships and VIP dashboards.
- **Inspired by:** Art & Design Movements category
- **Palette:** background `#0e1a2b`, surface `#132339`, ink `#f4ead2`, accent `#d4af37`, second accent `#2f8f83`
- **Type:** Georgia for display, Segoe UI for body. **Shape:** card radius 0, card treatment `deco`. **Nav:** `top`
