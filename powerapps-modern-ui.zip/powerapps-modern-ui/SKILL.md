---
name: powerapps-modern-ui
description: Generate modern, good-looking Power Apps canvas screens as copy-and-paste YAML. Use when someone wants a Power App, Power Apps screens or pa.yaml, wants an existing Power App to look modern, or points you at this repo. You ask what they are building, show style samples of their own app, and once they pick a style you produce paste-ready YAML for home, dashboard, list and form screens.
---

# Power Apps Modern UI

This skill turns a short description of an app into paste-ready Power Apps canvas YAML (tablet, 1366 x 768) in one of 30 styles: 8 modern business looks, 11 from Futurepedia's AI Style Atlas (Papercraft, Flat-Vector Science, Watercolor, Shadow Puppet, Whiteboard, Psychedelic, Film Noir, Manim Math, Illuminated Manuscript, Deep Sea, Halftone Pop) and 11 more from the Atlas families (Synthwave, Retro Desktop, Pixel, Terminal, Blueprint, Bauhaus, Swiss, Claymorphism, Risograph, Chalkboard, Art Deco). All art is inline SVG and data starts as a named-formula seed, so the screens work as soon as they are pasted. They don't need images, connectors or premium licences.

Repo layout:

```
scripts/build.py         spec JSON -> App.Formulas.txt + <Screen>.pa.yaml + paste.html + sample-data.csv (+ mock_*.html); --source ListName for SharePoint
scripts/make_ready.py    docs/ready-to-use.html: every style's YAML (demo + SharePoint) and the CSV in one offline page
docs/                    how-to PDF, ready-to-use.html, sample-data.csv
scripts/compare.py       render one spec in several styles -> numbered comparison image to show the user
scripts/shoot.py         screenshot mock_*.html (Playwright)
scripts/make_gallery.py  rebuild examples/, assets/previews/, assets/style-picker.png, gallery/index.html
scripts/{pa,ui,pages,themes,styles_more,art}.py   control builders, components, page templates, style tokens, SVG card/background art
assets/style-picker.png  all 30 styles on one numbered sheet
assets/previews/         <style>-<page>.jpg and .html for every style and page
examples/specs/*.json    example specs (retail inventory, IT service desk)
examples/<spec>/<style>/ ready-made output for every example and style
reference/               spec format, style catalogue, design rules, Power Apps YAML gotchas
```

Setup, when the repo has been cloned somewhere: `pip install pyyaml pillow playwright` (skip what is already installed; Chromium must be available to Playwright for previews). The YAML itself needs only Python 3 + pyyaml.

## Workflow: always in this order

### 1. Ask what they want to build (first question, every time)

Before showing any style, find out what the app is for. Ask the questions below in one go, with the AskUserQuestion tool if you have it and in plain text if you don't. Offer quick options and let the user type their own.

- **What is the app for?** For example inventory or stock, requests or tickets, assets, sales or CRM, HR or onboarding, field inspections, or "other: describe it".
- **Who uses it, and where?** Office desktop, store floor or field tablet, wall display, or executives.
- **Which screens?** Home, Dashboard, List (search, filter, sort) and Form (add or edit). The default is all four.
- **Main record and its fields.** Ask what one row is (a stock line, a ticket) and the 5-8 fields that matter. If they don't know, propose fields yourself and confirm.
- **Brand.** Ask for an app name, an accent colour (hex) and the currency, or say "none".

If the user already described the app, don't re-ask what you know. Confirm it in one line and ask only what's missing.

### 2. Write the spec

Write `spec.json` following `reference/spec-format.md`, using the user's real nouns, fields, choices and statuses. Invent 30-60 realistic sample rows, enough for the charts and alerts to look alive. Pick:

- a `segment` field for the dashboard filter pills, such as region, site or priority;
- a `filter` field for the list's filter pills, such as category or team;
- status `rules` that drive coloured chips, KPI jumps and alerts;
- 2-4 KPIs, a `breakdown`, a `ranking` and an `attention` list for the dashboard.

Start from the closest file in `examples/specs/`.

### 3. Recommend styles and show samples of their app

Choose the **3-4 styles** that best fit what they told you, using the table below and `reference/styles.md`. Then render their own spec in those styles:

```bash
python scripts/compare.py spec.json --styles slate,aurora,midnight --page dashboard --out compare
```

Show the user `compare/compare-dashboard.png` by sending the image file. Also mention that `assets/style-picker.png` and `gallery/index.html` show all 30 styles if they want to browse. Mix one safe choice with one or two bolder ones. Add one line per option saying why it suits their app. Then ask them to pick. Use AskUserQuestion with your 3-4 recommendations as options; "Other" covers the remaining styles or a custom look.

| What they're building | Recommend first | Bolder alternatives |
|---|---|---|
| Internal business tools, approvals, anything next to Teams/SharePoint | fluent, slate | swiss, editorial |
| Admin / master data / inventory / CRM | slate, fluent | midnight, blueprint, papercraft (retail) |
| Ops monitoring, IT/security, wallboards | midnight, keynote | deepsea, terminal, synthwave |
| Executive / sales KPI boards, kiosks | keynote, swiss | artdeco, noir, editorial |
| Finance, analytics, forecasting | swiss, manim | keynote, editorial |
| Employee self-service, booking, portals, onboarding | aurora, pastel | clay, watercolor |
| Front-line, store-floor and education tablets | pastel, clay | papercraft, flatvector, chalkboard |
| Training, workshops, planning, classrooms | whiteboard, chalkboard | pastel, flatvector |
| Science / STEM / product catalogues | flatvector, slate | manim, papercraft |
| Facilities, construction, field service, assets | blueprint, fluent | retroos, slate |
| Heritage, culture, luxury, hospitality | manuscript, artdeco | shadowpuppet, watercolor |
| Creative teams, marketing, events, youth | brutal, risograph | halftone, psychedelic, bauhaus |
| Gaming, rewards, gamification, fun internal tools | pixel, synthwave | retroos, halftone |
| Security, audit, investigations | noir, terminal | midnight |

The full catalogue with moods and palettes is in `reference/styles.md`.

If the user can't run Python and you can't either, show `assets/style-picker.png` and the `assets/previews/*` images instead.

### 4. Generate the copy-and-paste YAML

```bash
python scripts/build.py spec.json --style <picked> --out out/<app>
python scripts/shoot.py out/<app>/mock_*.html   # check every screen yourself before handing over
```

Look at every screenshot. Fix anything clipped, overlapping or empty, either in the spec (shorter labels, fewer columns or choices) or in the templates, then rebuild. After that:

- Ask the user whether they want **demo data** (it runs instantly, but edits aren't kept) or a **SharePoint list** (edits are kept). For SharePoint, rebuild with `--source <ListName>`. Then give them `out/<app>/sample-data.csv` and these steps:
  1. In Microsoft Lists, choose **New list → From CSV**.
  2. Set number and currency fields to **Number** and every other field to **Single line of text**.
  3. Keep the column names, and name the list `<ListName>`.
  4. In Power Apps, choose **Data → Add data → SharePoint**, then paste the screens. There is no App.Formulas block in this mode.
- Give the user `out/<app>/paste.html`. It holds every file in paste order, each with a Copy button. If you can publish a hosted page or artifact, publish paste.html so they get a link. Also attach the raw `App.Formulas.txt` and `*.pa.yaml` files.
- Include the paste steps:
  1. Blank canvas app, **Tablet** format.
  2. Tree view → **App** → **Formulas** → paste `App.Formulas.txt`.
  3. Right-click any screen → **Paste** each `.pa.yaml`. Studio may freeze for up to a minute.
  4. Drag the first screen to the top, delete Screen1, save, press Play.
- Say plainly that the data is a demo seed held in a collection. To keep data, they create a SharePoint list or Dataverse table with the same columns and replace the collection name. Offer to do that wiring.

### 5. Iterate

For changes such as "make the accent green", "add a field" or "drop the home screen", edit the spec (or `--style`), rebuild and re-shoot. For a custom brand colour, copy the closest style in `scripts/themes.py` under a new key, change `acc`, `acc_soft` and `acc2` (keep contrast at least 4.5:1 for text on `acc`), and rebuild.

## Rules that keep it modern (summary of reference/design-principles.md)

- **Tokens first.** Every colour, radius and font comes from the style in `themes.py`. Never hard-code a one-off hex in a page.
- **One visual anchor per screen**, such as the hero, the KPI row or the table. Keep everything else quiet.
- **Status is never colour-only.** Chips always carry text.
- **Write labels in sentence case.** Name buttons by what they do ("Save changes", not "Submit") and give errors a fix ("Unit price must be more than 0.").
- **Use real content.** Write plausible names and numbers from the user's domain, not lorem ipsum.
- **Verify by screenshot** before you hand anything over. A model cannot grade a layout it hasn't looked at.

## Power Apps limits to respect (details in reference/powerapps-yaml-notes.md)

- **Control versions:** `Label@2.5.1`, `Classic/Button@2.2.0`, `Image@2.2.3`, `Rectangle@2.3.0`, `Gallery@2.15.0` (Vertical), `Classic/TextInput@2.3.2`.
- **Rounded shapes** are SVG images or buttons. Rectangles have no corner radius.
- **SVG strings** use single quotes only.
- **Control names** must be unique across the whole app. Set `app.prefix` in the spec when adding screens to an existing app.
- **Fonts:** Segoe UI, Open Sans, Lato, Lato Black, Lato Light, Georgia, Courier New and Verdana. The whiteboard and chalkboard styles also use Patrick Hand, which is in the Power Apps font list. If a tenant rejects it, replace `Font.'Patrick Hand'` with `Font.'Segoe UI'`.
