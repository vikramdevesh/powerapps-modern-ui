"""Core: Power Apps canvas controls -> paste-ready pa.yaml, plus an HTML mock renderer for visual checks.

Every builder returns a Ctl. A Ctl carries the Power Fx properties (what gets pasted) and a `pv`
dict (what the HTML mock shows). Geometry values may be ints or (formula, preview_number) tuples.
Control versions and property names here are ones known to paste cleanly (see reference/powerapps-yaml-notes.md).
"""
import html, urllib.parse

LBL, BTN, IMG, RECT, GAL, TXT = "Label@2.5.1", "Classic/Button@2.2.0", "Image@2.2.3", "Rectangle@2.3.0", "Gallery@2.15.0", "Classic/TextInput@2.3.2"

# Power Apps font enum -> CSS used in mocks. Only fonts that exist in every Power Apps tenant.
FONTS = {
    "Segoe UI": ("Font.'Segoe UI'", '"Segoe UI","Selawik","Open Sans",system-ui,sans-serif'),
    "Open Sans": ("Font.'Open Sans'", '"Open Sans",sans-serif'),
    "Lato": ("Font.Lato", '"Lato",sans-serif'),
    "Lato Black": ("Font.'Lato Black'", '"Lato",sans-serif'),
    "Lato Light": ("Font.'Lato Light'", '"Lato",sans-serif'),
    "Georgia": ("Font.Georgia", 'Georgia,"Times New Roman",serif'),
    "Courier New": ("Font.'Courier New'", '"Courier New",Courier,monospace'),
    "Verdana": ("Font.Verdana", "Verdana,sans-serif"),
    "Patrick Hand": ("Font.'Patrick Hand'", '"Patrick Hand","Segoe Print","Comic Sans MS",sans-serif'),
    "Open Sans Condensed": ("Font.'Open Sans Condensed'", '"Open Sans",sans-serif'),
}
CSS_WEIGHT_OVERRIDE = {"Lato Black": 900, "Lato Light": 300}
W8 = {"light": ("FontWeight.Lighter", 300), "normal": ("FontWeight.Normal", 400), "semi": ("FontWeight.Semibold", 600), "bold": ("FontWeight.Bold", 700)}


class Ctl:
    def __init__(s, name, typ, geo, props, pv=None, children=None, variant=None):
        s.name, s.typ, s.geo, s.props, s.pv, s.children, s.variant = name, typ, geo, props, pv or {}, children, variant


def g(v): return v if isinstance(v, tuple) else (str(v), v)
def gv(v): return g(v)[1]
def hexc(h): return h.lstrip("#")
def col(h):
    h = hexc(h)
    if len(h) == 8:  # rrggbbaa
        r, gg, b, a = (int(h[i:i + 2], 16) for i in (0, 2, 4, 6))
        return f"RGBA({r}, {gg}, {b}, {round(a / 255, 3)})"
    return f'ColorValue("#{h}")'
def css(h):
    h = hexc(h)
    if len(h) == 8:
        r, gg, b, a = (int(h[i:i + 2], 16) for i in (0, 2, 4, 6)); return f"rgba({r},{gg},{b},{round(a / 255, 3)})"
    return "#" + h
def pfx_str(s): return '"' + s.replace('"', '""') + '"'
def svgfx(s):
    assert '"' not in s, "SVG must use single quotes only: " + s[:80]
    return '"data:image/svg+xml;utf8," & EncodeUrl("' + s + '")'
def uri(s): return "data:image/svg+xml;utf8," + urllib.parse.quote(s)


def _radius(p, r):
    for k in ("RadiusTopLeft", "RadiusTopRight", "RadiusBottomLeft", "RadiusBottomRight"): p[k] = str(r)


def label(name, geo, fx, pv, size=12, font="Segoe UI", weight="normal", color="000000", align="Left", valign="Middle",
          wrap=False, color_fx=None, pvcolor=None, visible=None, pvhide=False, fill=None, fill_fx=None, italic=False, upper_pv=False, pad=0):
    p = {"Text": fx, "Font": FONTS[font][0], "FontWeight": W8[weight][0], "Size": str(size), "Color": color_fx or col(color),
         "Align": f"Align.{align}", "VerticalAlign": f"VerticalAlign.{valign}",
         "PaddingLeft": str(pad), "PaddingRight": str(pad), "PaddingTop": "0", "PaddingBottom": "0"}
    if not wrap: p["Wrap"] = "false"
    if italic: p["Italic"] = "true"
    if fill_fx or fill: p["Fill"] = fill_fx or col(fill)
    if visible: p["Visible"] = visible
    return Ctl(name, LBL, geo, p, dict(kind="lbl", text=pv, size=size, font=font, w=W8[weight][1], color=pvcolor or color, align=align,
                                       valign=valign, wrap=wrap, hide=pvhide, fill=fill, italic=italic, pad=pad))


def button(name, geo, fx, pv, onselect, fill="000000", color="ffffff", size=12, font="Segoe UI", weight="semi", radius=8,
           border=None, bthick=1, align="Center", pad=0, fill_fx=None, color_fx=None, border_fx=None, pvfill=None, pvcolor=None,
           pvborder=None, visible=None, pvhide=False, hover_fx=None, tip=None, extra=None, focus="000000"):
    p = {"Text": fx, "Fill": fill_fx or col(fill), "Color": color_fx or col(color),
         "HoverFill": hover_fx or "ColorFade(Self.Fill, -0.08)", "PressedFill": "ColorFade(Self.Fill, -0.16)",
         "HoverColor": "Self.Color", "PressedColor": "Self.Color",
         "Font": FONTS[font][0], "FontWeight": W8[weight][0], "Size": str(size), "Align": f"Align.{align}",
         "PaddingLeft": str(pad), "PaddingRight": "0",
         "BorderThickness": str(bthick) if (border or border_fx) else "0", "FocusedBorderThickness": "2", "FocusedBorderColor": col(focus),
         "OnSelect": onselect}
    _radius(p, radius)
    if border or border_fx: p["BorderColor"] = border_fx or col(border); p["HoverBorderColor"] = "Self.BorderColor"
    if tip: p["Tooltip"] = pfx_str(tip)
    if visible: p["Visible"] = visible
    if extra: p.update(extra)
    return Ctl(name, BTN, geo, p, dict(kind="btn", text=pv, fill=pvfill or fill, color=pvcolor or color, size=size, font=font,
                                       w=W8[weight][1], r=radius, border=pvborder or border, bthick=bthick, align=align, pad=pad, hide=pvhide))


def hit(name, geo, onselect, tip, hover="RGBA(0, 0, 0, 0.04)", radius=8, visible=None, focus="000000"):
    """Transparent click target placed on top of a group of controls (last child = top layer)."""
    p = {"Text": '""', "Fill": "RGBA(0, 0, 0, 0)", "HoverFill": hover, "PressedFill": "RGBA(0, 0, 0, 0.08)",
         "BorderThickness": "0", "FocusedBorderThickness": "2", "FocusedBorderColor": col(focus), "Tooltip": pfx_str(tip), "OnSelect": onselect}
    _radius(p, radius)
    if visible: p["Visible"] = visible
    return Ctl(name, BTN, geo, p, dict(kind="none"))


def image(name, geo, fx, pvsvg, pos="Fit", visible=None, pvhide=False):
    p = {"Image": fx, "ImagePosition": f"ImagePosition.{pos}", "BorderThickness": "0"}
    if visible: p["Visible"] = visible
    return Ctl(name, IMG, geo, p, dict(kind="img", svg=pvsvg, pos=pos, hide=pvhide))


def svg(name, geo, s, pos="Fit", visible=None, pvhide=False):
    return image(name, geo, svgfx(s), s, pos, visible, pvhide)


def rect(name, geo, fill, fill_fx=None, visible=None, pvhide=False, onselect=None, pvfill=None):
    p = {"Fill": fill_fx or col(fill)}
    if visible: p["Visible"] = visible
    if onselect: p["OnSelect"] = onselect
    return Ctl(name, RECT, geo, p, dict(kind="rect", fill=css(pvfill or fill), hide=pvhide))


def textinput(name, geo, default, hint, pv="", T=None, numeric=False, mode=None, align="Left", size=12, pvview=False, padleft=12):
    t = T or {}
    p = {"Default": default, "HintText": pfx_str(hint), "Font": FONTS[t.get("font_body", "Segoe UI")][0], "Size": str(size),
         "Color": col(t.get("ink", "111111")), "Fill": col(t.get("input_bg", "ffffff")), "BorderColor": col(t.get("input_line", "cccccc")),
         "HoverBorderColor": col(t.get("ink2", "888888")), "FocusedBorderColor": col(t.get("acc", "000000")),
         "BorderThickness": str(t.get("input_bthick", 1)), "FocusedBorderThickness": "2", "PaddingLeft": str(padleft), "Align": f"Align.{align}",
         "DisabledFill": col(t.get("surface2", "f5f5f5")), "DisabledColor": col(t.get("ink2", "666666")), "DisabledBorderColor": col(t.get("line", "dddddd"))}
    _radius(p, t.get("r_ctrl", 8))
    if numeric: p["Format"] = "TextFormat.Number"
    if mode: p["DisplayMode"] = mode
    return Ctl(name, TXT, geo, p, dict(kind="txt", text=pv, hint=hint, align=align, size=size, view=pvview, pad=padleft,
                                       font=t.get("font_body", "Segoe UI"), ink=t.get("ink", "111111"), faint=t.get("faint", "999999"),
                                       bg=t.get("surface2", "f5f5f5") if pvview else t.get("input_bg", "ffffff"), line=t.get("input_line", "cccccc"),
                                       bthick=t.get("input_bthick", 1), r=t.get("r_ctrl", 8)))


def gallery(name, geo, items, build, pvitems, tsize, wrap=1, pad=0, scroll=False):
    """`build(item, template_w, template_h)` returns the template children. It is called once with pvitems[0] for the YAML
    (formulas must not depend on the item) and once per pvitem for the mock."""
    p = {"Items": items, "WrapCount": str(wrap), "TemplateSize": str(tsize), "TemplatePadding": str(pad),
         "TemplateFill": "RGBA(0, 0, 0, 0)", "Fill": "RGBA(0, 0, 0, 0)", "BorderThickness": "0",
         "ShowScrollbar": "true" if scroll else "false", "ShowNavigation": "false"}
    w = gv(geo[2]); tw = (w - pad * (wrap + 1)) / wrap
    return Ctl(name, GAL, geo, p, dict(kind="gal", items=pvitems, build=build, wrap=wrap, pad=pad, tw=tw, th=tsize),
               build(pvitems[0] if pvitems else None, tw, tsize), "Vertical")


# ---------------- YAML ----------------
def yval(fx, ind):
    s = "=" + fx
    if "\n" in s or ": " in s or "#" in s or s.endswith(":") or "{" in s or s.startswith("=-") or "'" in s[:2]:
        return "|-\n" + "\n".join(" " * ind + l for l in s.split("\n"))
    return s


def emit(c, ind):
    o = [" " * ind + f"- {c.name}:", " " * (ind + 4) + f"Control: {c.typ}"]
    if c.variant: o.append(" " * (ind + 4) + f"Variant: {c.variant}")
    o.append(" " * (ind + 4) + "Properties:")
    props = dict(c.props)
    for k, v in zip(("X", "Y", "Width", "Height"), c.geo): props[k] = g(v)[0]
    for k, v in props.items(): o.append(" " * (ind + 6) + f"{k}: " + yval(v, ind + 8))
    if c.children:
        o.append(" " * (ind + 4) + "Children:")
        for ch in c.children: o += emit(ch, ind + 6)
    return o


def screen_yaml(name, ctrls, onvis="", fill='ColorValue("#ffffff")'):
    o = ["Screens:", f"  {name}:", "    Properties:", "      Fill: " + yval(fill, 8)]
    if onvis: o.append("      OnVisible: " + yval(onvis, 8))
    o.append("    Children:")
    for c in ctrls: o += emit(c, 6)
    return "\n".join(o) + "\n"


def check_unique(screens):
    seen = {}
    def walk(cs, scr):
        for c in cs:
            if c.name in seen: raise ValueError(f"Duplicate control name {c.name} in {scr} and {seen[c.name]}")
            seen[c.name] = scr
            if c.children: walk(c.children, scr)
    for scr, cs in screens.items(): walk(cs, scr)


# ---------------- HTML mock ----------------
def _font(f, w):
    return f"font-family:{FONTS[f][1]};font-weight:{CSS_WEIGHT_OVERRIDE.get(f, w)};"


def H(c):
    pv = c.pv
    if pv.get("hide") or pv.get("kind") == "none": return ""
    x, y, w, h = (gv(v) for v in c.geo)
    st = f"position:absolute;left:{x}px;top:{y}px;width:{w}px;height:{h}px;box-sizing:border-box;"
    k = pv["kind"]
    if k == "img":
        return f"<img style='{st}object-fit:{ {'Fill': 'cover', 'Fit': 'contain', 'Stretch': 'fill'}[pv['pos']] }' src=\"{uri(pv['svg'])}\">"
    if k == "rect": return f"<div style='{st}background:{pv['fill']}'></div>"
    if k == "lbl":
        ja = {"Left": "flex-start", "Center": "center", "Right": "flex-end"}[pv["align"]]
        va = {"Middle": "center", "Top": "flex-start", "Bottom": "flex-end"}[pv["valign"]]
        bg = f"background:{css(pv['fill'])};" if pv.get("fill") else ""
        return (f"<div style='{st}{bg}{_font(pv['font'], pv['w'])}display:flex;align-items:{va};justify-content:{ja};text-align:{pv['align'].lower()};"
                f"color:{css(pv['color'])};font-size:{pv['size'] * 1.333:.1f}px;font-style:{'italic' if pv['italic'] else 'normal'};padding:0 {pv['pad']}px;"
                f"white-space:{'pre-wrap' if pv['wrap'] else 'pre'};overflow:hidden;line-height:1.22'>{html.escape(str(pv['text']))}</div>")
    if k == "btn":
        bd = f"border:{pv['bthick']}px solid {css(pv['border'])};" if pv.get("border") else ""
        ja = {"Left": "flex-start", "Center": "center", "Right": "flex-end"}[pv["align"]]
        return (f"<div style='{st}{bd}{_font(pv['font'], pv['w'])}background:{css(pv['fill'])};color:{css(pv['color'])};border-radius:{pv['r']}px;"
                f"display:flex;align-items:center;justify-content:{ja};padding-left:{pv['pad']}px;font-size:{pv['size'] * 1.333:.1f}px;white-space:pre;overflow:hidden'>{html.escape(str(pv['text']))}</div>")
    if k == "txt":
        t = pv["text"] or pv["hint"]; colr = pv["ink"] if pv["text"] else pv["faint"]
        return (f"<div style='{st}{_font(pv['font'], 400)}background:{css(pv['bg'])};border:{pv['bthick']}px solid {css(pv['line'])};border-radius:{pv['r']}px;"
                f"display:flex;align-items:center;justify-content:{'center' if pv['align'] == 'Center' else 'flex-start'};padding-left:{pv['pad']}px;"
                f"color:{css(colr)};font-size:{pv['size'] * 1.333:.1f}px;white-space:pre;overflow:hidden'>{html.escape(str(t))}</div>")
    if k == "gal":
        out = f"<div style='{st}overflow:hidden'>"
        for i, it in enumerate(pv["items"]):
            gx = pv["pad"] + (i % pv["wrap"]) * (pv["tw"] + pv["pad"]); gy = pv["pad"] + (i // pv["wrap"]) * (pv["th"] + pv["pad"])
            out += (f"<div style='position:absolute;left:{gx}px;top:{gy}px;width:{pv['tw']}px;height:{pv['th']}px'>"
                    + "".join(H(ch) for ch in pv["build"](it, pv["tw"], pv["th"])) + "</div>")
        return out + "</div>"
    return ""


def mock(ctrls, bg="#ffffff", w=1366, h=768):
    return ("<!doctype html><html><head><meta charset='utf-8'>"
            "<link href='https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&family=Open+Sans:wght@300;400;600;700&family=Patrick+Hand&display=block' rel='stylesheet'>"
            f"</head><body style='margin:0;background:#888'><div style='position:relative;width:{w}px;height:{h}px;overflow:hidden;background:{bg}'>"
            + "".join(H(c) for c in ctrls) + "</div></body></html>")
