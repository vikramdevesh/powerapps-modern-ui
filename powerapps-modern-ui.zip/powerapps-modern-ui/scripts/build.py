"""Generate a modern Power Apps canvas app from a JSON spec.

  python scripts/build.py SPEC.json [--style KEY] [--out DIR] [--pages home,dashboard,list,form] [--no-mocks]

Writes to DIR (default: out/<style>):
  App.Formulas.txt          paste into App > Formulas (seed data as a named formula)
  <Screen>.pa.yaml          one per page: right-click a screen in Tree view > Paste
  paste.html                one page with a Copy button per file, in paste order
  sample-data.csv           the demo rows as CSV (import into SharePoint / Microsoft Lists to create the list)
  --source ListName         screens read/write that SharePoint list instead of the demo collection (no App.Formulas)
  mock_<Screen>.html        HTML render for checking layout (screenshot with scripts/shoot.py)
"""
import os, sys, json, argparse, html
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from pa import screen_yaml, mock, check_unique, col, pfx_str
from themes import theme, STYLES, ORDER
from ui import Ctx
from pages import PAGES


def fx_value(v):
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, (int, float)): return repr(v)
    return pfx_str(str(v))


def formulas(C):
    d = C.S["data"]; names = [f["name"] for f in d["fields"]]
    rows = []
    for i, r in enumerate(d["rows"]):
        rec = {"Id": r.get("Id", i + 1)}; rec.update({k: r[k] for k in names if k in r})
        rows.append("    {" + ", ".join(f"{k}: {fx_value(v)}" for k, v in rec.items()) + "}")
    return (f"// ===== {C.S['app']['name']} : App.Formulas (style: {C.T['title']}) =====\n"
            f"// Demo data. Screens copy {C.seed} into the {C.coll} collection the first time they open.\n"
            f"// To use real data, point the screens at a SharePoint list / Dataverse table with the same columns.\n\n"
            f"{C.seed} = Table(\n" + ",\n".join(rows) + "\n);\n")


def paste_page(app, style, files):
    blocks = ""
    for i, (fname, how, text) in enumerate(files, 1):
        blocks += (f"<section><div class=hd><b class=n>{i}</b><div class=t><h2>{html.escape(fname)}</h2><p>{how}</p></div>"
                   f"<button class=cp data-t=t{i}>Copy</button></div><textarea id=t{i} readonly spellcheck=false>{html.escape(text)}</textarea>"
                   f"<small>{len(text) // 1024 or 1} KB · {text.count(chr(10)) + 1} lines</small></section>")
    return f"""<!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>{html.escape(app)} YAML</title>
<style>:root{{--bg:#f4f4f6;--card:#fff;--ink:#16161d;--mute:#6b6b78;--line:#e3e3ea;--acc:#3b5bdb;--ok:#2b8a3e;--code:#fafafc}}
@media (prefers-color-scheme:dark){{:root{{--bg:#0f0f14;--card:#17171f;--ink:#ececf1;--mute:#9a9aa8;--line:#2a2a35;--acc:#7c9cff;--ok:#69db7c;--code:#121218}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:980px;margin:0 auto;padding:32px 16px 64px}}h1{{margin:0 0 4px;font-size:30px}}.lead{{color:var(--mute);margin:0 0 22px}}
section{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin:0 0 16px}}
.hd{{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:10px}}.n{{width:30px;height:30px;border-radius:9px;background:var(--acc);color:#fff;display:grid;place-items:center}}
.t{{flex:1;min-width:200px}}h2{{margin:0;font:700 15px ui-monospace,Menlo,monospace}}.t p{{margin:2px 0 0;color:var(--mute);font-size:14px}}
.cp{{background:var(--acc);color:#fff;border:0;border-radius:10px;padding:9px 22px;font:600 15px system-ui;cursor:pointer;min-width:110px}}.cp.ok{{background:var(--ok)}}
textarea{{width:100%;height:180px;resize:vertical;background:var(--code);color:var(--ink);border:1px solid var(--line);border-radius:10px;padding:12px;font:12px/1.45 ui-monospace,Menlo,monospace;white-space:pre}}
small{{color:var(--mute)}}</style></head><body><main><h1>{html.escape(app)}</h1>
<p class=lead>Style: {html.escape(style)}. Create a blank canvas app in <b>Tablet</b> format, then copy and paste each block in order.</p>{blocks}
<p class=lead>Last step: drag the first screen to the top of the Tree view, delete Screen1, save and press Play.</p></main>
<script>document.querySelectorAll('.cp').forEach(b=>b.onclick=async()=>{{const t=document.getElementById(b.dataset.t);let ok=false;
try{{await navigator.clipboard.writeText(t.value);ok=true}}catch(e){{t.select();try{{ok=document.execCommand('copy')}}catch(_){{}}}}
b.textContent=ok?'Copied':'Press Ctrl+C';b.classList.toggle('ok',ok);setTimeout(()=>{{b.textContent='Copy';b.classList.remove('ok')}},2000)}})</script></body></html>"""


def csv_text(spec):
    import csv, io
    names = [f["name"] for f in spec["data"]["fields"]]
    buf = io.StringIO(); w = csv.writer(buf, lineterminator="\n"); w.writerow(names)
    for r in spec["data"]["rows"]: w.writerow([r.get(n, "") for n in names])
    return buf.getvalue()


def build(spec, style=None, out=None, pages=None, mocks=True, source=None):
    style = style or spec.get("style", "slate")
    if source: spec = dict(spec, source=source)
    if style not in STYLES: raise SystemExit(f"Unknown style {style}. Choose from: {', '.join(ORDER)}")
    if pages: spec = dict(spec, pages=pages)
    T = theme(style); C = Ctx(T, spec)
    out = out or os.path.join("out", style); os.makedirs(out, exist_ok=True)
    order = [p for p in ["home", "dashboard", "list", "form"] if p in C.pages]
    built = {}
    for p in order:
        name, ctrls, onvis = PAGES[p](C)
        built[name] = (ctrls, onvis)
    check_unique({k: v[0] for k, v in built.items()})
    files = [] if C.source else [("App.Formulas.txt", "Tree view: select <b>App</b>, pick the <b>Formulas</b> property, paste.", formulas(C))]
    try:
        import yaml
    except ImportError:
        yaml = None
    for name, (ctrls, onvis) in built.items():
        y = screen_yaml(name, ctrls, onvis, col(T["bg"][:6]))
        if yaml: yaml.safe_load(y)
        open(os.path.join(out, name + ".pa.yaml"), "w", encoding="utf-8").write(y)
        files.append((name + ".pa.yaml", "Right-click any screen in the Tree view, choose <b>Paste</b>. Wait until Studio finishes.", y))
        if mocks: open(os.path.join(out, f"mock_{name}.html"), "w", encoding="utf-8").write(mock(ctrls, "#" + T["bg"][:6]))
    if not C.source: open(os.path.join(out, "App.Formulas.txt"), "w", encoding="utf-8").write(files[0][2])
    open(os.path.join(out, "sample-data.csv"), "w", encoding="utf-8-sig").write(csv_text(spec))
    open(os.path.join(out, "paste.html"), "w", encoding="utf-8").write(paste_page(spec["app"]["name"], T["title"], files))
    return out, list(built)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("spec"); ap.add_argument("--style"); ap.add_argument("--out"); ap.add_argument("--pages"); ap.add_argument("--no-mocks", action="store_true")
    ap.add_argument("--source", help="SharePoint list name: generate screens that read/write that list (import sample-data.csv to create it)")
    a = ap.parse_args()
    spec = json.load(open(a.spec, encoding="utf-8"))
    out, names = build(spec, a.style, a.out, a.pages.split(",") if a.pages else None, not a.no_mocks, a.source)
    print(f"Wrote {", ".join(names)} + paste.html + sample-data.csv to {out}")
