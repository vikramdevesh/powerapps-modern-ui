"""Theme-driven components and the four page templates (home, dashboard, list, form).

Everything takes a Ctx: the theme tokens `T`, the app spec `S` and derived helpers.
Pages return (controls, OnVisible formula). build.py turns them into YAML + mocks.
"""
import re
from pa import (Ctl, label, button, hit, image, svg, rect, textinput, gallery, col, css, gv, pfx_str, FONTS)
from themes import SVGNS, is_dark
from art import EXTRA_CARDS

# ---------------- icons (24px stroke paths) ----------------
ICONS = {
    "home": "<path d='M3 11l9-7 9 7'/><path d='M5 10v10h14V10'/><path d='M10 20v-6h4v6'/>",
    "grid": "<rect x='3' y='3' width='7' height='7' rx='1.5'/><rect x='14' y='3' width='7' height='7' rx='1.5'/><rect x='3' y='14' width='7' height='7' rx='1.5'/><rect x='14' y='14' width='7' height='7' rx='1.5'/>",
    "list": "<path d='M8 6h13M8 12h13M8 18h13'/><circle cx='4' cy='6' r='1'/><circle cx='4' cy='12' r='1'/><circle cx='4' cy='18' r='1'/>",
    "plus": "<path d='M12 5v14M5 12h14'/>",
    "search": "<circle cx='11' cy='11' r='7'/><path d='M20 20l-4-4'/>",
    "box": "<path d='M21 8l-9-5-9 5 9 5 9-5z'/><path d='M3 8v8l9 5 9-5V8'/><path d='M12 13v8'/>",
    "alert": "<path d='M12 3l10 18H2L12 3z'/><path d='M12 10v5'/><path d='M12 18h.01'/>",
    "ban": "<circle cx='12' cy='12' r='9'/><path d='M5.6 5.6l12.8 12.8'/>",
    "coin": "<circle cx='12' cy='12' r='9'/><path d='M15 9.5c-.5-1-1.6-1.5-3-1.5-1.7 0-3 .9-3 2.2 0 3 6 1.6 6 4.6 0 1.3-1.3 2.2-3 2.2-1.4 0-2.6-.6-3-1.6'/><path d='M12 6v2M12 16v2'/>",
    "chart": "<path d='M4 20V10M10 20V4M16 20v-7M22 20H2'/>",
    "check": "<path d='M5 12l5 5L20 7'/>",
    "users": "<circle cx='9' cy='8' r='3.5'/><path d='M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5'/><path d='M16 4.5a3.5 3.5 0 0 1 0 7M18 14.8c1.9.7 3.1 2.5 3.5 5.2'/>",
    "store": "<path d='M3 9l2-5h14l2 5'/><path d='M4 9v11h16V9'/><path d='M3 9h18'/><path d='M9 20v-6h6v6'/>",
    "doc": "<path d='M14 3H6v18h12V7l-4-4z'/><path d='M14 3v4h4M9 12h6M9 16h6'/>",
    "arrow": "<path d='M5 12h14M13 6l6 6-6 6'/>",
    "back": "<path d='M19 12H5M11 6l-6 6 6 6'/>",
    "clock": "<circle cx='12' cy='12' r='9'/><path d='M12 7v5l3 2'/>",
    "trash": "<path d='M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3'/>",
}


def icon_svg(key, stroke, size=24, sw=1.8):
    return (f"<svg {SVGNS} viewBox='0 0 24 24' width='{size}' height='{size}' fill='none' stroke='{css(stroke)}' stroke-width='{sw}' "
            f"stroke-linecap='round' stroke-linejoin='round'>{ICONS[key]}</svg>")


def tile_svg(key, fg, bg, s=40, r=10, border=None):
    b = f" stroke='{css(border)}' stroke-width='2'" if border else ""
    return (f"<svg {SVGNS} viewBox='0 0 {s} {s}' width='{s}' height='{s}'><rect x='1' y='1' width='{s - 2}' height='{s - 2}' rx='{r}' fill='{css(bg)}'{b}/>"
            f"<g transform='translate({(s - 21.6) / 2:.1f} {(s - 21.6) / 2:.1f}) scale(0.9)' fill='none' stroke='{css(fg)}' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>{ICONS[key]}</g></svg>")


# ---------------- expression helpers ----------------
def fx2py(e):
    """Tiny Power Fx subset -> Python (for computing mock numbers): fields, numbers, strings, + - * /, = <> < <= > >=, && || !, true/false."""
    s = e.replace("<>", " != ").replace("&&", " and ").replace("||", " or ")
    s = re.sub(r"(?<![<>!=])=(?!=)", "==", s)
    s = re.sub(r"!(?!=)", " not ", s)
    s = re.sub(r"\btrue\b", "True", s); s = re.sub(r"\bfalse\b", "False", s)
    return s


def ev(e, row):
    return eval(fx2py(e), {"__builtins__": {}}, dict(row))


class Ctx:
    def __init__(s, T, S):
        s.T, s.S = T, S
        a = S["app"]; d = S["data"]
        s.P = a.get("prefix", "")
        s.coll, s.seed = d.get("collection", "col" + s.P + "Items"), d.get("seed", "Seed" + s.P + "Items")
        s.source = S.get("source")  # SharePoint list name: screens read/write the list directly instead of a demo collection
        if s.source: s.coll = s.source
        s.key = "ID" if s.source else "Id"
        s.F = {f["name"]: f for f in d["fields"]}
        for c in d.get("computed", []): s.F[c["name"]] = dict(c, computed=True)
        s.cur = a.get("currency", "$"); s.indian = a.get("numbers", "intl") == "indian"
        s.title_f = next((f["name"] for f in d["fields"] if f.get("title")), d["fields"][0]["name"])
        s.seg = next((f["name"] for f in d["fields"] if f.get("segment")), None)
        s.filt = next((f["name"] for f in d["fields"] if f.get("filter")), None)
        s.status = d.get("status")
        # mock rows with computed columns + status
        s.rows = []
        for i, r in enumerate(d["rows"]):
            r = dict(r); r.setdefault("Id", i + 1)
            for c in d.get("computed", []): r[c["name"]] = ev(c["expr"], r)
            if s.status:
                for cond, text, tone in s.status["rules"]:
                    if ev(cond, r): r["StatusText"] = text; break
            s.rows.append(r)
        s.screens = {k: s.P + v for k, v in dict(home="HomeScreen", dashboard="DashboardScreen", list="ListScreen", form="FormScreen").items()}
        s.pages = S.get("pages", ["home", "dashboard", "list", "form"])

    # variable / control naming
    def v(s, n): return "g" + s.P + n
    def n(s, scr, name): return s.P + scr + name

    @property
    def ROWS(s):
        d = s.S["data"]; parts = []
        for c in d.get("computed", []): parts += [c["name"], c["expr"]]
        if s.status:
            conds = []
            for cond, text, tone in s.status["rules"]:
                if cond.strip() == "true": conds.append(pfx_str(text))
                else: conds += [cond, pfx_str(text)]
            parts += ["StatusText", "If(" + ", ".join(conds) + ")"]
        return f"AddColumns({s.coll}, {', '.join(parts)})" if parts else s.coll

    def SRC(s):  # dashboard source, filtered by segment
        if not s.seg: return s.ROWS
        return f'Filter({s.ROWS}, {s.v("Seg")} = "All" || {s.seg} = {s.v("Seg")})'

    def tone_of(s, text):
        for cond, t, tone in (s.status or {}).get("rules", []):
            if t == text: return tone
        return "good"

    def tone_fx(s, item, which):  # which 0=fg 1=bg
        T = s.T
        if not s.status: return col(T["good"][which])
        args = []
        for cond, text, tone in s.status["rules"][:-1]:
            args += [pfx_str(text), col(T[tone][which])]
        return f"Switch({item}.StatusText, {', '.join(args)}, {col(T[s.status['rules'][-1][2]][which])})"

    # formatting
    def fmt_fx(s, expr, kind):
        if kind == "money":
            if s.indian:
                return (f'With({{v: {expr}}}, If(Abs(v) >= 10000000, "{s.cur}" & Text(v / 10000000, "0.00") & " Cr", '
                        f'Abs(v) >= 100000, "{s.cur}" & Text(v / 100000, "0.0") & " L", "{s.cur}" & Text(v, "#,##0")))')
            return (f'With({{v: {expr}}}, If(Abs(v) >= 1000000000, "{s.cur}" & Text(v / 1000000000, "0.00") & "B", '
                    f'Abs(v) >= 1000000, "{s.cur}" & Text(v / 1000000, "0.0") & "M", Abs(v) >= 10000, "{s.cur}" & Text(v / 1000, "0.0") & "K", "{s.cur}" & Text(v, "#,##0")))')
        if kind == "currency": return f'"{s.cur}" & Text({expr}, "#,##0")'
        if kind == "number": return f'Text({expr}, "#,##0")'
        return expr

    def fmt_py(s, v, kind):
        if kind == "money":
            a = abs(v)
            if s.indian: return f"{s.cur}{v / 1e7:.2f} Cr" if a >= 1e7 else (f"{s.cur}{v / 1e5:.1f} L" if a >= 1e5 else f"{s.cur}{v:,.0f}")
            return (f"{s.cur}{v / 1e9:.2f}B" if a >= 1e9 else f"{s.cur}{v / 1e6:.1f}M" if a >= 1e6 else f"{s.cur}{v / 1e3:.1f}K" if a >= 1e4 else f"{s.cur}{v:,.0f}")
        if kind == "currency": return f"{s.cur}{v:,.0f}"
        if kind == "number": return f"{v:,.0f}"
        return str(v)

    def ftype_kind(s, name):
        t = s.F[name].get("type", "text")
        return {"currency": "currency", "number": "number"}.get(t, "text")

    # ---------------- primitives ----------------
    def L(s, name, geo, fx, pv, size=11, role="body", weight="normal", color=None, **kw):
        T = s.T; font = {"display": T["font_display"], "label": T["font_label"], "body": T["font_body"]}[role]
        if role == "display" and font in ("Lato Black", "Lato Light"): weight = "normal"
        if role == "label" and T.get("label_upper"): fx, pv = f"Upper({fx})", str(pv).upper()
        size = max(7, size + T.get("size_bump", 0))
        return label(name, geo, fx, pv, size, font, weight, color or T["ink"], **kw)

    def card(s, name, x, y, w, h, fill=None, emph=False):
        T = s.T; k = T["card"]; r = T["r_card"]; m = 12; f = fill or T["surface"]
        W, Hh = w + 2 * m, h + 2 * m
        defs, body = "", ""
        if k == "soft":
            defs = "<filter id='s' x='-20%' y='-20%' width='140%' height='150%'><feGaussianBlur stdDeviation='5'/></filter>"
            body = (f"<rect x='{m}' y='{m + 4}' width='{w}' height='{h}' rx='{r}' fill='#0f172a' fill-opacity='0.07' filter='url(#s)'/>"
                    f"<rect x='{m}' y='{m}' width='{w}' height='{h}' rx='{r}' fill='{css(f)}' stroke='{css(T['line'])}'/>")
        elif k == "glass":
            defs = ("<filter id='s' x='-20%' y='-20%' width='140%' height='150%'><feGaussianBlur stdDeviation='8'/></filter>"
                    "<linearGradient id='e' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#fff' stop-opacity='0.95'/><stop offset='1' stop-color='#fff' stop-opacity='0.35'/></linearGradient>")
            body = (f"<rect x='{m}' y='{m + 6}' width='{w}' height='{h}' rx='{r}' fill='#4c3d99' fill-opacity='0.08' filter='url(#s)'/>"
                    f"<rect x='{m}' y='{m}' width='{w}' height='{h}' rx='{r}' fill='{css(f)}' stroke='url(#e)' stroke-width='1.5'/>")
        elif k == "glow":
            defs = (f"<linearGradient id='e' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#{T['acc']}' stop-opacity='{0.9 if emph else 0.55}'/>"
                    f"<stop offset='0.5' stop-color='#{T['line']}' stop-opacity='0.6'/><stop offset='1' stop-color='#{T['acc2'][:6]}' stop-opacity='{0.8 if emph else 0.35}'/></linearGradient>"
                    "<filter id='s' x='-20%' y='-20%' width='140%' height='150%'><feGaussianBlur stdDeviation='9'/></filter>")
            body = (f"<rect x='{m}' y='{m}' width='{w}' height='{h}' rx='{r}' fill='#{T['acc']}' fill-opacity='{0.16 if emph else 0.06}' filter='url(#s)'/>"
                    f"<rect x='{m}' y='{m}' width='{w}' height='{h}' rx='{r}' fill='{css(f)}' stroke='url(#e)' stroke-width='1.2'/>")
        elif k == "tint":
            defs = "<filter id='s' x='-20%' y='-20%' width='140%' height='150%'><feGaussianBlur stdDeviation='10'/></filter>"
            body = (f"<rect x='{m + 6}' y='{m + 8}' width='{w - 12}' height='{h - 4}' rx='{r}' fill='#5b5f97' fill-opacity='0.08' filter='url(#s)'/>"
                    f"<rect x='{m}' y='{m}' width='{w}' height='{h}' rx='{r}' fill='{css(f)}'/>")
        elif k == "rule":
            body = (f"<rect x='{m}' y='{m}' width='{w}' height='{h}' fill='{css(f)}'/>"
                    f"<rect x='{m}' y='{m}' width='{w}' height='3' fill='#{T['ink']}'/><rect x='{m}' y='{m + h - 1}' width='{w}' height='1' fill='#{T['ink']}' fill-opacity='0.35'/>")
        elif k == "offset":
            body = (f"<rect x='{m + 6}' y='{m + 6}' width='{w - 4}' height='{h - 4}' rx='{r}' fill='#000'/>"
                    f"<rect x='{m + 1.5}' y='{m + 1.5}' width='{w - 7}' height='{h - 7}' rx='{r}' fill='{css(f)}' stroke='#000' stroke-width='3'/>")
        elif k in EXTRA_CARDS:
            defs, body = EXTRA_CARDS[k](T, w, h, css(f), r, m, emph)
        else:  # hairline
            body = (f"<rect x='{m + .5}' y='{m + .5}' width='{w - 1}' height='{h - 1}' rx='{r}' fill='{css(f)}' stroke='{css(T['line'])}'/>")
        s_ = f"<svg {SVGNS} width='{W}' height='{Hh}' viewBox='0 0 {W} {Hh}'><defs>{defs}</defs>{body}</svg>"
        return svg(name, (x - m, y - m, W, Hh), s_, "Fit")

    def btn_primary(s, name, geo, fx, pv, onselect, size=11, **kw):
        T = s.T; brut = bool(T.get("outline"))
        return button(name, geo, fx, pv, onselect, fill=T["acc"], color=T["acc_ink"], size=size, font=T["font_body"], weight="semi" if not brut else "bold",
                      radius=T["r_ctrl"] if T["r_ctrl"] < 12 else 22, border="000000" if brut else None, bthick=3 if brut else 1, focus=T["ink"], **kw)

    def btn_secondary(s, name, geo, fx, pv, onselect, size=11, color=None, **kw):
        T = s.T; brut = bool(T.get("outline"))
        return button(name, geo, fx, pv, onselect, fill=T["surface2"] if is_dark(T) else "ffffff", color=color or T["ink"], size=size, font=T["font_body"],
                      weight="semi", radius=T["r_ctrl"] if T["r_ctrl"] < 12 else 22, border="000000" if brut else T["input_line"], bthick=3 if brut else 1, focus=T["ink"], **kw)

    def chip(s, name, geo, fx, pv, fill_fx, color_fx, pvfill, pvcolor, size=8):
        T = s.T; brut = bool(T.get("outline"))
        return button(name, geo, fx, pv, "false", size=size, font=T["font_label"], weight="bold" if brut else "semi", radius=min(T["r_pill"], gv(geo[3]) // 2),
                      fill_fx=fill_fx, color_fx=color_fx, pvfill=pvfill, pvcolor=pvcolor, hover_fx="Self.Fill",
                      border="000000" if brut else None, bthick=2, extra={"TabIndex": "-1"})

    def bar(s, name, geo, color_fx, pvcolor, track=False):
        T = s.T; h = gv(geo[3])
        if track:
            tc = T["line"] if is_dark(T) else ("00000012" if not T.get("outline") else "ffffff")
            return button(name, geo, '""', "", "false", fill=tc, radius=0 if T["r_card"] == 0 else h // 2, hover_fx="Self.Fill",
                          border="000000" if T.get("outline") else None, bthick=2, extra={"TabIndex": "-1"})
        return button(name, geo, '""', "", "false", fill_fx=color_fx, pvfill=pvcolor, radius=0 if T["r_card"] == 0 else h // 2, hover_fx="Self.Fill",
                      border="000000" if T.get("outline") else None, bthick=2, extra={"TabIndex": "-1"})

    def pills(s, name, geo, items_fx, pvitems, var, pvsel, wrap, onextra=""):
        T = s.T; brut = bool(T.get("outline"))
        on_bg, on_ink = T["acc"], T["acc_ink"]
        off_bg = T["pill_off"]
        def build(it, tw, th):
            on = it == pvsel
            return [button(name + "Pill", (0, 0, ("Parent.TemplateWidth", tw), ("Parent.TemplateHeight", th)), "ThisItem.Value", it or "",
                           f"Set({var}, ThisItem.Value){onextra}", size=10, font=T["font_body"], weight="semi", radius=min(T["r_pill"], th // 2),
                           fill_fx=f"If({var} = ThisItem.Value, {col(on_bg)}, {col(off_bg)})",
                           color_fx=f"If({var} = ThisItem.Value, {col(on_ink)}, {col(T['ink2'] if not brut else '000000')})",
                           border_fx=None if T.get("pill_noborder") else f"If({var} = ThisItem.Value, {col(on_bg if not brut else '000000')}, {col(T['line'] if not brut else '000000')})",
                           bthick=2 if brut else 1, pvfill=on_bg if on else off_bg, pvcolor=on_ink if on else (T["ink2"] if not brut else "000000"),
                           pvborder=None if T.get("pill_noborder") else ((on_bg if not brut else "000000") if on else (T["line"] if not brut else "000000")), focus=T["ink"])]
        x, y, w, h = geo
        return gallery(name, (x, y, w, h + 6), items_fx, build, pvitems, h, wrap, 3)

    # ---------------- chrome ----------------
    def background(s, scr):
        T = s.T
        o = [rect(s.n(scr, "Bg"), (0, 0, 1366, 768), T["bg"][:6])]
        if T.get("bg_svg"): o.append(svg(s.n(scr, "BgArt"), (0, 0, 1366, 768), T["bg_svg"](1366, 768), "Stretch"))
        return o

    def logo(s, name, x, y, size=40):
        T = s.T; brut = bool(T.get("outline"))
        a1, a2 = T["acc"], T["acc2"][:6]; bstroke = " stroke='#000' stroke-width='3'" if brut else ""
        if T.get("logo") == "letter":
            s_ = (f"<svg {SVGNS} viewBox='0 0 40 40' width='40' height='40'><rect width='40' height='40' fill='#{T['ink']}'/>"
                  f"<text x='20' y='29' font-family='Georgia,serif' font-size='24' fill='#{T['bg'][:6]}' text-anchor='middle'>{s.S['app']['name'][0]}</text></svg>")
        else:
            s_ = (f"<svg {SVGNS} viewBox='0 0 40 40' width='40' height='40'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>"
                  f"<stop offset='0' stop-color='#{a1}'/><stop offset='1' stop-color='#{a2 if not brut else a1}'/></linearGradient></defs>"
                  f"<rect x='1.5' y='1.5' width='37' height='37' rx='{min(11, T['r_card'])}' fill='url(#g)'{bstroke}/>"
                  f"<g transform='translate(9 9) scale(0.92)' fill='none' stroke='#fff' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'>{ICONS[s.S['app'].get('icon', 'box')]}</g></svg>")
        return svg(name, (x, y, size, size), s_)

    def nav_items(s):
        e = s.S["data"]
        items = []
        for p in s.pages:
            if p == "home": items.append(("home", "Home", "home"))
            if p == "dashboard": items.append(("dashboard", "Dashboard", "grid"))
            if p == "list": items.append(("list", e.get("entities", "Records"), "list"))
        return items

    def nav(s, scr, active):
        """Returns (controls, x0, y0, width) of the content area."""
        T = s.T; a = s.S["app"]; o = []
        brut = bool(T.get("outline"))
        if T["nav"].startswith("side"):
            o.append(rect(s.n(scr, "SideBg"), (0, 0, 232, 768), T["nav_bg"]))
            if T["nav"] == "side-light" and not brut: o.append(rect(s.n(scr, "SideEdge"), (231, 0, 1, 768), T["line"][:6]))
            if brut: o.append(rect(s.n(scr, "SideEdge"), (229, 0, 3, 768), "000000"))
            o += [s.logo(s.n(scr, "Logo"), 24, 26),
                  s.L(s.n(scr, "AppName"), (74, 26, 152, 22), pfx_str(a["name"]), a["name"], 12, "display" if T["font_display"] != "Lato Light" else "body", "bold", T["nav_ink"]),
                  s.L(s.n(scr, "AppSub"), (74, 48, 152, 18), pfx_str(a.get("tagline", "")), a.get("tagline", ""), 8, "label", color=T["nav_muted"])]
            for i, (key, lab_, ic) in enumerate(s.nav_items()):
                y = 112 + i * 48; on = key == active; nm = s.n(scr, "Nav" + key.title())
                o += [button(nm, (16, y, 200, 42), pfx_str(lab_), lab_, "false", fill=T["nav_act_bg"] if on else T["nav_bg"][:6] + ("00" if not on else ""),
                             color=T["nav_act_ink"] if on else T["nav_ink"], size=11, font=T["font_body"], weight="semi", radius=min(12, T["r_ctrl"] + 2) if not brut else 6,
                             align="Left", pad=48, hover_fx="Self.Fill", border="000000" if (brut and on) else None, bthick=2),
                      svg(nm + "Ico", (32, y + 11, 20, 20), icon_svg(ic, T["nav_act_ink"] if on else T["nav_muted"], 20)),
                      hit(nm + "Hit", (16, y, 200, 42), "false" if on else f"Navigate({s.screens[key]}, ScreenTransition.None)", f"Open {lab_}",
                          "RGBA(127, 127, 127, 0.10)", radius=min(12, T["r_ctrl"] + 2), focus=T["acc"])]
            if "form" in s.pages:
                o.append(s.btn_primary(s.n(scr, "NavNew"), (16, 700, 200, 44), pfx_str("New " + s.S["data"].get("entity", "record").lower()),
                                       "New " + s.S["data"].get("entity", "record").lower(), s.go_new(), size=11))
            return o, 256, 24, 1086
        # top bar
        floating = T.get("float_nav")
        if floating:
            o.append(s.card(s.n(scr, "TopBar"), 24, 14, 1318, 56, fill=T["nav_bg"]))
        elif T.get("nav_rule"):
            o += [rect(s.n(scr, "TopRule"), (24, 70, 1318, 2), T["ink"])]
        elif T["nav_bg"][-2:] != "00" or len(T["nav_bg"]) == 6:
            o.append(rect(s.n(scr, "TopBar"), (0, 0, 1366, 64), T["nav_bg"][:6] if len(T["nav_bg"]) == 6 else T["nav_bg"], ))
        else:
            o.append(rect(s.n(scr, "TopRule"), (0, 64, 1366, 1), T["line"][:6]))
        ty = 26 if floating else 18
        o += [s.logo(s.n(scr, "Logo"), 38 if floating else 24, ty - 6 if not floating else 22, 28 if floating else 30),
              s.L(s.n(scr, "AppName"), (78 if floating else 66, ty - 6 if not floating else 22, 260, 28 if not floating else 28), pfx_str(a["name"]), a["name"],
                  14 if T["font_display"] == "Georgia" else 12, "display" if T["font_display"] != "Lato Light" else "body", "bold", T["nav_ink"])]
        x = 1342 - (16 if floating else 0)
        btns = []
        if "form" in s.pages:
            w = 150; x -= w
            nb = s.btn_primary(s.n(scr, "NavNew"), (x, ty - 7 if not floating else 23, w, 34), pfx_str("New " + s.S["data"].get("entity", "record").lower()),
                               "New " + s.S["data"].get("entity", "record").lower(), s.go_new(), size=10)
            if T["nav_bg"][:6] == T["acc"]:  # accent-coloured bar: invert the button
                nb.props["Fill"], nb.props["Color"] = col("ffffff"), col(T["acc"]); nb.pv["fill"], nb.pv["color"] = "ffffff", T["acc"]
            btns.append(nb)
            x -= 16
        for key, lab_, ic in reversed(s.nav_items()):
            w = 34 + 8 * len(lab_) + 26; x -= w; on = key == active; nm = s.n(scr, "Nav" + key.title())
            yy = ty - 7 if not floating else 23
            btns += [button(nm, (x, yy, w, 34), pfx_str(lab_), lab_, "false", fill=T["nav_act_bg"] if on else "00000000",
                            color=T["nav_act_ink"] if on else T["nav_muted"], size=10, font=T["font_body"], weight="semi", radius=min(17, T["r_pill"]) if T["r_pill"] else 0,
                            align="Left", pad=34, hover_fx="Self.Fill"),
                     svg(nm + "Ico", (x + 11, yy + 8, 18, 18), icon_svg(ic, T["nav_act_ink"] if on else T["nav_muted"], 18)),
                     hit(nm + "Hit", (x, yy, w, 34), "false" if on else f"Navigate({s.screens[key]}, ScreenTransition.None)", f"Open {lab_}",
                         "RGBA(127, 127, 127, 0.12)", radius=min(17, T["r_pill"]), focus=T["acc"])]
            x -= 6
        o += btns
        return o, 24 if not floating else 24, 92, 1318

    def header(s, scr, x0, y0, title, sub_fx, sub_pv, w=640):
        T = s.T
        big = 22 if T["font_display"] != "Lato Light" else 26
        return [s.L(s.n(scr, "Title"), (x0, y0, w, 36), pfx_str(title), title, big, "display", "bold" if T["font_display"] in ("Segoe UI", "Open Sans", "Verdana", "Courier New") else "normal", T["header_ink"]),
                s.L(s.n(scr, "Sub"), (x0, y0 + 36, w, 20), sub_fx, sub_pv, 10, "body", color=T["header_ink2"])]

    # ---------------- navigation formulas ----------------
    def reset_form(s):
        out = []
        for f in s.form_fields():
            if f.get("type") == "choice": out.append(f'Set({s.v("F" + f["name"])}, If({s.v("Mode")} = "edit", {s.v("Sel")}.{f["name"]}, "{f["choices"][0]}"))')
            else: out.append(f'Reset({s.n("Fm", "In" + f["name"])})')
        return ";\n".join(out)

    def go_new(s):
        if "form" not in s.pages: return "false"
        return f'Set({s.v("Mode")}, "new");\nSet({s.v("Sel")}, Blank());\nNavigate({s.screens["form"]}, ScreenTransition.None)'

    def go_edit(s, item="ThisItem"):
        if "form" not in s.pages: return "false"
        return f'Set({s.v("Mode")}, "edit");\nSet({s.v("Sel")}, {item});\nNavigate({s.screens["form"]}, ScreenTransition.None)'

    def form_fields(s):
        return [f for f in s.S["data"]["fields"] if not f.get("readonly")]

    def init(s):
        o = [] if s.source else [f"If(IsEmpty({s.coll}), ClearCollect({s.coll}, {s.seed}))"]
        if s.seg: o.append(f'If(IsBlank({s.v("Seg")}), Set({s.v("Seg")}, "All"))')
        if s.filt: o.append(f'If(IsBlank({s.v("Filt")}), Set({s.v("Filt")}, "All"))')
        if s.status: o.append(f'If(IsBlank({s.v("Stat")}), Set({s.v("Stat")}, "All"))')
        o.append(f'If(IsBlank({s.v("Sort")}), Set({s.v("Sort")}, "{s.title_f}"); Set({s.v("Desc")}, false))')
        return ";\n".join(o)
