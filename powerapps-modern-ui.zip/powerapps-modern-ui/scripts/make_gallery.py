"""Rebuild the example apps, preview images, the style-picker sheet and gallery/index.html.

  python scripts/make_gallery.py        (needs: pyyaml, playwright + chromium, pillow)
"""
import os, sys, json, glob, shutil, asyncio, html
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, HERE)
from build import build
from themes import STYLES, ORDER
from PIL import Image, ImageDraw, ImageFont

PAGES = ["HomeScreen", "DashboardScreen", "ListScreen", "FormScreen"]
TMP = os.path.join(ROOT, ".preview_tmp")


async def shoot(files):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1366, "height": 768})
        for f in files:
            await pg.goto("file://" + f); await pg.wait_for_timeout(450); await pg.screenshot(path=f[:-5] + ".png")
        await b.close()


def font(sz, bold=False):
    for f in (["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"] if bold else ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]):
        if os.path.exists(f): return ImageFont.truetype(f, sz)
    return ImageFont.load_default()


def main():
    specs = sorted(glob.glob(os.path.join(ROOT, "examples", "specs", "*.json")))
    shutil.rmtree(TMP, ignore_errors=True)
    mocks = []
    for sp in specs:
        spec = json.load(open(sp, encoding="utf-8")); key = os.path.basename(sp)[:-5]
        for st in (ORDER if key == "retail-inventory" else ORDER[:8]):
            out = os.path.join(ROOT, "examples", key, st) if key == "retail-inventory" else os.path.join(TMP, "_" + key, st)
            shutil.rmtree(out, ignore_errors=True)
            build(spec, st, out, mocks=True)
            for m in glob.glob(os.path.join(out, "mock_*.html")):
                dst = os.path.join(TMP, key, st, os.path.basename(m)); os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.move(m, dst); mocks.append(dst)
    asyncio.run(shoot(mocks))
    prev = os.path.join(ROOT, "assets", "previews"); os.makedirs(prev, exist_ok=True)
    demo = "retail-inventory"
    for m in mocks:
        key, st = m.split(os.sep)[-3], m.split(os.sep)[-2]; page = os.path.basename(m)[5:-5]
        page = page[len(page) - len(next(p for p in PAGES if page.endswith(p))):]
        im = Image.open(m[:-5] + ".png").convert("RGB")
        if key == demo:
            im.save(os.path.join(prev, f"{st}-{page.replace('Screen', '').lower()}.jpg"), quality=84)
        elif page == "DashboardScreen":
            im.resize((683, 384), Image.LANCZOS).save(os.path.join(prev, f"{key}-{st}-dashboard.jpg"), quality=80)
    # style picker sheet: all styles, numbered, 5 per row
    W, Hh, pad, cap, cols = 360, 203, 22, 46, 5
    rows = (len(ORDER) + cols - 1) // cols
    sheet = Image.new("RGB", (pad + cols * (W + pad), 76 + rows * (Hh + cap + pad)), "#f4f4f6")
    d = ImageDraw.Draw(sheet)
    d.text((pad, 20), f"Power Apps Modern UI: {len(ORDER)} styles  (reply with the number or name)", fill="#16161d", font=font(28, True))
    for i, st in enumerate(ORDER):
        x = pad + (i % cols) * (W + pad); y = 76 + (i // cols) * (Hh + cap + pad)
        th = Image.open(os.path.join(prev, f"{st}-dashboard.jpg")).resize((W, Hh), Image.LANCZOS)
        sheet.paste(th, (x, y)); d.rectangle((x - 1, y - 1, x + W, y + Hh), outline="#d0d0d8", width=1)
        d.text((x, y + Hh + 8), f"{i + 1}. {STYLES[st]['title']}", fill="#16161d", font=font(17, True))
        d.text((x, y + Hh + 29), STYLES[st].get("group", ""), fill="#6b6b78", font=font(12))
    sheet.save(os.path.join(ROOT, "assets", "style-picker.png"))
    gallery_html(prev)
    shutil.rmtree(TMP, ignore_errors=True)
    print("previews:", len(os.listdir(prev)), "| sheet: assets/style-picker.png | gallery/index.html")


def gallery_html(prev):
    cards = ""
    for i, st in enumerate(ORDER, 1):
        S = STYLES[st]
        sw = "".join(f"<i style='background:#{c[:6]}' title='#{c[:6]}'></i>" for c in [S["bg"], S["surface"], S["ink"], S["acc"], S["acc2"]] + S["chart"][:3])
        thumbs = "".join(f"<a href='../assets/previews/{st}-{p}.jpg' target=_blank><img loading=lazy src='../assets/previews/{st}-{p}.jpg' alt='{S['title']} {p}'><span>{p.title()}</span></a>"
                         for p in ["dashboard", "home", "list", "form"])
        cards += f"""<article id='{st}'><header><b class=n>{i}</b><div><h2>{html.escape(S['title'])} <code>{st}</code></h2>
<p>{html.escape(S['mood'])}</p><p class=best><b>Best for:</b> {html.escape(S['best'])}</p><p class=best><b>Family:</b> {html.escape(S.get('group', ''))} · <b>Inspired by:</b> {html.escape(S['atlas'])} · fonts {S['font_display']} / {S['font_body']}</p></div></header>
<div class=sw>{sw}</div><div class=th>{thumbs}</div></article>"""
    page = f"""<!doctype html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Power Apps Modern UI styles</title>
<style>:root{{--bg:#f4f4f6;--card:#fff;--ink:#16161d;--mute:#5f5f6b;--line:#e3e3ea;--acc:#3b5bdb}}
@media (prefers-color-scheme:dark){{:root{{--bg:#0f0f14;--card:#17171f;--ink:#ececf1;--mute:#9a9aa8;--line:#2a2a35;--acc:#7c9cff}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:1180px;margin:0 auto;padding:32px 16px 64px}}h1{{font-size:clamp(26px,4vw,38px);margin:0 0 6px;letter-spacing:-.01em}}.lead{{color:var(--mute);max-width:760px;margin:0 0 26px}}
article{{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px;margin:0 0 20px}}header{{display:flex;gap:14px}}
.n{{flex:none;width:36px;height:36px;border-radius:10px;background:var(--acc);color:#fff;display:grid;place-items:center;font-size:17px}}
h2{{margin:2px 0 4px;font-size:21px}}code{{font-size:13px;color:var(--mute);background:var(--bg);padding:2px 7px;border-radius:6px}}p{{margin:0 0 4px}}.best{{color:var(--mute);font-size:14px}}
.sw{{display:flex;gap:6px;margin:12px 0}}.sw i{{width:26px;height:26px;border-radius:7px;border:1px solid var(--line)}}
.th{{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:10px}}.th a{{position:relative;display:block;border-radius:10px;overflow:hidden;border:1px solid var(--line)}}
.th img{{display:block;width:100%;aspect-ratio:1366/768;object-fit:cover}}.th span{{position:absolute;left:8px;bottom:8px;background:rgba(0,0,0,.65);color:#fff;font-size:12px;padding:2px 8px;border-radius:6px}}
@media (max-width:760px){{.th{{grid-template-columns:1fr 1fr}}}}</style></head><body><main>
<h1>Power Apps Modern UI styles</h1><p class=lead>{len(ORDER)} looks, each shown on the same demo app. Every screen is generated as paste-ready Power Apps YAML. Click a thumbnail to open it full size. Tell Claude the number or name of the style you want.</p>
{cards}</main></body></html>"""
    os.makedirs(os.path.join(ROOT, "gallery"), exist_ok=True)
    open(os.path.join(ROOT, "gallery", "index.html"), "w", encoding="utf-8").write(page)


if __name__ == "__main__":
    main()
