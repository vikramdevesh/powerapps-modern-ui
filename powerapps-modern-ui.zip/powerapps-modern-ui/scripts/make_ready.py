"""Build docs/ready-to-use.html: every style's paste-ready YAML (demo-data and SharePoint-list versions) + the sample CSV.

  python scripts/make_ready.py [SPEC.json] [--list InventoryItems]

The YAML is gzip-compressed and base64-embedded, so the page is one self-contained file that works offline.
"""
import os, sys, json, gzip, base64, io, tempfile, html, argparse
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, HERE)
from build import build, csv_text
from themes import STYLES, ORDER
from PIL import Image

ap = argparse.ArgumentParser(); ap.add_argument("spec", nargs="?", default=os.path.join(ROOT, "examples", "specs", "retail-inventory.json"))
ap.add_argument("--list", default="InventoryItems"); ap.add_argument("--out", default=os.path.join(ROOT, "docs", "ready-to-use.html"))
a = ap.parse_args()
spec = json.load(open(a.spec, encoding="utf-8"))
P = spec["app"].get("prefix", ""); SCR = [P + s for s in ("HomeScreen", "DashboardScreen", "ListScreen", "FormScreen")]

data = {}
with tempfile.TemporaryDirectory() as tmp:
    for st in ORDER:
        entry = {}
        for mode, src in (("demo", None), ("sp", a.list)):
            d = os.path.join(tmp, st, mode); build(spec, st, d, mocks=False, source=src)
            files = []
            if not src: files.append(["App.Formulas.txt", open(os.path.join(d, "App.Formulas.txt"), encoding="utf-8").read()])
            for s in SCR: files.append([s + ".pa.yaml", open(os.path.join(d, s + ".pa.yaml"), encoding="utf-8").read()])
            entry[mode] = files
        data[st] = entry
blob = base64.b64encode(gzip.compress(json.dumps(data, ensure_ascii=False).encode("utf-8"), 9)).decode()

thumbs = {}
for st in ORDER:
    im = Image.open(os.path.join(ROOT, "assets", "previews", f"{st}-dashboard.jpg")).convert("RGB").resize((420, 236), Image.LANCZOS)
    b = io.BytesIO(); im.save(b, "JPEG", quality=78); thumbs[st] = "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()
meta = {st: {"t": STYLES[st]["title"], "g": STYLES[st].get("group", ""), "m": STYLES[st]["mood"], "b": STYLES[st]["best"], "img": thumbs[st]} for st in ORDER}
csv = csv_text(spec); fields = spec["data"]["fields"]
num = [f["name"] for f in fields if f.get("type") in ("number", "currency")]; txt = [f["name"] for f in fields if f["name"] not in num]
app = spec["app"]["name"]

page = """<!doctype html><html lang=en><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>__APP__ · ready-to-use Power Apps YAML</title>
<style>
:root{--bg:#f5f5f7;--card:#fff;--ink:#16161d;--mute:#5d5d6b;--line:#e2e2ea;--acc:#3b5bdb;--acc2:#e8edff;--ok:#2b8a3e;--code:#fafafc}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#0f0f14;--card:#17171f;--ink:#ececf1;--mute:#a0a0ae;--line:#2a2a35;--acc:#8aa2ff;--acc2:#1f2647;--ok:#69db7c;--code:#121218}}
:root[data-theme=dark]{--bg:#0f0f14;--card:#17171f;--ink:#ececf1;--mute:#a0a0ae;--line:#2a2a35;--acc:#8aa2ff;--acc2:#1f2647;--ok:#69db7c;--code:#121218}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1200px;margin:0 auto;padding:28px 16px 80px}h1{font-size:clamp(26px,4vw,40px);line-height:1.1;margin:0 0 8px;letter-spacing:-.015em}
h2{font-size:22px;margin:34px 0 10px}h3{margin:0 0 4px;font-size:17px}.lead{color:var(--mute);max-width:780px;margin:0 0 18px}
.box{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}
.steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px}.steps .box b.k{display:inline-grid;place-items:center;width:28px;height:28px;border-radius:8px;background:var(--acc);color:#fff;margin-bottom:8px}
.seg{display:inline-flex;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:4px;gap:4px;flex-wrap:wrap}
.seg button{border:0;background:transparent;color:var(--ink);font:600 14px system-ui;padding:9px 16px;border-radius:9px;cursor:pointer}.seg button.on{background:var(--acc);color:#fff}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}
.st{background:var(--card);border:2px solid var(--line);border-radius:12px;overflow:hidden;cursor:pointer;text-align:left;padding:0;color:var(--ink);font:inherit}
.st img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover}.st div{padding:8px 10px}.st small{color:var(--mute);display:block;font-size:12px}.st.on{border-color:var(--acc);box-shadow:0 0 0 3px var(--acc2)}
.sel{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.2fr);gap:18px;align-items:start}@media(max-width:820px){.sel{grid-template-columns:1fr}}
.sel img{width:100%;border-radius:10px;border:1px solid var(--line)}
.file{margin:0 0 14px}.fh{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px}.fh h3{flex:1;font:700 15px ui-monospace,Menlo,monospace;word-break:break-all;margin:0}
.fh p{flex-basis:100%;margin:0;color:var(--mute);font-size:14px}
.btn{border:0;border-radius:10px;padding:9px 18px;font:600 14px system-ui;cursor:pointer;background:var(--acc);color:#fff;min-width:96px}.btn.sec{background:transparent;color:var(--ink);border:1px solid var(--line)}.btn.ok{background:var(--ok)}
textarea{width:100%;height:150px;resize:vertical;background:var(--code);color:var(--ink);border:1px solid var(--line);border-radius:10px;padding:10px;font:12px/1.45 ui-monospace,Menlo,monospace;white-space:pre}
ol{padding-left:20px;margin:6px 0}li{margin:3px 0}code{background:var(--code);border:1px solid var(--line);border-radius:5px;padding:1px 5px;font-size:13px}
table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left}
.note{color:var(--mute);font-size:14px}#loading{color:var(--mute)}
</style></head><body><main>
<h1>__APP__: ready-to-use Power Apps screens</h1>
<p class=lead>Thirty styles of the same four screens (Home, Dashboard, List and Form), ready to paste into Power Apps. Pick a style, choose how you want to hold the data, then copy each block into Power Apps Studio. A sample CSV is included so the screens work with a real SharePoint list too.</p>
<div class=steps>
<div class=box><b class=k>1</b><h3>Pick a style</h3><div class=note>Click any of the 30 thumbnails below.</div></div>
<div class=box><b class=k>2</b><h3>Choose a data option</h3><div class=note><b>Demo data</b> runs straight away. <b>SharePoint list</b> keeps your changes. Create the list from the sample CSV.</div></div>
<div class=box><b class=k>3</b><h3>Copy and paste</h3><div class=note>Use the Copy button on each block, then paste it into Power Apps in the order shown.</div></div>
</div>

<h2>Data option</h2>
<div class=seg id=mode><button data-m=demo class=on>Demo data (no setup)</button><button data-m=sp>SharePoint list (from CSV)</button></div>
<div class=box style="margin-top:12px" id=modehelp></div>

<h2>Sample data (CSV)</h2>
<div class=box><p style="margin:0 0 10px">__ROWS__ rows with the columns: __COLS__. The screens expect exactly these column names.</p>
<button class=btn id=dlcsv>Download sample-data.csv</button></div>

<h2>Choose a style</h2><div class=grid id=grid></div>

<h2 id=selh>Your paste blocks</h2><div id=loading>Unpacking the YAML…</div><div id=sel></div>

<h2>If something goes wrong</h2><div class=box><ul style="margin:0;padding-left:20px">
<li><b>Studio looks frozen after a paste.</b> Large screens take up to a minute. Wait rather than pasting again.</li>
<li><b>"Name isn't valid" for <code>InventoryItems</code>.</b> Add the SharePoint list as a data source first (Data → Add data → SharePoint), or rename the list to <code>InventoryItems</code>.</li>
<li><b>Category or Region shows errors.</b> Those columns must be <i>Single line of text</i> in the list, not Choice.</li>
<li><b>A font error on the Whiteboard or Chalkboard styles.</b> Replace <code>Font.'Patrick Hand'</code> with <code>Font.'Segoe UI'</code>.</li>
<li><b>A delegation warning (blue underline).</b> It's fine for lists under 2,000 rows. Set Settings → General → Data row limit to 2000.</li></ul></div>
<p class=note style="margin-top:28px">Generated by the powerapps-modern-ui skill (github.com/vikramdevesh/powerapps-modern-ui).</p>
</main>
<script>
const META=__META__, CSV=__CSV__, LIST=__LIST__, BLOB="__BLOB__";
let DATA=null, mode="demo", style="slate";
const HELP={
 demo:`<b>Demo data:</b> the sample rows live inside the app (App.Formulas), so nothing else is needed. Edits last until the app closes.<ol>
 <li>make.powerapps.com → <b>Create</b> → <b>Blank canvas app</b> → <b>Tablet</b>.</li>
 <li>Tree view → select <b>App</b> → property <b>Formulas</b> → paste block 1.</li>
 <li>Right-click <b>Screen1</b> → <b>Paste</b> each screen block (2–5).</li>
 <li>Drag <b>HomeScreen</b> to the top, delete Screen1, save, press <b>Play</b>.</li></ol>`,
 sp:`<b>SharePoint list:</b> the screens read and write the list <code>${LIST}</code> directly, so changes are saved and shared.<ol>
 <li>Download <b>sample-data.csv</b> (below).</li>
 <li>Open <b>Microsoft Lists</b> (or a SharePoint site) → <b>New list</b> → <b>From CSV</b> → upload the file.</li>
 <li>Set these column types: <b>__NUM__</b> as <i>Number</i>. Set <b>__TXT__</b> as <i>Single line of text</i>. Keep every column name unchanged. Leave the built-in Title column as it is: the app fills it.</li>
 <li>Name the list exactly <code>${LIST}</code> and create it.</li>
 <li>In Power Apps: <b>Blank canvas app</b> (Tablet) → <b>Data</b> → <b>Add data</b> → <b>SharePoint</b> → your site → tick <code>${LIST}</code>.</li>
 <li>Right-click <b>Screen1</b> → <b>Paste</b> each screen block. There is no App.Formulas block in this mode.</li>
 <li>Drag <b>HomeScreen</b> to the top, delete Screen1, save, press <b>Play</b>.</li></ol>`};
function esc(s){return s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
function dl(name,text,type){const b=new Blob([text],{type});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}
async function unpack(){const bin=Uint8Array.from(atob(BLOB),c=>c.charCodeAt(0));
 const s=new Blob([bin]).stream().pipeThrough(new DecompressionStream('gzip'));DATA=JSON.parse(await new Response(s).text());document.getElementById('loading').remove();render()}
function grid(){const g=document.getElementById('grid');g.innerHTML='';Object.entries(META).forEach(([k,m],i)=>{const b=document.createElement('button');b.className='st'+(k===style?' on':'');
 b.innerHTML=`<img src="${m.img}" alt="${esc(m.t)}"><div><b>${i+1}. ${esc(m.t)}</b><small>${esc(m.g)}</small></div>`;b.onclick=()=>{style=k;grid();render();document.getElementById('selh').scrollIntoView({behavior:'smooth'})};g.appendChild(b)})}
const HOW={"App.Formulas.txt":"Tree view → App → Formulas property → paste.","HomeScreen":"Right-click a screen → Paste. This is the start screen.","DashboardScreen":"Right-click a screen → Paste.","ListScreen":"Right-click a screen → Paste.","FormScreen":"Right-click a screen → Paste."};
function render(){document.getElementById('modehelp').innerHTML=HELP[mode];if(!DATA)return;const m=META[style];const files=DATA[style][mode];
 let h=`<div class="box sel"><div><img src="${m.img}" alt=""><p class=note style="margin:8px 0 0">${esc(m.m)}</p><p class=note style="margin:4px 0 0"><b>Best for:</b> ${esc(m.b)}</p></div><div><h3>${esc(m.t)} · ${mode==='demo'?'Demo data':'SharePoint list'}</h3><p class=note>${files.length} blocks to paste, in this order.</p>`;
 files.forEach(([n,t],i)=>{const key=Object.keys(HOW).find(k=>n.startsWith(k)||n.endsWith(k+'.pa.yaml'))||'';h+=`<div class=file><div class=fh><h3>${i+1}. ${esc(n)}</h3><button class=btn data-i=${i}>Copy</button><button class="btn sec" data-d=${i}>Download</button><p>${HOW[key]||''}</p></div><textarea readonly spellcheck=false id=ta${i}>${esc(t)}</textarea></div>`});
 h+='</div></div>';const el=document.getElementById('sel');el.innerHTML=h;
 el.querySelectorAll('[data-i]').forEach(b=>b.onclick=async()=>{const t=document.getElementById('ta'+b.dataset.i);let ok=false;try{await navigator.clipboard.writeText(t.value);ok=true}catch(e){t.focus();t.select();try{ok=document.execCommand('copy')}catch(_){}}
  b.textContent=ok?'Copied':'Press Ctrl+C';b.classList.toggle('ok',ok);setTimeout(()=>{b.textContent='Copy';b.classList.remove('ok')},2000)});
 el.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{const [n,t]=files[+b.dataset.d];dl(n,t,'text/plain')})}
document.querySelectorAll('#mode button').forEach(b=>b.onclick=()=>{mode=b.dataset.m;document.querySelectorAll('#mode button').forEach(x=>x.classList.toggle('on',x===b));render()});
document.getElementById('dlcsv').onclick=()=>dl('sample-data.csv','\\ufeff'+CSV,'text/csv');
grid();render();unpack().catch(e=>{document.getElementById('loading').textContent='Could not unpack the YAML in this browser ('+e.message+'). Use a current Chrome, Edge, Safari or Firefox.'});
</script></body></html>"""
page = (page.replace("__APP__", html.escape(app)).replace("__META__", json.dumps(meta)).replace("__CSV__", json.dumps(csv, ensure_ascii=False))
        .replace("__LIST__", json.dumps(a.list)).replace("__BLOB__", blob).replace("__ROWS__", str(len(spec["data"]["rows"])))
        .replace("__COLS__", ", ".join(f"<code>{n}</code>" for n in [f["name"] for f in fields])).replace("__NUM__", ", ".join(num)).replace("__TXT__", ", ".join(txt)))
os.makedirs(os.path.dirname(a.out), exist_ok=True); open(a.out, "w", encoding="utf-8").write(page)
open(os.path.join(os.path.dirname(a.out), "sample-data.csv"), "w", encoding="utf-8-sig").write(csv)
print(f"Wrote {a.out} ({len(page) // 1024} KB) and sample-data.csv")
