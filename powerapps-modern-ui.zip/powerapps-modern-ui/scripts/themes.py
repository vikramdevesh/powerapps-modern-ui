"""Style catalogue: each style is a token set plus a few treatment switches.

Tokens (all hex without '#', 8-digit = with alpha):
  bg, surface, surface2, line, ink, ink2, faint, acc, acc_ink (text on accent), acc_soft, acc2
  good/warn/bad = (fg, bg) for status chips, chart = 5 series colours, kpi_tints = optional per-KPI card fills
  nav_* colours, input_* colours
Fonts: font_display, font_body, font_label (Power Apps font names from pa.FONTS); w_display weight.
Shape: r_card, r_ctrl, r_pill; card = soft | glass | glow | tint | rule | offset | hairline
Layout: nav = side-dark | side-light | top
Art: bg_svg(w, h) -> full-screen background SVG or None
"""

SVGNS = "xmlns='http://www.w3.org/2000/svg'"


def _blobs(w, h, base, blobs, extra=""):
    defs, shapes = [], []
    for i, (cx, cy, r, c, op) in enumerate(blobs):
        defs.append(f"<radialGradient id='b{i}'><stop offset='0' stop-color='#{c}' stop-opacity='{op}'/><stop offset='1' stop-color='#{c}' stop-opacity='0'/></radialGradient>")
        shapes.append(f"<circle cx='{cx * w:.0f}' cy='{cy * h:.0f}' r='{r * w:.0f}' fill='url(#b{i})'/>")
    return (f"<svg {SVGNS} width='{w}' height='{h}' viewBox='0 0 {w} {h}' preserveAspectRatio='none'><defs>{''.join(defs)}</defs>"
            f"<rect width='{w}' height='{h}' fill='#{base}'/>{''.join(shapes)}{extra}</svg>")


def bg_midnight(w, h):
    grid = (f"<defs><pattern id='g' width='40' height='40' patternUnits='userSpaceOnUse'><path d='M40 0H0V40' fill='none' stroke='#8ea2ff' stroke-opacity='0.06'/></pattern></defs>"
            f"<rect width='{w}' height='{h}' fill='url(#g)'/>")
    return _blobs(w, h, "070b1a", [(0.82, 0.05, 0.38, "6d4aff", 0.35), (0.25, 1.0, 0.35, "00c2ff", 0.18), (0.55, 0.55, 0.25, "3b2bd9", 0.10)], grid)


def bg_aurora(w, h):
    return _blobs(w, h, "f6f5fb", [(0.15, 0.1, 0.42, "ffb3d9", 0.55), (0.85, 0.15, 0.40, "b8a6ff", 0.55), (0.6, 0.95, 0.45, "8ee6d8", 0.55), (0.05, 0.9, 0.3, "ffd9a8", 0.45)])


def bg_keynote(w, h):
    return _blobs(w, h, "000000", [(0.5, -0.1, 0.55, "2a2a35", 0.9), (0.85, 1.05, 0.3, "1a3a66", 0.45)])


def bg_editorial(w, h):
    noise = ("<filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/>"
             "<feColorMatrix values='0 0 0 0 0.2  0 0 0 0 0.15  0 0 0 0 0.1  0 0 0 0.07 0'/></filter>")
    return (f"<svg {SVGNS} width='{w}' height='{h}' viewBox='0 0 {w} {h}' preserveAspectRatio='none'><defs>{noise}</defs>"
            f"<rect width='{w}' height='{h}' fill='#efeadf'/><rect width='{w}' height='{h}' filter='url(#n)'/></svg>")


def bg_brutal(w, h):
    dots = (f"<defs><pattern id='d' width='22' height='22' patternUnits='userSpaceOnUse'><circle cx='2' cy='2' r='1.4' fill='#000' fill-opacity='0.13'/></pattern></defs>"
            f"<rect width='{w}' height='{h}' fill='url(#d)'/>")
    return f"<svg {SVGNS} width='{w}' height='{h}' viewBox='0 0 {w} {h}' preserveAspectRatio='none'><rect width='{w}' height='{h}' fill='#fff8e7'/>{dots}</svg>"


STYLES = {
    "fluent": dict(
        title="Fluent Enterprise", mood="Familiar Microsoft 365 look. Calm neutrals, one brand blue, compact and dependable.",
        best="Internal line-of-business apps, approvals, HR / IT / finance tools, anything that sits next to Teams and SharePoint.",
        atlas="Clean product UI (Fluent 2 design language)",
        bg="f5f5f5", surface="ffffff", surface2="fafafa", line="e0e0e0", ink="242424", ink2="616161", faint="9e9e9e",
        acc="0f6cbd", acc_ink="ffffff", acc_soft="ebf3fc", acc2="115ea3",
        good=("0e700e", "f1faf1"), warn=("8a5000", "fff9f5"), bad=("b10e1c", "fdf3f4"),
        chart=["0f6cbd", "4f6bed", "00a5af", "c239b3", "e97548"], kpi_tints=None,
        nav="top", nav_bg="0f6cbd", nav_ink="ffffff", nav_muted="cfe4fa", nav_act_bg="115ea3", nav_act_ink="ffffff",
        input_bg="ffffff", input_line="d1d1d1", input_bthick=1,
        font_display="Segoe UI", w_display="semi", font_body="Segoe UI", font_label="Segoe UI",
        r_card=8, r_ctrl=4, r_pill=4, card="soft", bg_svg=None, scale=1.0),
    "slate": dict(
        title="Slate & Indigo", mood="Crisp modern SaaS. Dark sidebar, white cards with soft shadow, indigo accent, generous spacing.",
        best="Dashboards, admin consoles, inventory / CRM / ticketing masters.",
        atlas="Modern SaaS dashboard",
        bg="f1f5f9", surface="ffffff", surface2="f8fafc", line="e2e8f0", ink="0f172a", ink2="64748b", faint="94a3b8",
        acc="4f46e5", acc_ink="ffffff", acc_soft="eef2ff", acc2="4338ca",
        good=("15803d", "dcfce7"), warn=("b45309", "fef3c7"), bad=("b91c1c", "fee2e2"),
        chart=["6366f1", "0ea5e9", "14b8a6", "f59e0b", "ec4899"], kpi_tints=None,
        nav="side-dark", nav_bg="0f172a", nav_ink="e2e8f0", nav_muted="94a3b8", nav_act_bg="1e293b", nav_act_ink="ffffff",
        input_bg="ffffff", input_line="cbd5e1", input_bthick=1,
        font_display="Segoe UI", w_display="bold", font_body="Segoe UI", font_label="Segoe UI",
        r_card=14, r_ctrl=8, r_pill=17, card="soft", bg_svg=None, scale=1.0),
    "midnight": dict(
        title="Midnight Glow", mood="Dark command-centre. Deep navy, faint grid, violet and cyan glows, neon-edged glass panels.",
        best="Ops / monitoring dashboards, IT and security consoles, data-heavy screens shown on big displays.",
        atlas="Tech Glow Explainer",
        bg="070b1a", surface="0f1630e6", surface2="141d3d", line="2a3566", ink="eef1ff", ink2="98a3d4", faint="5d6899",
        acc="7c5cff", acc_ink="ffffff", acc_soft="7c5cff33", acc2="22d3ee",
        good=("4ade80", "4ade8026"), warn=("fbbf24", "fbbf2426"), bad=("fb7185", "fb718526"),
        chart=["7c5cff", "22d3ee", "a78bfa", "38bdf8", "f472b6"], kpi_tints=None,
        nav="side-dark", nav_bg="0a0f24", nav_ink="dfe4ff", nav_muted="7d88bb", nav_act_bg="7c5cff26", nav_act_ink="ffffff",
        input_bg="0d1430", input_line="2f3b70", input_bthick=1,
        font_display="Segoe UI", w_display="semi", font_body="Segoe UI", font_label="Segoe UI",
        r_card=16, r_ctrl=10, r_pill=17, card="glow", bg_svg=bg_midnight, scale=1.0),
    "aurora": dict(
        title="Aurora Glass", mood="Airy and optimistic. Soft aurora gradient backdrop with frosted white glass cards and a floating top bar.",
        best="Employee portals, self-service apps, booking and request apps, home / landing screens.",
        atlas="Glassmorphism on gradient mesh",
        bg="f6f5fb", surface="ffffffb8", surface2="ffffffe0", line="ffffff", ink="1e1b3a", ink2="5f5a7d", faint="9a95b5",
        acc="5b3df5", acc_ink="ffffff", acc_soft="5b3df51f", acc2="db2777",
        good=("047857", "d1fae5cc"), warn=("a16207", "fef3c7cc"), bad=("be123c", "ffe4e6cc"),
        chart=["5b3df5", "db2777", "0d9488", "f59e0b", "6366f1"], kpi_tints=None,
        nav="top", nav_bg="ffffffc4", nav_ink="1e1b3a", nav_muted="5f5a7d", nav_act_bg="1e1b3a", nav_act_ink="ffffff",
        input_bg="ffffffe6", input_line="d9d4f0", input_bthick=1,
        font_display="Lato Black", w_display="normal", font_body="Lato", font_label="Lato",
        r_card=22, r_ctrl=12, r_pill=18, card="glass", bg_svg=bg_aurora, scale=1.0, float_nav=True, pill_off="ffffffb0", divider="ffffff", tipbg="ffffff"),
    "pastel": dict(
        title="Soft Pastel", mood="Friendly and rounded. Pastel colour blocks, big radii, a single coral accent, no hard borders.",
        best="Retail floor, education, wellbeing, onboarding and front-line apps used on tablets.",
        atlas="Isometric Pastel",
        bg="eef0fa", surface="ffffff", surface2="f6f7fd", line="e6e8f5", ink="2b2d42", ink2="6b6f8e", faint="a3a7c2",
        acc="ff6b5b", acc_ink="ffffff", acc_soft="ffe7e4", acc2="2b2d42",
        good=("2f855a", "dcf5e7"), warn=("b7791f", "fff1d6"), bad=("c53030", "ffe3e3"),
        chart=["ff8a7a", "8b9cff", "5fd3b3", "ffc65c", "c79bff"], kpi_tints=["ffe7e4", "e3e7ff", "d9f6ee", "fff1d6"],
        nav="side-light", nav_bg="ffffff", nav_ink="2b2d42", nav_muted="8a8fae", nav_act_bg="ffe7e4", nav_act_ink="e2493a",
        input_bg="f6f7fd", input_line="e1e4f3", input_bthick=1,
        font_display="Lato Black", w_display="normal", font_body="Open Sans", font_label="Open Sans",
        r_card=24, r_ctrl=14, r_pill=18, card="tint", bg_svg=None, scale=1.0, hero_fill=True, pill_noborder=True),
    "editorial": dict(
        title="Editorial Paper", mood="Magazine layout. Warm grainy paper, Georgia serif headlines, hairline rules, a highlighter accent.",
        best="Reports and briefings, knowledge bases, policy / content apps, executive summaries.",
        atlas="Editorial Essay Collage",
        bg="efeadf", surface="faf7f0", surface2="f4efe4", line="1a1a1a", ink="1a1a1a", ink2="5c574f", faint="8d877c",
        acc="1a1a1a", acc_ink="faf7f0", acc_soft="ffe14d", acc2="c8102e",
        good=("1f5f3a", "dbe8d4"), warn=("7a5200", "ffe9a8"), bad=("a30d24", "f6d3cf"),
        chart=["1a1a1a", "c8102e", "8d877c", "d9a400", "3b5b7a"], kpi_tints=None,
        nav="top", nav_bg="efeadf00", nav_ink="1a1a1a", nav_muted="5c574f", nav_act_bg="ffe14d", nav_act_ink="1a1a1a",
        input_bg="faf7f0", input_line="1a1a1a", input_bthick=1,
        font_display="Georgia", w_display="normal", font_body="Segoe UI", font_label="Segoe UI",
        r_card=0, r_ctrl=0, r_pill=0, card="rule", bg_svg=bg_editorial, scale=1.0, logo="letter", nav_rule=True, sort_acc="c8102e", pill_off="efeadf"),
    "brutal": dict(
        title="Neo-Brutalist", mood="Loud and confident. Thick black outlines, hard offset shadows, saturated blocks, monospace labels.",
        best="Creative teams, campaigns, events, start-up tools, anything that should feel energetic and un-corporate.",
        atlas="Halftone Pop Panel / bold print",
        bg="fff8e7", surface="ffffff", surface2="fff1c2", line="000000", ink="000000", ink2="333333", faint="777777",
        acc="2f5bff", acc_ink="ffffff", acc_soft="ffd400", acc2="ff5ca8",
        good=("000000", "7cf5a4"), warn=("000000", "ffd400"), bad=("ffffff", "ff4d4d"),
        chart=["2f5bff", "ff5ca8", "00c27a", "ffd400", "9b5cff"], kpi_tints=["ffd400", "ffffff", "ffffff", "ff9ec9"],
        nav="side-light", nav_bg="ffd400", nav_ink="000000", nav_muted="000000", nav_act_bg="000000", nav_act_ink="ffd400",
        input_bg="ffffff", input_line="000000", input_bthick=2,
        font_display="Lato Black", w_display="normal", font_body="Lato", font_label="Courier New",
        r_card=10, r_ctrl=8, r_pill=8, card="offset", bg_svg=bg_brutal, scale=1.0, outline=True, hero_fill=True),
    "keynote": dict(
        title="Keynote Noir", mood="Product-launch stage. Near-black, spotlight gradient, oversized light-weight numbers, hairline panels.",
        best="Executive / CEO dashboards, sales leaderboards, kiosk and wallboard screens.",
        atlas="Product Launch Reveal",
        bg="000000", surface="111114", surface2="1c1c21", line="2c2c33", ink="f5f5f7", ink2="8e8e96", faint="5c5c66",
        acc="2997ff", acc_ink="ffffff", acc_soft="2997ff26", acc2="bf5af2",
        good=("30d158", "30d15822"), warn=("ffd60a", "ffd60a1f"), bad=("ff453a", "ff453a24"),
        chart=["2997ff", "bf5af2", "64d2ff", "30d158", "ff9f0a"], kpi_tints=None,
        nav="top", nav_bg="00000000", nav_ink="f5f5f7", nav_muted="8e8e96", nav_act_bg="2c2c33", nav_act_ink="ffffff",
        input_bg="1c1c21", input_line="3a3a42", input_bthick=1,
        font_display="Lato Light", w_display="normal", font_body="Segoe UI", font_label="Segoe UI",
        r_card=18, r_ctrl=10, r_pill=17, card="hairline", bg_svg=bg_keynote, scale=1.0),
}
ORDER = ["fluent", "slate", "midnight", "aurora", "pastel", "editorial", "brutal", "keynote"]
for _k in ORDER: STYLES[_k].setdefault("group", "Modern business")
STYLES["pastel"]["atlas"] = "Isometric Pastel (AI Style Atlas)"; STYLES["midnight"]["atlas"] = "Tech Glow Explainer (AI Style Atlas)"
STYLES["keynote"]["atlas"] = "Product Launch Reveal (AI Style Atlas)"; STYLES["editorial"]["atlas"] = "Editorial Essay Collage (AI Style Atlas)"

from styles_more import MORE, MORE_ORDER  # noqa: E402
STYLES.update(MORE); ORDER = ORDER + MORE_ORDER


def theme(key):
    t = dict(STYLES[key]); t["key"] = key
    dark = is_dark(t)
    t.setdefault("divider", t["line"][:6])
    t.setdefault("tipbg", t["surface2"][:6])
    t.setdefault("pill_off", t["surface2"] if dark else "ffffff")
    t.setdefault("header_ink", t["ink"]); t.setdefault("header_ink2", t["ink2"])
    return t


def is_dark(t):
    h = t["bg"][:6]; r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (0.299 * r + 0.587 * g + 0.114 * b) < 100
