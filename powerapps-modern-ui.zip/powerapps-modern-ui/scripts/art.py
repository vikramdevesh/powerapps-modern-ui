"""SVG art for the extended styles: card treatments and full-screen backgrounds.

Card functions: (T, w, h, fill_css, radius, margin, emph) -> (defs, body). The card sits at (m, m) inside a (w+2m) x (h+2m) SVG.
Background functions: (w, h) -> full SVG string. Single quotes only (the SVG is embedded in a Power Fx string).
"""
import random
NS = "xmlns='http://www.w3.org/2000/svg'"


def _blur(id_, sd): return f"<filter id='{id_}' x='-20%' y='-20%' width='140%' height='150%'><feGaussianBlur stdDeviation='{sd}'/></filter>"
def _rr(m, w, h, r, extra): return f"<rect x='{m}' y='{m}' width='{w}' height='{h}' rx='{r}' {extra}/>"


# ---------------- card treatments ----------------
def c_paper(T, w, h, f, r, m, e):
    d = _blur("s", 2.5)
    b = (f"<rect x='{m + 3}' y='{m + 5}' width='{w}' height='{h}' rx='{r}' fill='#1d2a1f' fill-opacity='0.35' filter='url(#s)'/>"
         + _rr(m, w, h, r, f"fill='{f}'")
         + f"<rect x='{m + 7}' y='{m + 7}' width='{w - 14}' height='{h - 14}' rx='{max(0, r - 2)}' fill='none' stroke='#{T['line'][:6]}' stroke-dasharray='5 4' stroke-width='1.2'/>"
         + f"<path d='M{m + w - 22},{m} l22,0 l0,22 z' fill='#000' fill-opacity='0.06'/>")
    return d, b


def c_wash(T, w, h, f, r, m, e):
    d = ("<filter id='wc' x='-10%' y='-10%' width='120%' height='120%'><feTurbulence type='fractalNoise' baseFrequency='0.018' numOctaves='3' seed='4'/>"
         "<feDisplacementMap in='SourceGraphic' scale='22'/><feGaussianBlur stdDeviation='1.2'/></filter>")
    b = (f"<rect x='{m + 4}' y='{m + 4}' width='{w - 4}' height='{h - 2}' fill='#{T['acc2'][:6]}' fill-opacity='{0.22 if e else 0.13}' filter='url(#wc)'/>"
         + _rr(m + 6, w - 12, h - 12, r, f"fill='{f}' fill-opacity='0.9' stroke='#{T['line'][:6]}' stroke-opacity='0.5'"))
    return d, b


def c_cutout(T, w, h, f, r, m, e):
    d = _blur("s", 10)
    holes = "".join(f"<circle cx='{m + x}' cy='{m + 9}' r='2.6'/><circle cx='{m + x}' cy='{m + h - 9}' r='2.6'/>" for x in range(18, w - 12, 16))
    b = (_rr(m, w, h, r, f"fill='#ffb347' fill-opacity='0.25' filter='url(#s)'") + _rr(m, w, h, r, f"fill='{f}'")
         + f"<g fill='#ffb347' fill-opacity='0.55'>{holes}</g>")
    return d, b


def c_sketch(T, w, h, f, r, m, e):
    c = T.get("sketch", T["ink"])
    d = ("<filter id='wob'><feTurbulence type='fractalNoise' baseFrequency='0.03' numOctaves='2' seed='7'/><feDisplacementMap in='SourceGraphic' scale='5'/></filter>"
         "<filter id='wob2'><feTurbulence type='fractalNoise' baseFrequency='0.025' numOctaves='2' seed='19'/><feDisplacementMap in='SourceGraphic' scale='6'/></filter>")
    b = (_rr(m + 2, w - 4, h - 4, r, f"fill='{f}'")
         + _rr(m + 2, w - 4, h - 4, r, f"fill='none' stroke='#{c}' stroke-width='2.4' stroke-linecap='round' filter='url(#wob)'")
         + _rr(m + 3, w - 6, h - 5, r, f"fill='none' stroke='#{c}' stroke-opacity='0.55' stroke-width='1.4' filter='url(#wob2)'"))
    return d, b


def c_ring(T, w, h, f, r, m, e):
    b = (_rr(m + 1.5, w - 3, h - 3, r, f"fill='{f}' stroke='#{T['acc2'][:6]}' stroke-width='3'")
         + _rr(m + 7, w - 14, h - 14, max(0, r - 5), f"fill='none' stroke='#{T['acc']}' stroke-width='2'"))
    return "", b


def c_frame(T, w, h, f, r, m, e):
    c = T.get("frame", T["acc"])
    return "", _rr(m + .75, w - 1.5, h - 1.5, r, f"fill='{f}' stroke='#{c}' stroke-opacity='{1 if e else 0.75}' stroke-width='1.5'")


def c_illum(T, w, h, f, r, m, e):
    g, v = T["acc2"][:6], T["acc"]
    dots = "".join(f"<circle cx='{cx}' cy='{cy}' r='3.2' fill='#{g}'/>" for cx, cy in ((m + 5, m + 5), (m + w - 5, m + 5), (m + 5, m + h - 5), (m + w - 5, m + h - 5)))
    b = (_rr(m, w, h, 0, f"fill='{f}'") + _rr(m + 1, w - 2, h - 2, 0, f"fill='none' stroke='#{g}' stroke-width='2'")
         + _rr(m + 6, w - 12, h - 12, 0, f"fill='none' stroke='#{v}' stroke-width='0.8'") + dots)
    return "", b


def c_halftone(T, w, h, f, r, m, e):
    d = (f"<pattern id='ht' width='7' height='7' patternUnits='userSpaceOnUse'><circle cx='3.5' cy='3.5' r='2.1' fill='#{T['acc']}'/></pattern>")
    b = (f"<rect x='{m + 8}' y='{m + 8}' width='{w - 8}' height='{h - 8}' fill='url(#ht)'/>"
         f"<rect x='{m + 1.5}' y='{m + 1.5}' width='{w - 9}' height='{h - 9}' rx='{r}' fill='{f}' stroke='#000' stroke-width='3'/>")
    return d, b


def c_neon(T, w, h, f, r, m, e):
    d = _blur("g", 6)
    b = (_rr(m + 1, w - 2, h - 2, r, f"fill='none' stroke='#{T['acc']}' stroke-width='3' stroke-opacity='{0.75 if e else 0.45}' filter='url(#g)'")
         + _rr(m + 1, w - 2, h - 2, r, f"fill='{f}' stroke='#{T['acc'] if e else T['acc2'][:6]}' stroke-width='1.3'"))
    return d, b


def c_bevel(T, w, h, f, r, m, e):
    x0, y0, x1, y1 = m, m, m + w, m + h
    b = (f"<rect x='{x0}' y='{y0}' width='{w}' height='{h}' fill='{f}'/>"
         f"<path d='M{x0},{y1} L{x0},{y0} L{x1},{y0}' fill='none' stroke='#ffffff' stroke-width='2'/>"
         f"<path d='M{x0 + 2},{y1 - 1} L{x1 - 1},{y1 - 1} L{x1 - 1},{y0 + 2}' fill='none' stroke='#808080' stroke-width='2'/>"
         f"<path d='M{x0},{y1} L{x1},{y1} L{x1},{y0}' fill='none' stroke='#0a0a0a' stroke-width='1.5'/>")
    return "", b


def _step(x, y, w, h, s):
    return (f"M{x + 2 * s},{y} H{x + w - 2 * s} V{y + s} H{x + w - s} V{y + 2 * s} H{x + w} V{y + h - 2 * s} H{x + w - s} V{y + h - s} H{x + w - 2 * s} V{y + h} "
            f"H{x + 2 * s} V{y + h - s} H{x + s} V{y + h - 2 * s} H{x} V{y + 2 * s} H{x + s} V{y + s} H{x + 2 * s} Z")


def c_pixel(T, w, h, f, r, m, e):
    c = T.get("frame", T["acc"])
    b = (f"<path d='{_step(m + 6, m + 6, w - 6, h - 6, 4)}' fill='#000' fill-opacity='0.45'/>"
         f"<path d='{_step(m, m, w - 6, h - 6, 4)}' fill='{f}' stroke='#{c}' stroke-width='3' shape-rendering='crispEdges'/>")
    return "", b


def c_dashed(T, w, h, f, r, m, e):
    c = T.get("frame", "ffffff")
    ticks = "".join(f"<path d='M{x},{y} {d}' stroke='#{c}' stroke-width='1.5' fill='none'/>" for x, y, d in
                    ((m - 6, m, "h12"), (m, m - 6, "v12"), (m + w - 6, m + h, "h12"), (m + w, m + h - 6, "v12")))
    b = _rr(m, w, h, r, f"fill='{f}' stroke='#{c}' stroke-opacity='0.8' stroke-dasharray='6 4' stroke-width='1.2'") + ticks
    return "", b


def c_clay(T, w, h, f, r, m, e):
    d = (_blur("s", 9) + "<linearGradient id='hl' x1='0' y1='0' x2='0.6' y2='1'><stop offset='0' stop-color='#fff' stop-opacity='0.9'/><stop offset='0.45' stop-color='#fff' stop-opacity='0'/></linearGradient>"
         "<linearGradient id='sh' x1='0' y1='0' x2='0' y2='1'><stop offset='0.6' stop-color='#000' stop-opacity='0'/><stop offset='1' stop-color='#000' stop-opacity='0.06'/></linearGradient>")
    b = (f"<rect x='{m + 8}' y='{m + 12}' width='{w - 16}' height='{h - 8}' rx='{r}' fill='#{T['acc']}' fill-opacity='0.22' filter='url(#s)'/>"
         + _rr(m, w, h, r, f"fill='{f}'") + _rr(m, w, h, r, "fill='url(#sh)'") + _rr(m + 2, w - 4, h - 4, r - 2, "fill='none' stroke='url(#hl)' stroke-width='2.5'"))
    return d, b


def c_riso(T, w, h, f, r, m, e):
    b = (f"<rect x='{m + 6}' y='{m + 6}' width='{w - 6}' height='{h - 6}' rx='{r}' fill='#{T['acc2'][:6]}' fill-opacity='0.75'/>"
         f"<rect x='{m}' y='{m}' width='{w - 6}' height='{h - 6}' rx='{r}' fill='{f}'/>"
         f"<rect x='{m + 2.5}' y='{m + 1.5}' width='{w - 8}' height='{h - 8}' rx='{r}' fill='none' stroke='#{T['acc']}' stroke-width='2' stroke-opacity='0.9'/>")
    return "", b


def c_deco(T, w, h, f, r, m, e):
    g = T["acc"]; s = 10
    corners = "".join(f"<path d='{p}' fill='none' stroke='#{g}' stroke-width='1.2'/>" for p in (
        f"M{m + 6},{m + 6 + s} V{m + 6} H{m + 6 + s}", f"M{m + w - 6 - s},{m + 6} H{m + w - 6} V{m + 6 + s}",
        f"M{m + 6},{m + h - 6 - s} V{m + h - 6} H{m + 6 + s}", f"M{m + w - 6 - s},{m + h - 6} H{m + w - 6} V{m + h - 6 - s}"))
    b = (_rr(m, w, h, 0, f"fill='{f}' stroke='#{g}' stroke-width='1.5'") + _rr(m + 4, w - 8, h - 8, 0, f"fill='none' stroke='#{g}' stroke-opacity='0.45' stroke-width='0.8'") + corners)
    return "", b


EXTRA_CARDS = {"paper": c_paper, "wash": c_wash, "cutout": c_cutout, "sketch": c_sketch, "ring": c_ring, "frame": c_frame, "illum": c_illum,
               "halftone": c_halftone, "neon": c_neon, "bevel": c_bevel, "pixel": c_pixel, "dashed": c_dashed, "clay": c_clay, "riso": c_riso, "deco": c_deco}


# ---------------- backgrounds ----------------
def _svg(w, h, defs, body): return f"<svg {NS} width='{w}' height='{h}' viewBox='0 0 {w} {h}' preserveAspectRatio='none'><defs>{defs}</defs>{body}</svg>"
def _noise(id_, freq, rgb, alpha, seed=3):
    r, g, b = rgb
    return (f"<filter id='{id_}'><feTurbulence type='fractalNoise' baseFrequency='{freq}' numOctaves='3' seed='{seed}' stitchTiles='stitch'/>"
            f"<feColorMatrix values='0 0 0 0 {r}  0 0 0 0 {g}  0 0 0 0 {b}  0 0 0 {alpha} 0'/></filter>")


def bg_papercraft(w, h):
    d = ("<pattern id='mn' width='20' height='20' patternUnits='userSpaceOnUse'><path d='M20 0H0V20' fill='none' stroke='#cfe8b5' stroke-opacity='0.18'/></pattern>"
         "<pattern id='mj' width='100' height='100' patternUnits='userSpaceOnUse'><path d='M100 0H0V100' fill='none' stroke='#d6f0bd' stroke-opacity='0.35' stroke-width='1.4'/></pattern>")
    ticks = "".join(f"<path d='M{x} {h - 14}v{14 if x % 100 == 0 else 7}' stroke='#d6f0bd' stroke-opacity='0.5'/>" for x in range(0, w, 20))
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#3f7d4f'/><rect width='{w}' height='{h}' fill='url(#mn)'/><rect width='{w}' height='{h}' fill='url(#mj)'/>{ticks}")


def bg_flatvector(w, h):
    R = random.Random(5)
    stars = "".join(f"<circle cx='{R.randint(0, w)}' cy='{R.randint(0, h)}' r='{R.choice([0.8, 1, 1.4, 2])}' fill='#fff' fill-opacity='{R.choice([0.35, 0.6, 0.9])}'/>" for _ in range(90))
    d = ("<linearGradient id='sky' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#0f1446'/><stop offset='1' stop-color='#3b1a6e'/></linearGradient>"
         "<radialGradient id='pl' cx='0.35' cy='0.3'><stop offset='0' stop-color='#ffb46b'/><stop offset='1' stop-color='#e2572c'/></radialGradient>"
         "<radialGradient id='gl'><stop offset='0' stop-color='#ff9d5c' stop-opacity='0.35'/><stop offset='1' stop-color='#ff9d5c' stop-opacity='0'/></radialGradient>")
    px, py = w - 90, h - 70
    planet = (f"<circle cx='{px}' cy='{py}' r='190' fill='url(#gl)'/><ellipse cx='{px}' cy='{py}' rx='150' ry='30' fill='none' stroke='#ffd59a' stroke-opacity='0.7' stroke-width='9' transform='rotate(-18 {px} {py})'/>"
              f"<circle cx='{px}' cy='{py}' r='88' fill='url(#pl)'/><path d='M{px - 88},{py} a88,88 0 0,0 176,0 a100,70 0 0,1 -176,0z' fill='#000' fill-opacity='0.18'/>")
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#sky)'/>{stars}{planet}")


def bg_watercolor(w, h):
    d = _noise("n", 0.8, (0.45, 0.4, 0.35), 0.06) + ("<filter id='wc'><feTurbulence type='fractalNoise' baseFrequency='0.006' numOctaves='3' seed='2'/><feDisplacementMap in='SourceGraphic' scale='90'/><feGaussianBlur stdDeviation='6'/></filter>")
    blobs = (f"<g filter='url(#wc)'><ellipse cx='{w * 0.92}' cy='{h * 0.08}' rx='260' ry='170' fill='#7aa7d9' fill-opacity='0.25'/>"
             f"<ellipse cx='{w * 0.12}' cy='{h * 0.98}' rx='300' ry='160' fill='#e59aa8' fill-opacity='0.2'/><ellipse cx='{w * 0.55}' cy='{h * 1.05}' rx='240' ry='90' fill='#9ccfa6' fill-opacity='0.2'/></g>")
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#fbfaf6'/>{blobs}<rect width='{w}' height='{h}' filter='url(#n)'/>")


def bg_shadow(w, h):
    d = ("<radialGradient id='lamp' cx='0.55' cy='0.42' r='0.75'><stop offset='0' stop-color='#ffcf7a'/><stop offset='0.45' stop-color='#e9852f'/><stop offset='1' stop-color='#4a1709'/></radialGradient>"
         + _noise("n", 0.6, (0.2, 0.08, 0.02), 0.12))
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#lamp)'/><rect width='{w}' height='{h}' filter='url(#n)'/>")


def bg_whiteboard(w, h):
    d = "<linearGradient id='sh' x1='0' y1='0' x2='1' y2='0.4'><stop offset='0.3' stop-color='#fff' stop-opacity='0'/><stop offset='0.5' stop-color='#fff' stop-opacity='0.85'/><stop offset='0.7' stop-color='#fff' stop-opacity='0'/></linearGradient>"
    R = random.Random(9)
    ghosts = "".join(f"<path d='M{x},{y} q40,-12 80,0 t80,0 t80,4' fill='none' stroke='#8a9aa8' stroke-opacity='0.07' stroke-width='5' stroke-linecap='round'/>"
                     for x, y in ((R.randint(250, 1100), R.randint(60, 720)) for _ in range(12)))
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#f3f5f4'/>{ghosts}<rect width='{w}' height='{h}' fill='url(#sh)'/>")


def bg_psychedelic(w, h):
    cols = ["ff6a00", "ff2e88", "7b2ff7", "ffb000", "00b3a4"]
    rings = "".join(f"<circle cx='{w * 0.62}' cy='{h * 0.5}' r='{r}' fill='#{cols[i % 5]}'/>" for i, r in enumerate(range(1300, 0, -55)))
    return _svg(w, h, "", f"<rect width='{w}' height='{h}' fill='#2a0a3d'/><g opacity='0.85'>{rings}</g>")


def bg_noir(w, h):
    d = _noise("n", 0.9, (1, 1, 1), 0.08) + "<radialGradient id='v' cx='0.6' cy='0.35' r='0.8'><stop offset='0' stop-color='#3a3a3a'/><stop offset='1' stop-color='#050505'/></radialGradient>"
    blinds = "".join(f"<path d='M{x},0 L{x + 380},{h} L{x + 410},{h} L{x + 30},0 Z' fill='#fff' fill-opacity='0.05'/>" for x in range(200, 1500, 70))
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#v)'/>{blinds}<rect width='{w}' height='{h}' filter='url(#n)'/>")


def bg_manim(w, h):
    d = "<pattern id='g' width='60' height='60' patternUnits='userSpaceOnUse'><path d='M60 0H0V60' fill='none' stroke='#58c4dd' stroke-opacity='0.08'/></pattern>"
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#000'/><rect width='{w}' height='{h}' fill='url(#g)'/>")


def bg_manuscript(w, h):
    d = _noise("n", 0.012, (0.55, 0.4, 0.2), 0.16, 8) + _noise("f", 0.9, (0.4, 0.3, 0.2), 0.07)
    rules = "".join(f"<path d='M0 {y}H{w}' stroke='#9b7b4a' stroke-opacity='0.08'/>" for y in range(30, h, 28))
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#f1e3c2'/><rect width='{w}' height='{h}' filter='url(#n)'/>{rules}<rect width='{w}' height='{h}' filter='url(#f)'/>")


def bg_deepsea(w, h):
    R = random.Random(11)
    snow = "".join(f"<circle cx='{R.randint(0, w)}' cy='{R.randint(0, h)}' r='{R.choice([0.7, 1, 1.5])}' fill='#bff6ff' fill-opacity='{R.choice([0.15, 0.3, 0.5])}'/>" for _ in range(140))
    d = ("<linearGradient id='sea' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#022633'/><stop offset='1' stop-color='#00070b'/></linearGradient>"
         "<radialGradient id='a'><stop offset='0' stop-color='#22e1ff' stop-opacity='0.35'/><stop offset='1' stop-color='#22e1ff' stop-opacity='0'/></radialGradient>"
         "<radialGradient id='b'><stop offset='0' stop-color='#ff4fd8' stop-opacity='0.25'/><stop offset='1' stop-color='#ff4fd8' stop-opacity='0'/></radialGradient>")
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#sea)'/><circle cx='{w * 0.85}' cy='{h * 0.2}' r='320' fill='url(#a)'/><circle cx='{w * 0.25}' cy='{h * 0.95}' r='280' fill='url(#b)'/>{snow}")


def bg_halftone(w, h):
    d = "<pattern id='d' width='18' height='18' patternUnits='userSpaceOnUse'><circle cx='9' cy='9' r='4' fill='#e10600' fill-opacity='0.28'/></pattern>"
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#ffe14d'/><rect width='{w}' height='{h}' fill='url(#d)'/>")


def bg_synthwave(w, h):
    d = ("<linearGradient id='sky' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#120326'/><stop offset='0.62' stop-color='#3a0b5c'/><stop offset='0.62' stop-color='#12021f'/></linearGradient>"
         "<linearGradient id='sun' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='#ffe66d'/><stop offset='1' stop-color='#ff2fd2'/></linearGradient>")
    hz = h * 0.62; cx = w * 0.6
    sun = f"<circle cx='{cx}' cy='{hz - 10}' r='150' fill='url(#sun)' opacity='0.85'/>" + "".join(
        f"<rect x='{cx - 160}' y='{hz - 70 + i * 14}' width='320' height='{3 + i}' fill='#3a0b5c'/>" for i in range(5))
    grid = "".join(f"<path d='M{cx},{hz} L{cx + k * 260},{h}' stroke='#ff2fd2' stroke-opacity='0.55'/>" for k in range(-8, 9))
    grid += "".join(f"<path d='M0,{hz + (h - hz) * (t * t)} H{w}' stroke='#ff2fd2' stroke-opacity='0.5'/>" for t in [i / 9 for i in range(1, 10)])
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#sky)'/>{sun}{grid}")


def bg_retroos(w, h):
    return _svg(w, h, "", f"<rect width='{w}' height='{h}' fill='#008080'/>")


def bg_pixel(w, h):
    R = random.Random(2)
    st = "".join(f"<rect x='{R.randint(0, w // 4) * 4}' y='{R.randint(0, h // 4) * 4}' width='{R.choice([2, 4])}' height='{R.choice([2, 4])}' fill='#{R.choice(['ffffff', 'ffcc00', '4dd0ff'])}' fill-opacity='0.6'/>" for _ in range(110))
    d = "<pattern id='sl' width='4' height='4' patternUnits='userSpaceOnUse'><rect width='4' height='1' fill='#000' fill-opacity='0.25'/></pattern>"
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#1a1433'/>{st}<rect width='{w}' height='{h}' fill='url(#sl)'/>")


def bg_terminal(w, h):
    d = ("<pattern id='sl' width='3' height='3' patternUnits='userSpaceOnUse'><rect width='3' height='1' fill='#000' fill-opacity='0.35'/></pattern>"
         "<radialGradient id='v' cx='0.5' cy='0.5' r='0.75'><stop offset='0' stop-color='#0b2a12'/><stop offset='1' stop-color='#010502'/></radialGradient>")
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#v)'/><rect width='{w}' height='{h}' fill='url(#sl)'/>")


def bg_blueprint(w, h):
    d = ("<pattern id='mn' width='16' height='16' patternUnits='userSpaceOnUse'><path d='M16 0H0V16' fill='none' stroke='#fff' stroke-opacity='0.07'/></pattern>"
         "<pattern id='mj' width='80' height='80' patternUnits='userSpaceOnUse'><path d='M80 0H0V80' fill='none' stroke='#fff' stroke-opacity='0.16'/></pattern>")
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#0d4f8b'/><rect width='{w}' height='{h}' fill='url(#mn)'/><rect width='{w}' height='{h}' fill='url(#mj)'/>")


def bg_bauhaus(w, h):
    body = (f"<rect width='{w}' height='{h}' fill='#f2ead8'/><circle cx='{w - 40}' cy='-30' r='170' fill='#e63322'/>"
            f"<path d='M0,{h} V{h - 230} A230,230 0 0,1 230,{h} Z' fill='#1f4fa3'/><path d='M{w - 260},{h} L{w - 130},{h - 200} L{w},{h} Z' fill='#f6c445'/>"
            f"<rect x='{w * 0.45}' y='{h - 14}' width='260' height='14' fill='#111'/>")
    return _svg(w, h, "", body)


def bg_clay(w, h):
    d = "<linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#ffe8f1'/><stop offset='1' stop-color='#e6e3ff'/></linearGradient>"
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='url(#g)'/>")


def bg_riso(w, h):
    d = (_noise("n", 0.85, (0.3, 0.25, 0.2), 0.09)
         + "<pattern id='p' width='9' height='9' patternUnits='userSpaceOnUse'><circle cx='4.5' cy='4.5' r='2' fill='#ff48b0' fill-opacity='0.35'/></pattern>")
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#f6f1e7'/><circle cx='{w - 60}' cy='60' r='240' fill='url(#p)'/><rect width='{w}' height='{h}' filter='url(#n)'/>")


def bg_chalk(w, h):
    d = _noise("n", 0.012, (1, 1, 1), 0.08, 12) + _noise("f", 0.9, (1, 1, 1), 0.05)
    return _svg(w, h, d, f"<rect width='{w}' height='{h}' fill='#26372d'/><rect width='{w}' height='{h}' filter='url(#n)'/><rect width='{w}' height='{h}' filter='url(#f)'/>")


def bg_deco(w, h):
    fan = "<g fill='none' stroke='#d4af37' stroke-opacity='0.12'>" + "".join(
        f"<path d='M{cx - r},{cy} A{r},{r} 0 0,1 {cx + r},{cy}'/>" for cy in range(80, h + 80, 80) for cx in range(0, w + 80, 160) for r in (20, 40, 60, 80)) + "</g>"
    return _svg(w, h, "", f"<rect width='{w}' height='{h}' fill='#0e1a2b'/>{fan}")
