"""Render the user's own app spec in several styles and make one labelled comparison image.

  python scripts/compare.py SPEC.json --styles slate,aurora,midnight [--page dashboard] [--out compare]

Writes OUT/compare-<page>.png (numbered sheet to show the user) and OUT/<style>-<page>.png (full size).
"""
import os, sys, json, argparse, asyncio, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from build import build
from themes import STYLES
from make_gallery import shoot, font
from PIL import Image, ImageDraw

ap = argparse.ArgumentParser(); ap.add_argument("spec"); ap.add_argument("--styles", required=True)
ap.add_argument("--page", default="dashboard"); ap.add_argument("--out", default="compare")
a = ap.parse_args()
spec = json.load(open(a.spec, encoding="utf-8")); styles = a.styles.split(",")
os.makedirs(a.out, exist_ok=True); P = spec.get("app", {}).get("prefix", "")
scr = P + {"home": "HomeScreen", "dashboard": "DashboardScreen", "list": "ListScreen", "form": "FormScreen"}[a.page]
files = []
for st in styles:
    d = os.path.join(a.out, "_" + st); build(spec, st, d)
    files.append(os.path.abspath(os.path.join(d, f"mock_{scr}.html")))
asyncio.run(shoot(files))
W, Hh, pad, cap = 660, 371, 28, 70
cols = 2 if len(styles) > 1 else 1; rows = (len(styles) + cols - 1) // cols
sheet = Image.new("RGB", (pad + cols * (W + pad), 64 + rows * (Hh + cap + pad)), "#f4f4f6"); dr = ImageDraw.Draw(sheet)
dr.text((pad, 18), f"{spec['app']['name']}: pick a style (reply with the number)", fill="#16161d", font=font(24, True))
for i, (st, f) in enumerate(zip(styles, files)):
    im = Image.open(f[:-5] + ".png").convert("RGB"); im.save(os.path.join(a.out, f"{st}-{a.page}.png"))
    x = pad + (i % cols) * (W + pad); y = 64 + (i // cols) * (Hh + cap + pad)
    sheet.paste(im.resize((W, Hh), Image.LANCZOS), (x, y)); dr.rectangle((x - 1, y - 1, x + W, y + Hh), outline="#d9d9e0", width=2)
    dr.text((x, y + Hh + 10), f"{i + 1}. {STYLES[st]['title']}", fill="#16161d", font=font(21, True))
    m = STYLES[st]["mood"]; dr.text((x, y + Hh + 38), m if len(m) < 92 else m[:89] + "…", fill="#55555f", font=font(14))
sheet.save(os.path.join(a.out, f"compare-{a.page}.png"))
for st in styles: shutil.rmtree(os.path.join(a.out, "_" + st), ignore_errors=True)
print("Wrote", os.path.join(a.out, f"compare-{a.page}.png"))
