"""Page templates. Each returns (screen_name, controls, onvisible)."""
from pa import label, button, hit, svg, rect, textinput, gallery, col, pfx_str, gv
from ui import icon_svg, tile_svg, ev
from themes import is_dark


def _agg_py(C, rows, k):
    sel = [r for r in rows if ev(k["where"], r)] if k.get("where") else rows
    if k.get("agg", "sum") == "count": return len(sel)
    vals = [ev(k.get("expr", "1"), r) for r in sel]
    if k.get("agg") == "avg": return sum(vals) / max(1, len(vals))
    return sum(vals)


def _agg_fx(C, src, k):
    s = f"Filter({src}, {k['where']})" if k.get("where") else src
    if k.get("agg", "sum") == "count": return f"CountRows({s})"
    if k.get("agg") == "avg": return f"Average({s}, {k.get('expr', '1')})"
    return f"Sum({s}, {k.get('expr', '1')})"


def plural(f):
    if f.get("plural"): return f["plural"]
    l = f["label"]
    return l[:-1] + "ies" if l.endswith("y") and l[-2:-1] not in "aeiou" else (l if l.endswith("s") else l + "s")


def _kpi_icon(k, i):
    return k.get("icon") or ["coin", "box", "alert", "ban"][i % 4]


# =====================================================================
def kpi_row(C, scr, x0, y, W, kpis, rows, jump=True):
    T = C.T; o = []; n = len(kpis); gap = 18; h = 128 if T["font_display"] != "Lato Light" else 150
    w = (W - gap * (n - 1)) / n; src = C.SRC()
    tints = T.get("kpi_tints")
    for i, k in enumerate(kpis):
        x = round(x0 + i * (w + gap)); ww = round(w); nm = C.n(scr, f"K{i}")
        tone = k.get("tone"); fg = T[tone][0] if tone else T["acc"]
        bgc = T[tone][1] if tone else T["acc_soft"]
        if T.get("outline"): fg, bgc = "000000", (T[tone][1] if tone else "ffffff")
        fill = tints[i % len(tints)] if tints else None
        val_fx = C.fmt_fx(_agg_fx(C, src, k), k.get("format", "number")); val_pv = C.fmt_py(_agg_py(C, rows, k), k.get("format", "number"))
        o.append(C.card(nm + "Card", x, y, ww, h, fill=fill, emph=(i == 0)))
        if T["font_display"] == "Lato Light":  # keynote: number first, huge
            o += [C.L(nm + "T", (x + 22, y + 18, ww - 44, 18), pfx_str(k["label"]), k["label"], 10, "body", "semi", T["ink2"]),
                  C.L(nm + "V", (x + 20, y + 42, ww - 40, 58), val_fx, val_pv, 34, "display", color=fg if tone else T["ink"]),
                  C.L(nm + "S", (x + 22, y + 108, ww - 44, 22), pfx_str(k.get("note", "")), k.get("note", ""), 9, "body", color=fg if (tone and jump) else T["ink2"])]
        else:
            ic = tile_svg(_kpi_icon(k, i), fg, bgc if not fill else ("ffffff" if not T.get("outline") else "ffffff"), 40, min(10, T["r_ctrl"] + 2),
                          border="000000" if T.get("outline") else None)
            o += [svg(nm + "Ico", (x + 20, y + 20, 40, 40), ic),
                  C.L(nm + "T", (x + 72, y + 18, ww - 86, 18), pfx_str(k["label"]), k["label"], 10, "label", "semi", T["ink2"]),
                  C.L(nm + "V", (x + 72, y + 36, ww - 86, 34), val_fx, val_pv, 20, "display", "bold", T["ink"]),
                  rect(nm + "Div", (x + 20, y + 86, ww - 40, 1), T["divider"],
                       pvfill=T["divider"]),
                  C.L(nm + "S", (x + 20, y + 94, ww - 40, 22), pfx_str(k.get("note", "")), k.get("note", ""), 9, "body", "semi" if tone else "normal",
                      color=fg if (tone and not T.get("outline")) else T["ink2"])]
        if jump and k.get("status") and "list" in C.pages:
            o.append(hit(nm + "Hit", (x, y, ww, h), f'Set({C.v("Stat")}, "{k["status"]}");\nNavigate({C.screens["list"]}, ScreenTransition.None)',
                         f"Show {k['label'].lower()}", "RGBA(127, 127, 127, 0.06)", radius=T["r_card"], focus=T["acc"]))
    return o, h


def bars_card(C, scr, x, y, w, h, spec, rows, rank=False):
    T = C.T; nm = C.n(scr, "Rank" if rank else "Brk"); o = [C.card(nm + "Card", x, y, w, h)]
    o += [C.L(nm + "T", (x + 22, y + 18, w - 44, 22), pfx_str(spec["title"]), spec["title"], 12, "display", "semi"),
          C.L(nm + "S", (x + 22, y + 40, w - 44, 18), pfx_str(spec.get("note", "")), spec.get("note", ""), 9, "body", color=T["ink2"])]
    by, ex, fm = spec["by"], spec.get("expr", "1"), spec.get("format", "number")
    agg = {}
    for r in rows: agg[r[by]] = agg.get(r[by], 0) + ev(ex, r)
    data = sorted(({"K": k, "Val": v} for k, v in agg.items()), key=lambda d: -d["Val"])
    top = min(spec.get("top", 6 if rank else 8), max(1, int((h - 92) // (52 if rank else 62)))); data = data[:top]
    for i, d in enumerate(data): d["MaxV"] = data[0]["Val"] or 1; d["Rank"] = i + 1; d["Ci"] = i % 5
    src = C.SRC()
    items = (f"With({{d: {src}}},\n    With({{t: FirstN(Sort(ForAll(Distinct(d, {by}) As k, {{K: k.Value, Val: Sum(Filter(d, {by} = k.Value), {ex})}}), Val, SortOrder.Descending), {top})}},\n"
             f"        With({{m: Max(t, Val)}}, ForAll(Sequence(CountRows(t)) As i, With({{r: Index(t, i.Value)}}, {{Rank: i.Value, K: r.K, Val: r.Val, MaxV: m}})))\n    )\n)")
    pal = T["chart"]
    pal_fx = "Switch(Mod(ThisItem.Rank - 1, 5), " + ", ".join(f'{i}, {col(c)}' for i, c in enumerate(pal[:4])) + f", {col(pal[4])})"
    th = 52 if rank else 62
    def row(it, tw, th_):
        it = it or (data[0] if data else {"K": "", "Val": 0, "MaxV": 1, "Rank": 1, "Ci": 0}); lx = 24 if rank else 0
        out = []
        if rank: out.append(C.L(nm + "No", (0, 0, 22, 22), "ThisItem.Rank", str(it["Rank"]), 9, "label", "bold", T["faint"]))
        else: out.append(rect(nm + "Dot", (0, 8, 8, 8), pal[it["Ci"]], fill_fx=pal_fx))
        bw = max(8, (tw - lx) * it["Val"] / (it["MaxV"] or 1))
        out += [C.L(nm + "K", (lx if rank else 16, 0, tw - 150, 22), "ThisItem.K", it["K"], 10, "body", "semi"),
                C.L(nm + "V", (("Parent.TemplateWidth - 130", tw - 130), 0, 130, 22), C.fmt_fx("ThisItem.Val", fm), C.fmt_py(it["Val"], fm), 10, "body", "semi",
                    T["ink2"] if rank else T["ink"], align="Right"),
                C.bar(nm + "Trk", (lx, 30, ("Parent.TemplateWidth" + (f" - {lx}" if lx else ""), tw - lx), 8 if rank else 10), None, None, track=True),
                C.bar(nm + "Bar", (lx, 30, (f"Max(8, (Parent.TemplateWidth - {lx}) * ThisItem.Val / Max(1, ThisItem.MaxV))", bw), 8 if rank else 10),
                      col(T["acc"]) if rank else pal_fx, T["acc"] if rank else pal[it["Ci"]])]
        return out
    o.append(gallery(nm + "Gal", (x + 22, y + 76, w - 44, h - 92), items, row, data, th))
    return o


def attention_card(C, scr, x, y, w, h, spec, rows):
    T = C.T; nm = C.n(scr, "Att"); o = [C.card(nm + "Card", x, y, w, h)]
    o += [C.L(nm + "T", (x + 22, y + 18, w - 140, 22), pfx_str(spec["title"]), spec["title"], 12, "display", "semi"),
          C.L(nm + "S", (x + 22, y + 40, w - 140, 18), pfx_str(spec.get("note", "")), spec.get("note", ""), 9, "body", color=T["ink2"])]
    if "list" in C.pages and spec.get("status"):
        o.append(C.btn_secondary(nm + "All", (x + w - 108, y + 20, 86, 30), '"View all"', "View all",
                                 f'Set({C.v("Stat")}, "{spec["status"]}");\nNavigate({C.screens["list"]}, ScreenTransition.None)', size=9))
    sel = [r for r in rows if ev(spec["where"], r)]
    srt = spec.get("sort", C.title_f); sel.sort(key=lambda r: ev(srt, r)); sel = sel[:20]
    sub = spec.get("sub")
    def row(it, tw, th):
        it = it or (sel[0] if sel else C.rows[0]); tone = C.tone_of(it.get("StatusText", ""))
        out = [C.L(nm + "P", (0, 7, tw - 110, 20), f"ThisItem.{C.title_f}", it[C.title_f], 10, "body", "semi"),
               C.L(nm + "W", (0, 27, tw - 110, 18), f"ThisItem.{sub}" if sub else '""', str(it.get(sub, "")) if sub else "", 8, "body", color=T["ink2"])]
        if C.status:
            out.append(C.chip(nm + "Chip", (("Parent.TemplateWidth - 100", tw - 100), 14, 100, 24), "ThisItem.StatusText", it.get("StatusText", ""),
                              C.tone_fx("ThisItem", 1), C.tone_fx("ThisItem", 0), T[tone][1], T[tone][0]))
        out += [rect(nm + "Div", (0, th - 1, ("Parent.TemplateWidth", tw), 1), T["divider"]),
                hit(nm + "Hit", (0, 0, ("Parent.TemplateWidth", tw), th), C.go_edit(), "Open this record", "RGBA(127, 127, 127, 0.06)", radius=0, focus=T["acc"])]
        return out
    items = f"FirstN(Sort(Filter({C.SRC()}, {spec['where']}), {srt}, SortOrder.Ascending), 20)"
    o.append(gallery(nm + "Gal", (x + 22, y + 68, w - 34, h - 80), items, row, sel, 52, scroll=True))
    return o


# =====================================================================
def dashboard(C):
    T = C.T; S = C.S; scr = "Db"; D = S["dashboard"]
    o = C.background(scr); navc, x0, y0, W = C.nav(scr, "dashboard"); o += navc
    allx = "All " + plural(C.F[C.seg]).lower() if C.seg else ""
    seg_txt = (f'If({C.v("Seg")} = "All", "{allx}", {C.v("Seg")})' if C.seg else '""')
    o += C.header(scr, x0, y0, D.get("title", "Dashboard"), f'{seg_txt} & "  ·  " & Text(Today(), "d mmmm yyyy")' if C.seg else 'Text(Today(), "d mmmm yyyy")',
                  (allx + "  ·  " if C.seg else "") + "9 November 2026", 560)
    if C.seg:
        ch = ["All"] + C.F[C.seg]["choices"]; pw = min(102 * len(ch), W - 600)
        o.append(C.pills(C.n(scr, "Seg"), (x0 + W - pw, y0 + 4, pw, 38), f"[{', '.join(pfx_str(c) for c in ch)}]", ch, C.v("Seg"), "All", len(ch)))
    kp, kh = kpi_row(C, scr, x0, y0 + 72, W, D["kpis"], C.rows)
    o += kp
    y2 = y0 + 72 + kh + 22; h2 = 768 - 22 - y2; gap = 18; cw = (W - 2 * gap) / 3
    if D.get("breakdown"): o += bars_card(C, scr, x0, y2, round(cw), h2, D["breakdown"], C.rows)
    if D.get("ranking"): o += bars_card(C, scr, round(x0 + cw + gap), y2, round(cw), h2, D["ranking"], C.rows, rank=True)
    if D.get("attention"): o += attention_card(C, scr, round(x0 + 2 * (cw + gap)), y2, round(cw), h2, D["attention"], C.rows)
    return C.screens["dashboard"], o, C.init()


# =====================================================================
def list_page(C):
    T = C.T; S = C.S; scr = "Ls"; L_ = S.get("list", {}); d = S["data"]
    o = C.background(scr); navc, x0, y0, W = C.nav(scr, "list"); o += navc
    gal_name = C.n(scr, "Gal"); search = C.n(scr, "Search")
    o += C.header(scr, x0, y0, d.get("entities", "Records"),
                  f'"Showing " & Text(CountRows({gal_name}.AllItems), "#,##0") & " of " & Text(CountRows({C.coll}), "#,##0")',
                  f"Showing {len(C.rows)} of {len(C.rows)}", 600)
    if "form" in C.pages and T["nav"].startswith("side"):
        lbl = "Add " + d.get("entity", "record").lower()
        o.append(C.btn_primary(C.n(scr, "Add"), (x0 + W - 170, y0 + 4, 170, 42), pfx_str("+  " + lbl), "+  " + lbl, C.go_new()))
    # toolbar
    ty = y0 + 70
    si = textinput(search, (x0, ty, 320, 40), '""', "Search " + ", ".join(f.lower() for f in L_.get("search", [C.title_f])[:3]) + "…", T=T, size=11, padleft=40)
    si.props["DelayOutput"] = "true"
    o += [si, svg(search + "Ico", (x0 + 13, ty + 11, 18, 18), icon_svg("search", T["faint"], 18))]
    if C.filt:
        ch = ["All"] + C.F[C.filt]["choices"]; pw = min(W - 340, 118 * len(ch))
        o.append(C.pills(C.n(scr, "Filt"), (x0 + W - pw, ty - 1, pw, 38), f"[{', '.join(pfx_str(c) for c in ch)}]", ch, C.v("Filt"), "All", len(ch)))
    ty2 = ty + 50
    xx = x0
    if C.seg:
        ch = ["All"] + C.F[C.seg]["choices"]
        pw = min(96 * len(ch), W - 64 - 30 - ((104 * (len(C.status["rules"]) + 1) + 60) if C.status else 0))
        o += [C.L(C.n(scr, "SegL"), (xx, ty2, 70, 38), pfx_str(C.F[C.seg]["label"]), C.F[C.seg]["label"], 9, "label", "semi", T["header_ink2"]),
              C.pills(C.n(scr, "Seg"), (xx + 64, ty2, pw, 38), f"[{', '.join(pfx_str(c) for c in ch)}]", ch, C.v("Seg"), "All", len(ch))]
    if C.status:
        ch = ["All"] + [r[1] for r in C.status["rules"]]; pw = 104 * len(ch)
        o += [C.L(C.n(scr, "StatL"), (x0 + W - pw - 58, ty2, 56, 38), pfx_str(C.status.get("label", "Status")), C.status.get("label", "Status"), 9, "label", "semi", T["header_ink2"]),
              C.pills(C.n(scr, "Stat"), (x0 + W - pw, ty2, pw, 38), f"[{', '.join(pfx_str(c) for c in ch)}]", ch, C.v("Stat"), "All", len(ch))]
    # table
    TY = ty2 + 54; TH = 768 - 22 - TY
    o.append(C.card(C.n(scr, "TblCard"), x0, TY, W, TH))
    cols = L_.get("columns") or [f["name"] for f in d["fields"]][:6] + (["StatusText"] if C.status else [])
    weights = {c: (1.0 if C.F.get(c, {}).get("type") in ("number", "currency") else 1.6) for c in cols}
    if "StatusText" in weights: weights["StatusText"] = 1.2
    weights[C.title_f] = 2.2
    inner = W - 44 - 30; tot = sum(weights.values()); xs = []; cx = 22
    for c in cols:
        cw = inner * weights[c] / tot; xs.append((c, round(cx), round(cw) - 10)); cx += cw
    sortable = L_.get("sort", [C.title_f])
    for c, cx, cw in xs:
        f = C.F.get(c, {"label": C.status.get("label", "Status") if c == "StatusText" else c, "type": "text"})
        al = "Right" if f.get("type") in ("number", "currency") else "Left"
        nm = C.n(scr, "H" + c)
        if c in sortable:
            o += [C.L(nm, (x0 + cx, TY + 12, cw, 24), f'"{f["label"]}" & If({C.v("Sort")} = "{c}", If({C.v("Desc")}, "  ↓", "  ↑"), "")',
                      f["label"] + ("  ↑" if c == C.title_f else ""), 9, "label", "semi", T["ink2"], align=al,
                      color_fx=f'If({C.v("Sort")} = "{c}", {col(T.get("sort_acc", T["acc"]))}, {col(T["ink2"])})',
                      pvcolor=T.get("sort_acc", T["acc"]) if c == C.title_f else T["ink2"]),
                  hit(nm + "Hit", (x0 + cx - 6, TY + 10, cw + 12, 28),
                      f'If({C.v("Sort")} = "{c}", Set({C.v("Desc")}, !{C.v("Desc")}), Set({C.v("Sort")}, "{c}"); Set({C.v("Desc")}, {"true" if f.get("type") in ("number", "currency") else "false"}))',
                      f"Sort by {f['label'].lower()}", radius=6, focus=T["acc"])]
        else:
            o.append(C.L(nm, (x0 + cx, TY + 12, cw, 24), pfx_str(f["label"]), f["label"], 9, "label", "semi", T["ink2"], align=al))
    o.append(rect(C.n(scr, "HDiv"), (x0, TY + 46, W, 1 if not T.get("outline") else 3), T["divider"]))
    # items
    conds = []
    if C.seg: conds.append(f'({C.v("Seg")} = "All" || {C.seg} = {C.v("Seg")})')
    if C.filt: conds.append(f'({C.v("Filt")} = "All" || {C.filt} = {C.v("Filt")})')
    if C.status: conds.append(f'({C.v("Stat")} = "All" || StatusText = {C.v("Stat")})')
    sf = L_.get("search", [C.title_f])
    srch = " || ".join(f"q in Lower({c})" for c in sf)
    order = f'If({C.v("Desc")}, SortOrder.Descending, SortOrder.Ascending)'
    sw = ",\n            ".join(f'"{c}", Sort(f, {c}, {order})' for c in sortable if c != C.title_f)
    items = (f"With(\n    {{q: Lower(Trim({search}.Text)), src: Filter({C.ROWS}, {' && '.join(conds) if conds else 'true'})}},\n"
             f"    With(\n        {{f: If(IsBlank(q), src, Filter(src, {srch}))}},\n"
             f"        Switch(\n            {C.v('Sort')},\n            {sw + ',' if sw else ''}\n            Sort(f, {C.title_f}, {order})\n        )\n    )\n)")
    rows_pv = sorted(C.rows, key=lambda r: str(r[C.title_f]))[:12]
    rh = 52
    def row(it, tw, th):
        it = it or rows_pv[0]; out = []
        for c, cx, cw in xs:
            f = C.F.get(c, {"type": "text"}); nm = C.n(scr, "R" + c)
            if c == "StatusText":
                tone = C.tone_of(it["StatusText"])
                out.append(C.chip(nm, (cx, 14, min(cw, 120), 24), "ThisItem.StatusText", it["StatusText"], C.tone_fx("ThisItem", 1), C.tone_fx("ThisItem", 0), T[tone][1], T[tone][0]))
                continue
            kind = C.ftype_kind(c); al = "Right" if kind != "text" else "Left"
            out.append(C.L(nm, (cx, 0, cw, th), C.fmt_fx(f"ThisItem.{c}", kind) if kind != "text" else f"ThisItem.{c}",
                           C.fmt_py(it[c], kind) if kind != "text" else str(it[c]), 10 if c == C.title_f else 10, "body",
                           "semi" if c == C.title_f else "normal", T["ink"] if c == C.title_f else (T["ink"] if kind != "text" else T["ink2"]), align=al))
        out += [C.L(C.n(scr, "RChev"), (("Parent.TemplateWidth - 26", tw - 26), 0, 14, th), '"›"', "›", 14, "body", color=T["faint"], align="Center"),
                rect(C.n(scr, "RDiv"), (0, th - 1, ("Parent.TemplateWidth", tw), 1), T["divider"]),
                hit(C.n(scr, "RHit"), (0, 0, ("Parent.TemplateWidth", tw), th), C.go_edit(), "Open this record", "RGBA(127, 127, 127, 0.06)", radius=0, focus=T["acc"])]
        return out
    o.append(gallery(gal_name, (x0, TY + 48, W, TH - 56), items, row, rows_pv, rh, scroll=True))
    o.append(C.L(C.n(scr, "Empty"), (x0, TY + 160, W, 60), '"No records match these filters. Clear the search or pick All."', "", 12, "body",
                 color=T["ink2"], align="Center", visible=f"CountRows({gal_name}.AllItems) = 0", pvhide=True))
    return C.screens["list"], o, C.init()


# =====================================================================
def form_page(C, edit_pv=True):
    T = C.T; S = C.S; scr = "Fm"; d = S["data"]
    o = C.background(scr); navc, x0, y0, W = C.nav(scr, "list"); o += navc
    ent = d.get("entity", "record"); M, SEL = C.v("Mode"), C.v("Sel")
    sel = C.rows[0]
    o += [C.btn_secondary(C.n(scr, "Back"), (x0, y0 + 2, 40, 40), '"‹"', "‹", "Back()", size=16),
          C.L(C.n(scr, "Title"), (x0 + 56, y0, 600, 34), f'If({M} = "new", "New {ent.lower()}", {SEL}.{C.title_f})', sel[C.title_f], 20, "display",
              "bold" if T["font_display"] == "Segoe UI" else "normal", T["header_ink"]),
          C.L(C.n(scr, "Sub"), (x0 + 56, y0 + 34, 600, 20), f'If({M} = "new", "Fill in the details and save", "Edit the details and save your changes")',
              "Edit the details and save your changes", 10, "body", color=T["header_ink2"])]
    mw = round(W * 0.66); sx = x0 + mw + 20; sw = W - mw - 20
    CY = y0 + 72; CH = 768 - 22 - CY
    o.append(C.card(C.n(scr, "Main"), x0, CY, mw, CH))
    o.append(C.L(C.n(scr, "SecT"), (x0 + 28, CY + 22, 400, 22), pfx_str(f"{ent} details"), f"{ent} details", 12, "display", "semi"))
    fx_, fw = x0 + 28, mw - 56; half = (fw - 20) // 2
    y = CY + 60; col_i = 0; errs = []; rec = []
    for f in C.form_fields():
        nm = C.n(scr, "In" + f["name"]); t = f.get("type", "text"); req = f.get("required")
        lab_ = f["label"] + ("" if req or t == "choice" else " (optional)")
        if t == "choice":
            if col_i: y += 74; col_i = 0
            var = C.v("F" + f["name"]); ch = f["choices"]
            o += [C.L(nm + "L", (fx_, y, fw, 18), pfx_str(lab_), lab_, 9, "label", "semi", T["ink2"]),
                  C.pills(nm, (fx_, y + 22, min(fw, 132 * len(ch)), 36), f"[{', '.join(pfx_str(c) for c in ch)}]", ch, var, sel[f["name"]], len(ch))]
            rec.append(f"{f['name']}: {var}")
            y += 74; continue
        x = fx_ if col_i == 0 else fx_ + half + 20
        num = t in ("number", "currency")
        dflt = f'If({M} = "edit", {"Text(" + SEL + "." + f["name"] + ")" if num else SEL + "." + f["name"]}, "{f.get("default", "")}")'
        o += [C.L(nm + "L", (x, y, half, 18), pfx_str(lab_), lab_, 9, "label", "semi", T["ink2"]),
              textinput(nm, (x, y + 22, half, 40), dflt, f.get("hint", ""), str(sel[f["name"]]) if edit_pv else "", T=T, numeric=num, size=11)]
        rec.append(f"{f['name']}: " + (f"IfError(Value({nm}.Text), 0)" if num else f"Trim({nm}.Text)"))
        if req and not num: errs.append((f"IsBlank(Trim({nm}.Text))", f"Enter {f['label'].lower()}."))
        if req and num: errs.append((f"IsBlank({nm}.Text) || IfError(Value({nm}.Text), -1) < 0", f"{f['label']} must be a number of 0 or more."))
        col_i = 1 - col_i
        if col_i == 0: y += 74
    if col_i: y += 74
    err_fx = "If(\n    " + ",\n    ".join(f'{c}, "{m}"' for c, m in errs) + ',\n    ""\n)' if errs else '""'
    errn = C.n(scr, "Err")
    o.append(C.L(errn, (fx_, CY + CH - 112, fw, 36), err_fx, "", 9, "body", "semi", T["bad"][0] if not T.get("outline") else "d00000", wrap=True, valign="Top"))
    o.append(rect(C.n(scr, "FootDiv"), (x0, CY + CH - 72, mw, 1), T["divider"]))
    if C.source:  # SharePoint: ID is automatic, Title is the list's required column
        tf = next((r for r in rec if r.startswith(C.title_f + ":")), None)
        if tf and C.title_f != "Title": rec = ["Title: " + tf.split(": ", 1)[1]] + rec
    newrec = ", ".join(rec) if C.source else f"Id: Max({C.coll}, Id) + 1, " + ", ".join(rec)
    save = (f'If(\n    {M} = "new",\n    Collect({C.coll}, {{' + newrec + "});\n"
            f'    Notify("{ent} added", NotificationType.Success),\n'
            f'    Patch({C.coll}, LookUp({C.coll}, {C.key} = {SEL}.{C.key}), {{' + ", ".join(rec) + "});\n"
            f'    Notify("Changes saved", NotificationType.Success)\n);\nBack()')
    by = CY + CH - 56
    o += [C.btn_primary(C.n(scr, "Save"), (x0 + mw - 28 - 150, by, 150, 42), f'If({M} = "new", "Add {ent.lower()}", "Save changes")', "Save changes", save,
                        extra={"DisplayMode": f"If(IsBlank({errn}.Text), DisplayMode.Edit, DisplayMode.Disabled)", "DisabledFill": "ColorFade(Self.Fill, 0.45)", "DisabledColor": col(T["acc_ink"])}),
          C.btn_secondary(C.n(scr, "Cancel"), (x0 + mw - 28 - 150 - 12 - 96, by, 96, 42), '"Cancel"', "Cancel", "Back()"),
          C.btn_secondary(C.n(scr, "Del"), (x0 + 28, by, 104, 42), '"Delete"', "Delete",
                          f'Remove({C.coll}, LookUp({C.coll}, {C.key} = {SEL}.{C.key}));\nNotify("{ent} deleted", NotificationType.Information);\nBack()',
                          color=T["bad"][0] if not T.get("outline") else "d00000", visible=f'{M} = "edit"')]
    # side summary
    o.append(C.card(C.n(scr, "Side"), sx, CY, sw, CH, emph=True))
    o.append(C.L(C.n(scr, "SumT"), (sx + 24, CY + 22, sw - 48, 22), '"Summary"', "Summary", 12, "display", "semi"))
    yy = CY + 62
    if C.status:
        tone = C.tone_of(sel.get("StatusText", ""))
        o += [C.L(C.n(scr, "StL"), (sx + 24, yy, sw - 48, 18), pfx_str(C.status.get("label", "Status")), C.status.get("label", "Status"), 9, "label", "semi", T["ink2"]),
              C.chip(C.n(scr, "StChip"), (sx + 24, yy + 22, 130, 28), f'If({M} = "new", "New", {SEL}.StatusText)', sel.get("StatusText", ""),
                     f'If({M} = "new", {col(T["acc_soft"])}, {C.tone_fx(SEL, 1)})', f'If({M} = "new", {col(T.get("sort_acc", T["acc"]))}, {C.tone_fx(SEL, 0)})',
                     T[tone][1], T[tone][0], size=9)]
        yy += 72
    for c in d.get("computed", []):
        kind = "money" if c.get("type") == "currency" else "number"
        o += [C.L(C.n(scr, "Cv" + c["name"] + "L"), (sx + 24, yy, sw - 48, 18), pfx_str(c["label"]), c["label"], 9, "label", "semi", T["ink2"]),
              C.L(C.n(scr, "Cv" + c["name"]), (sx + 24, yy + 20, sw - 48, 40), f'If({M} = "new", "–", {C.fmt_fx(SEL + "." + c["name"], "currency" if kind == "money" else "number")})',
                  C.fmt_py(sel[c["name"]], "currency" if kind == "money" else "number"), 22, "display", "bold")]
        yy += 76
    tip = S.get("form", {}).get("tip", f"Changes are saved straight to the {C.coll} list." if C.source else f"Changes are saved to {C.coll}. Connect a SharePoint list or Dataverse table to keep them.")
    o += [rect(C.n(scr, "TipBg"), (sx + 24, CY + CH - 120, sw - 48, 96), T["tipbg"],
               pvfill=T["tipbg"]),
          C.L(C.n(scr, "Tip"), (sx + 40, CY + CH - 108, sw - 80, 72), pfx_str(tip), tip, 9, "body", color=T["ink2"], wrap=True, valign="Top")]
    onvis = (C.init() + ";\n" if C.init() else "") + C.reset_form()
    return C.screens["form"], o, onvis


# =====================================================================
def home(C):
    T = C.T; S = C.S; scr = "Hm"; d = S["data"]; Hs = S.get("home", {})
    o = C.background(scr); navc, x0, y0, W = C.nav(scr, "home"); o += navc
    HH = 228
    o.append(C.card(C.n(scr, "Hero"), x0, y0, W, HH, fill=T["acc"] if T.get("hero_fill") else None, emph=True))
    on_acc = T.get("hero_fill"); ink = T["acc_ink"] if on_acc else T["ink"]; ink2 = T["acc_ink"] if on_acc else T["ink2"]
    if T.get("outline"): ink = ink2 = "ffffff"
    greet = 'If(Hour(Now()) < 12, "Good morning", Hour(Now()) < 17, "Good afternoon", "Good evening")'
    o += [C.L(C.n(scr, "Greet"), (x0 + 36, y0 + 32, 600, 22), greet + (' & ", " & ' + Hs["user"] if Hs.get("user") else ""), "Good morning", 11, "body", "semi", ink2),
          C.L(C.n(scr, "Head"), (x0 + 36, y0 + 58, W - 36 - 470, 76), pfx_str(Hs.get("headline", S["app"]["name"])), Hs.get("headline", S["app"]["name"]),
              26 if T["font_display"] != "Lato Light" else 30, "display", "bold" if T["font_display"] == "Segoe UI" else "normal", ink, wrap=True, valign="Top"),
          C.L(C.n(scr, "Lead"), (x0 + 36, y0 + 140, 600, 22), pfx_str(Hs.get("lead", S["app"].get("tagline", ""))), Hs.get("lead", S["app"].get("tagline", "")), 11, "body", color=ink2)]
    bx = x0 + 36
    if "dashboard" in C.pages:
        b = (C.btn_secondary if on_acc else C.btn_primary)(C.n(scr, "CtaDash"), (bx, y0 + 172, 168, 40), '"Open dashboard"', "Open dashboard",
                                                            f"Navigate({C.screens['dashboard']}, ScreenTransition.None)")
        o.append(b); bx += 180
    if "form" in C.pages:
        o.append(C.btn_secondary(C.n(scr, "CtaNew"), (bx, y0 + 172, 168, 40), pfx_str("New " + d.get("entity", "record").lower()), "New " + d.get("entity", "record").lower(), C.go_new()))
    # hero stats (first two KPIs)
    ks = S.get("dashboard", {}).get("kpis", [])[:2]
    for i, k in enumerate(ks):
        xx = x0 + W - 36 - (2 - i) * 210
        o += [C.L(C.n(scr, f"HS{i}V"), (xx, y0 + 70, 200, 52), C.fmt_fx(_agg_fx(C, C.ROWS, k), k.get("format", "number")),
                  C.fmt_py(_agg_py(C, C.rows, k), k.get("format", "number")), 26 if T["font_display"] != "Lato Light" else 32, "display",
                  "bold" if T["font_display"] == "Segoe UI" else "normal", ink, align="Right"),
              C.L(C.n(scr, f"HS{i}L"), (xx, y0 + 124, 200, 20), pfx_str(k["label"]), k["label"], 10, "body", color=ink2, align="Right")]
    # tiles
    ty = y0 + HH + 20; tiles = []
    if "dashboard" in C.pages: tiles.append(("Dash", "grid", "Dashboard", Hs.get("dash_note", "Key numbers, breakdowns and alerts"), f"Navigate({C.screens['dashboard']}, ScreenTransition.None)"))
    if "list" in C.pages: tiles.append(("List", "list", d.get("entities", "Records"), Hs.get("list_note", "Search, filter and edit every record"), f"Navigate({C.screens['list']}, ScreenTransition.None)"))
    if "form" in C.pages: tiles.append(("New", "plus", "New " + d.get("entity", "record").lower(), Hs.get("new_note", "Add a record in a few steps"), C.go_new()))
    TH_ = 132; gap = 18; tw = (W - gap * (len(tiles) - 1)) / max(1, len(tiles)); tints = T.get("kpi_tints")
    for i, (k, ic, t, note, act) in enumerate(tiles):
        x = round(x0 + i * (tw + gap)); w = round(tw); nm = C.n(scr, "T" + k)
        o += [C.card(nm + "Card", x, ty, w, TH_, fill=tints[(i + 1) % len(tints)] if tints else None),
              svg(nm + "Ico", (x + 22, ty + 22, 40, 40), tile_svg(ic, T["acc"] if not T.get("outline") else "000000", T["acc_soft"] if not tints else "ffffff", 40, min(10, T["r_ctrl"] + 2),
                                                               border="000000" if T.get("outline") else None)),
              C.L(nm + "T", (x + 22, ty + 74, w - 80, 24), pfx_str(t), t, 13, "display", "semi" if T["font_display"] == "Segoe UI" else "normal"),
              C.L(nm + "N", (x + 22, ty + 98, w - 60, 20), pfx_str(note), note, 9, "body", color=T["ink2"]),
              svg(nm + "Go", (x + w - 46, ty + 24, 22, 22), icon_svg("arrow", T["ink2"], 22)),
              hit(nm + "Hit", (x, ty, w, TH_), act, "Open " + t, "RGBA(127, 127, 127, 0.06)", radius=T["r_card"], focus=T["acc"])]
    # latest records
    ly = ty + TH_ + 20; LH = 768 - 22 - ly
    o.append(C.card(C.n(scr, "Recent"), x0, ly, W, LH))
    o.append(C.L(C.n(scr, "RecT"), (x0 + 24, ly + 16, 400, 22), pfx_str("Latest " + d.get("entities", "records").lower()), "Latest " + d.get("entities", "records").lower(), 12, "display", "semi"))
    sub = Hs.get("sub") or (S.get("dashboard", {}).get("attention", {}) or {}).get("sub")
    rec = sorted(C.rows, key=lambda r: -r["Id"])[:8]
    def row(it, tw_, th):
        it = it or rec[0]; out = [C.L(C.n(scr, "RP"), (0, 0, tw_ * 0.45, th), f"ThisItem.{C.title_f}", it[C.title_f], 10, "body", "semi"),
                                  C.L(C.n(scr, "RS"), (tw_ * 0.45, 0, tw_ * 0.3, th), f"ThisItem.{sub}" if sub else '""', str(it.get(sub, "")) if sub else "", 9, "body", color=T["ink2"])]
        if C.status:
            tone = C.tone_of(it.get("StatusText", ""))
            out.append(C.chip(C.n(scr, "RC"), (("Parent.TemplateWidth - 140", tw_ - 140), (th - 24) // 2, 116, 24), "ThisItem.StatusText", it.get("StatusText", ""),
                              C.tone_fx("ThisItem", 1), C.tone_fx("ThisItem", 0), T[tone][1], T[tone][0]))
        out += [rect(C.n(scr, "RD"), (0, th - 1, ("Parent.TemplateWidth", tw_), 1), T["divider"]),
                hit(C.n(scr, "RH"), (0, 0, ("Parent.TemplateWidth", tw_), th), C.go_edit(), "Open this record", "RGBA(127, 127, 127, 0.06)", radius=0, focus=T["acc"])]
        return out
    o.append(gallery(C.n(scr, "RecGal"), (x0 + 24, ly + 46, W - 36, LH - 54), f"FirstN(Sort({C.ROWS}, {C.key}, SortOrder.Descending), 20)", row, rec, 44, scroll=True))
    return C.screens["home"], o, C.init()


PAGES = {"home": home, "dashboard": dashboard, "list": list_page, "form": form_page}
