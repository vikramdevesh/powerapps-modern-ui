"""Screenshot mock_*.html files with Playwright (1366x768).  python scripts/shoot.py FILE.html [...] [--scale 1]"""
import sys, asyncio
from playwright.async_api import async_playwright
async def main(files, scale):
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={"width": 1366, "height": 768}, device_scale_factor=scale)
        for f in files:
            await pg.goto("file://" + __import__("os").path.abspath(f)); await pg.wait_for_timeout(500)
            await pg.screenshot(path=f.rsplit(".", 1)[0] + ".png")
        await b.close()
if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]; s = 2 if "--hd" in sys.argv else 1
    asyncio.run(main(a, s))
